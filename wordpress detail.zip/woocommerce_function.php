(*)wc_format_weight
->Format a weight for display.

(*)wc_format_dimensions
->Format dimensions for display.

(*)wc_get_dimension
->Normalise dimensions, unify to cm then convert to wanted unit value.
->Usage: wc_get_dimension( 55, 'in' ); wc_get_dimension( 55, 'in', 'm' );

(*)wc_get_weight
->Normalise weights, unify to kg then convert to wanted unit value.
->Usage: wc_get_weight(55, 'kg'); wc_get_weight(55, 'kg', 'lbs');

(*)wc_get_price_decimals
->Return the number of decimals after the decimal point.

(*)wc_string_to_bool
->Converts a string (e.g. 'yes' or 'no') to a bool.

(*)wc_bool_to_string
->Converts a bool to a 'yes' or 'no'.


(*)wc_string_to_array
->Explode a string into an array by $delimiter and remove empty values.

(*)wc_sanitize_taxonomy_name
->Sanitize taxonomy names. Slug format (no spaces, lowercase). Urldecode is used to reverse munging of UTF8 characters.

(*)wc_sanitize_permalink
->Sanitize permalink values before insertion into DB.
->Cannot use wc_clean because it sometimes strips % chars and breaks the user's setting.

(*)wc_get_filename_from_url
->Gets the filename part of a download URL.

(*)wc_trim_zeros
->Trim trailing zeros off prices

(*)wc_get_price_decimal_separator
->Return the decimal separator for prices.


(*)wc_round_tax_total
->Round a tax amount.

(*)wc_get_tax_rounding_mode
->Get rounding mode for internal tax calculations.


(*)wc_legacy_round_half_down
->Round half down in PHP 5.2.

(*)wc_float_to_string
->Convert a float to a string without locale formatting which PHP adds when changing floats to strings.

(*)wc_format_localized_price
->Format a price with WC Currency Locale settings.


(*)wc_format_localized_decimal
->Format a decimal with PHP Locale settings.



(*)wc_format_coupon_code
->Format a Coupon Code.

(*)wc_clean
->Clean variables using sanitize_text_field. Arrays are cleaned recursively. Non-scalar values are ignored.



(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->

(*)
->







