
----------------------------------Scripts in Header----------------------------------


<link rel="stylesheet" href="http://13.251.140.13/wordpress/petminda/wp-content/themes/proland-child/jquery.fancybox.css" />
<div id="hidden_link">
    <h3 style="color: #fff;">Launch day announcement</h3>
    <p>YOU'RE INVITED to the Petminda launch days!</p>
    <p>Barkly Square, Brunswick -   10th July<br>
        Highpoint shopping centre -   24th july<br>
        Victoria Gardens, Richmond - 7th August</p>
    <p>Giveaways, live demonstrations and a Park your pooch competition!</p>
    <p>Register your email <span>NOW</span> for one week <span>FREE, UNLIMITED use of the pods</span></p>
    <p>�</p>
    <a class="btn btn-primary btn-md" role="button" href="http://13.251.140.13/wordpress/petminda/register/">REGISTER NOW!!!</a>
</div>

----------------------------------Scripts in Footer----------------------------------

<script src="http://13.251.140.13/wordpress/petminda/wp-content/themes/proland-child/js/jquery.fancybox.pack.js
"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
<script type="text/javascript">
    /* jQuery(document).ready(function() { 
     setTimeout(function(){
     
     jQuery.fancybox.open('#hidden_link');
     
     },500)
     });*/
    jQuery(document).ready(function () {
        var visited = jQuery.cookie('pet_visited'); // create the cookie

        if (visited == 'yes') {
            return false; // second page load, cookie is active so do nothing

        } else {

            setTimeout(function () {
                jQuery.fancybox.open('#hidden_link');

            }, 500)
        }
        ;
        // assign cookie's value and expiration time
        jQuery.cookie('pet_visited', 'yes', {
            expires: 7 // the number of days the cookie will be effective
        });
        // your normal fancybox script
        /* jQuery("#hidden_link").click(function () {
         jQuery.fancybox({
         // your fancybox API options
         });
         return false;
         });*/
    });
</script>