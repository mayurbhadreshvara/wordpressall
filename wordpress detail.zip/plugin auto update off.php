//30518
// Disable update notification for individual plugins

function filter_plugin_updates($value) {

    unset($value->response['advanced-custom-fields/acf.php']);
    unset($value->response['acf-repeater/acf-repeater.php']);
    unset($value->response['woocommerce-ajax-filters/woocommerce-filters.php']);
    unset($value->response['woocommerce/woocommerce.php']);
    unset($value->response['ajax-load-more/ajax-load-more.php']);


    return $value;
}

add_filter('site_transient_update_plugins', 'filter_plugin_updates');

//Disable automatic WordPress plugin updates:

add_filter('auto_update_plugin', '__return_false');

//Disable automatic WordPress theme updates:

add_filter('auto_update_theme', '__return_false');

//


--------------------------------------------------------------------------
wordpress version & plugin update & theme update

function remove_core_updates(){
global $wp_version;return(object) array('last_checked'=> time(),'version_checked'=> $wp_version,);
}
add_filter('pre_site_transient_update_core','remove_core_updates');
add_filter('pre_site_transient_update_plugins','remove_core_updates');
add_filter('pre_site_transient_update_themes','remove_core_updates');
