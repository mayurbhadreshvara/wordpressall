
<div class="input country">
[group Somalia]
   <div class="selectbox ">
       [select country-region "Select a region" "Awdal" "Bakol" "Banadir" "Bari" "Bay" "Galgudug" "Gedo" "Hiran" "Jubbada Hose" "Jubbadha Dexe" "Mudug" "Nugal" "Sanag" "Shabellaha Dhexe" "Shabellaha Hose" "Togdher" "Woqoyi Galbed"]
   </div>
[/group]
</div>

<div class="input country">
[group South-Africa]
   <div class="selectbox ">
       [select country-region "Select a region" "Eastern Cape" "Free State" "Gauteng" "Kempton Park" "Kramerville" "KwaZulu Natal" "Limpopo" "Mpumalanga" "North West" "Northern Cape" "Parow" "Table View" "Umtentweni" "Western Cape"]
   </div>
[/group]
</div>

<div class="input country">
[group South-Georgia]
   <div class="selectbox ">
       [select country-region "Select a region" "South Georgia"]
   </div>
[/group]
</div>

<div class="input country">
[group South-Sudan]
   <div class="selectbox ">
       [select country-region "Select a region" "Central Equatoria"]
   </div>
[/group]
</div>

<div class="input country">
[group Spain]
   <div class="selectbox ">
       [select country-region "Select a region" "A Coruna" "Alacant" "Alava" "Albacete" "Almeria" "Asturias" "Avila" "Badajoz" "Balears" "Barcelona" "Burgos" "Caceres" "Cadiz" "Cantabria" "Castello" "Ceuta" "Ciudad Real" "Cordoba" "Cuenca" "Girona" "Granada" "Guadalajara" "Guipuzcoa" "Huelva" "Huesca" "Jaen" "La Rioja" "Las Palmas" "Leon" "Lleida" "Lugo" "Madrid" "Malaga" "Melilla" "Murcia" "Navarra" "Ourense" "Pais Vasco" "Palencia" "Pontevedra" "Salamanca" "Segovia" "Sevilla" "Soria" "Tarragona" "Santa Cruz de Tenerife" "Teruel" "Toledo" "Valencia" "Valladolid" "Vizcaya" "Zamora" "Zaragoza"]
   </div>
[/group]
</div>

<div class="input country">
[group SriLanka]
   <div class="selectbox ">
       [select country-region "Select a region" "Amparai" "Anuradhapuraya" "Badulla" "Boralesgamuwa" "Colombo" "Galla" "Gampaha" "Hambantota" "Kalatura" "Kegalla" "Kilinochchi" "Kurunegala" "Madakalpuwa" "Maha Nuwara" "Malwana" "Mannarama" "Matale" "Matara" "Monaragala" "Mullaitivu" "North Eastern Province" "North Western Province" "Nuwara Eliya" "Polonnaruwa" "Puttalama" "Ratnapuraya" "Southern Province" "Tirikunamalaya" "Tuscany" "Vavuniyawa" "Western Province" "Yapanaya" "kadawatha"]
   </div>
[/group]
</div>

<div class="input country">
[group Sudan]
   <div class="selectbox ">
       [select country-region "Select a region" "A'ali-an-Nil" "Bahr-al-Jabal" "Central Equatoria" "Gharb Bahr-al-Ghazal" "Gharb Darfur" "Gharb Kurdufan" "Gharb-al-Istiwa'iyah" "Janub Darfur" "Janub Kurdufan" "Junqali" "Kassala" "Nahr-an-Nil" "Shamal Bahr-al-Ghazal" "Shamal Darfur" "Shamal Kurdufan" "Sharq-al-Istiwa'iyah" "Sinnar" "Warab" "Wilayat al Khartum" "al-Bahr-al-Ahmar" "al-Buhayrat" "al-Jazirah" "al-Khartum" "al-Qadarif" "al-Wahdah" "an-Nil-al-Abyad" "an-Nil-al-Azraq" "ash-Shamaliyah"]
   </div>
[/group]
</div>

<div class="input country">
[group Suriname]
   <div class="selectbox ">
       [select country-region "Select a region" "Brokopondo" "Commewijne" "Coronie" "Marowijne" "Nickerie" "Para" "Paramaribo" "Saramacca" "Wanica"]
   </div>
[/group]
</div>

<div class="input country">
[group Svalbard-And-Jan-Mayen-Islands]
   <div class="selectbox ">
       [select country-region "Select a region" "Svalbard"]
   </div>
[/group]
</div>

<div class="input country">
[group Swaziland]
   <div class="selectbox ">
       [select country-region "Select a region" "Hhohho" "Lubombo" "Manzini" "Shiselweni"]
   </div>
[/group]
</div>

<div class="input country">
[group Sweden]
   <div class="selectbox ">
       [select country-region "Select a region" "Alvsborgs Lan" "Angermanland" "Blekinge" "Bohuslan" "Dalarna" "Gavleborg" "Gaza" "Gotland" "Halland" "Jamtland" "Jonkoping" "Kalmar" "Kristianstads" "Kronoberg" "Norrbotten" "Orebro" "Ostergotland" "Saltsjo-Boo" "Skane" "Smaland" "Sodermanland" "Stockholm" "Uppsala" "Varmland" "Vasterbotten" "Vastergotland" "Vasternorrland" "Vastmanland" "Vastra Gotaland"]
   </div>
[/group]
</div>

<div class="input country">
[group Switzerland]
   <div class="selectbox ">
       [select country-region "Select a region" "Aargau" "Appenzell Inner-Rhoden" "Appenzell-Ausser Rhoden" "Basel-Landschaft" "Basel-Stadt" "Bern" "Canton Ticino" "Fribourg" "Geneve" "Glarus" "Graubunden" "Heerbrugg" "Jura" "Kanton Aargau" "Luzern" "Morbio Inferiore" "Muhen" "Neuchatel" "Nidwalden" "Obwalden" "Sankt Gallen" "Schaffhausen" "Schwyz" "Solothurn" "Thurgau" "Ticino" "Uri" "Valais" "Vaud" "Vauffelin" "Zug" "Zurich"]
   </div>
[/group]
</div>

<div class="input country">
[group Syria]
   <div class="selectbox ">
       [select country-region "Select a region" "Aleppo" "Dar'a" "Dayr-az-Zawr" "Dimashq" "Halab" "Hamah" "Hims" "Idlib" "Madinat Dimashq" "Tartus" "al-Hasakah" "al-Ladhiqiyah" "al-Qunaytirah" "ar-Raqqah" "as-Suwayda"]
   </div>
[/group]
</div>

<div class="input country">
[group Taiwan]
   <div class="selectbox ">
       [select country-region "Select a region" "Chiayi County" "Chiayi City" "Taipei City" "Hsinchu County" "Hsinchu City" "Hualien County" "Kaohsiung City" "Keelung City" "Kinmen County" "Miaoli County" "Nantou County" "Penghu County" "Pingtung County" "Taichung City" "Tainan City" "New Taipei City" "Taitung County" "Taoyuan City" "Yilan County" "YunLin County" "Lienchiang County"]
   </div>
[/group]
</div>

<div class="input country">
[group Tajikistan]
   <div class="selectbox ">
       [select country-region "Select a region" "Dushanbe" "Gorno-Badakhshan" "Karotegin" "Khatlon" "Sughd"]
   </div>
[/group]
</div>

<div class="input country">
[group Tanzania]
   <div class="selectbox ">
       [select country-region "Select a region" "Arusha" "Dar es Salaam" "Dodoma" "Iringa" "Kagera" "Kigoma" "Kilimanjaro" "Lindi" "Mara" "Mbeya" "Morogoro" "Mtwara" "Mwanza" "Pwani" "Rukwa" "Ruvuma" "Shinyanga" "Singida" "Tabora" "Tanga" "Zanzibar and Pemba"]
   </div>
[/group]
</div>

<div class="input country">
[group Thailand]
   <div class="selectbox ">
       [select country-region "Select a region" "Amnat Charoen" "Ang Thong" "Bangkok" "Buri Ram" "Chachoengsao" "Chai Nat" "Chaiyaphum" "Changwat Chaiyaphum" "Chanthaburi" "Chiang Mai" "Chiang Rai" "Chon Buri" "Chumphon" "Kalasin" "Kamphaeng Phet" "Kanchanaburi" "Khon Kaen" "Krabi" "Krung Thep" "Lampang" "Lamphun" "Loei" "Lop Buri" "Mae Hong Son" "Maha Sarakham" "Mukdahan" "Nakhon Nayok" "Nakhon Pathom" "Nakhon Phanom" "Nakhon Ratchasima" "Nakhon Sawan" "Nakhon Si Thammarat" "Nan" "Narathiwat" "Nong Bua Lam Phu" "Nong Khai" "Nonthaburi" "Pathum Thani" "Pattani" "Phangnga" "Phatthalung" "Phayao" "Phetchabun" "Phetchaburi" "Phichit" "Phitsanulok" "Phra Nakhon Si Ayutthaya" "Phrae" "Phuket" "Prachin Buri" "Prachuap Khiri Khan" "Ranong" "Ratchaburi" "Rayong" "Roi Et" "Sa Kaeo" "Sakon Nakhon" "Samut Prakan" "Samut Sakhon" "Samut Songkhran" "Saraburi" "Satun" "Si Sa Ket" "Sing Buri" "Songkhla" "Sukhothai" "Suphan Buri" "Surat Thani" "Surin" "Tak" "Trang" "Trat" "Ubon Ratchathani" "Udon Thani" "Uthai Thani" "Uttaradit" "Yala" "Yasothon"]
   </div>
[/group]
</div>

<div class="input country">
[group Togo]
   <div class="selectbox ">
       [select country-region "Select a region" "Centre" "Kara" "Maritime" "Plateaux" "Savanes"]
   </div>
[/group]
</div>

<div class="input country">
[group Tokelau]
   <div class="selectbox ">
       [select country-region "Select a region" "Atafu" "Fakaofo" "Nukunonu"]
   </div>
[/group]
</div>

<div class="input country">
[group Tonga]
   <div class="selectbox ">
       [select country-region "Select a region" "Eua" "Ha'apai" "Niuas" "Tongatapu" "Vava'u"]
   </div>
[/group]
</div>

<div class="input country">
[group Trinidad-And-Tobago]
   <div class="selectbox ">
       [select country-region "Select a region" "Arima-Tunapuna-Piarco" "Caroni" "Chaguanas" "Couva-Tabaquite-Talparo" "Diego Martin" "Glencoe" "Penal Debe" "Point Fortin" "Port of Spain" "Princes Town" "Saint George" "San Fernando" "San Juan" "Sangre Grande" "Siparia" "Tobago"]
   </div>
[/group]
</div>

<div class="input country">
[group Tunisia]
   <div class="selectbox ">
       [select country-region "Select a region" "Aryanah" "Bajah" "Bin 'Arus" "Binzart" "Gouvernorat de Ariana" "Gouvernorat de Nabeul" "Gouvernorat de Sousse" "Hammamet Yasmine" "Jundubah" "Madaniyin" "Manubah" "Monastir" "Nabul" "Qabis" "Qafsah" "Qibili" "Safaqis" "Sfax" "Sidi Bu Zayd" "Silyanah" "Susah" "Tatawin" "Tawzar" "Tunis" "Zaghwan" "al-Kaf" "al-Mahdiyah" "al-Munastir" "al-Qasrayn" "al-Qayrawan"]
   </div>
[/group]
</div>

<div class="input country">
[group Turkey]
   <div class="selectbox ">
       [select country-region "Select a region" "Adana" "Adiyaman" "Afyon" "Agri" "Aksaray" "Amasya" "Ankara" "Antalya" "Ardahan" "Artvin" "Aydin" "Balikesir" "Bartin" "Batman" "Bayburt" "Bilecik" "Bingol" "Bitlis" "Bolu" "Burdur" "Bursa" "Canakkale" "Cankiri" "Corum" "Denizli" "Diyarbakir" "Duzce" "Edirne" "Elazig" "Erzincan" "Erzurum" "Eskisehir" "Gaziantep" "Giresun" "Gumushane" "Hakkari" "Hatay" "Icel" "Igdir" "Isparta" "Istanbul" "Izmir" "Kahramanmaras" "Karabuk" "Karaman" "Kars" "Karsiyaka" "Kastamonu" "Kayseri" "Kilis" "Kirikkale" "Kirklareli" "Kirsehir" "Kocaeli" "Konya" "Kutahya" "Lefkosa" "Malatya" "Manisa" "Mardin" "Mugla" "Mus" "Nevsehir" "Nigde" "Ordu" "Osmaniye" "Rize" "Sakarya" "Samsun" "Sanliurfa" "Siirt" "Sinop" "Sirnak" "Sivas" "Tekirdag" "Tokat" "Trabzon" "Tunceli" "Usak" "Van" "Yalova" "Yozgat" "Zonguldak"]
   </div>
[/group]
</div>


<div class="input country">
[group Turkmenistan]
   <div class="selectbox ">
       [select country-region "Select a region" "Ahal" "Asgabat" "Balkan" "Dasoguz" "Lebap" "Mari"]   </div>
[/group]
</div>

<div class="input country">
[group Turks-And-Caicos-Islands]
   <div class="selectbox ">
       [select country-region "Select a region" "Grand Turk" "South Caicos and East Caicos"]   </div>
[/group]
</div>

<div class="input country">
[group Tuvalu]
   <div class="selectbox ">
       [select country-region "Select a region" "Funafuti" "Nanumanga" "Nanumea" "Niutao" "Nui" "Nukufetau" "Nukulaelae" "Vaitupu"]   </div>
[/group]
</div>

<div class="input country">
[group Uganda]
   <div class="selectbox ">
       [select country-region "Select a region" "Central" "Eastern" "Northern" "Western"]   </div>
[/group]
</div>

<div class="input country">
[group Ukraine]
   <div class="selectbox ">
       [select country-region "Select a region" "Cherkas'ka" "Chernihivs'ka" "Chernivets'ka" "Crimea" "Dnipropetrovska" "Donets'ka" "Ivano-Frankivs'ka" "Kharkiv" "Kharkov" "Khersonska" "Khmel'nyts'ka" "Kirovohrad" "Krym" "Kyyiv" "Kyyivs'ka" "L'vivs'ka" "Luhans'ka" "Mykolayivs'ka" "Odes'ka" "Odessa" "Poltavs'ka" "Rivnens'ka" "Sevastopol'" "Sums'ka" "Ternopil's'ka" "Volyns'ka" "Vynnyts'ka" "Zakarpats'ka" "Zaporizhia" "Zhytomyrs'ka" ]   </div>
[/group]
</div>

<div class="input country">
[group United-Arab-Emirates]
   <div class="selectbox ">
       [select country-region "Select a region" "Abu Zabi" "Ajman" "Dubai" "Ras al-Khaymah" "Sharjah" "Sharjha" "Umm al Qaywayn" "al-Fujayrah" "ash-Shariqah"]   </div>
[/group]
</div>

<div class="input country">
[group United-Kingdom]
   <div class="selectbox ">
       [select country-region "Select a region" "Aberdeen" "Aberdeenshire" "Argyll" "Armagh" "Bedfordshire" "Belfast" "Berkshire" "Birmingham" "Brechin" "Bridgnorth" "Bristol" "Buckinghamshire" "Cambridge" "Cambridgeshire" "Channel Islands" "Cheshire" "Cleveland" "Co Fermanagh" "Conwy" "Cornwall" "Coventry" "Craven Arms" "Cumbria" "Denbighshire" "Derby" "Derbyshire" "Devon" "Dial Code Dungannon" "Didcot" "Dorset" "Dunbartonshire" "Durham" "East Dunbartonshire" "East Lothian" "East Midlands" "East Sussex" "East Yorkshire" "England" "Essex" "Fermanagh" "Fife" "Flintshire" "Fulham" "Gainsborough" "Glocestershire" "Gwent" "Hampshire" "Hants" "Herefordshire" "Hertfordshire" "Ireland" "Isle Of Man" "Isle of Wight" "Kenford" "Kent" "Kilmarnock" "Lanarkshire" "Lancashire" "Leicestershire" "Lincolnshire" "Llanymynech" "London" "Ludlow" "Manchester" "Mayfair" "Merseyside" "Mid Glamorgan" "Middlesex" "Mildenhall" "Monmouthshire" "Newton Stewart" "Norfolk" "North Humberside" "North Yorkshire" "Northamptonshire" "Northants" "Northern Ireland" "Northumberland" "Nottingh]   </div>
[/group]
</div>

<div class="input country">
[group United-States]
   <div class="selectbox ">
       [select country-region "Select a region" "Alabama" "Alaska" "Arizona" "Arkansas" "Byram" "California" "Cokato" "Colorado" "Connecticut" "Delaware" "District of Columbia" "Florida" "Georgia" "Hawaii" "Idaho" "Illinois" "Indiana" "Iowa" "Kansas" "Kentucky" "Louisiana" "Lowa" "Maine" "Maryland" "Massachusetts" "Medfield" "Michigan" "Minnesota" "Mississippi" "Missouri" "Montana" "Nebraska" "Nevada" "New Hampshire" "New Jersey" "New Jersy" "New Mexico" "New York" "North Carolina" "North Dakota" "Ohio" "Oklahoma" "Ontario" "Oregon" "Pennsylvania" "Ramey" "Rhode Island" "South Carolina" "South Dakota" "Sublimity" "Tennessee" "Texas" "Trimble" "Utah" "Vermont" "Virginia" "Washington" "West Virginia" "Wisconsin" "Wyoming" ]   </div>
[/group]
</div>

<div class="input country">
[group United-States-Minor-Outlying-Islands]
   <div class="selectbox ">
       [select country-region "Select a region" "United States Minor Outlying I"]   </div>
[/group]
</div>

<div class="input country">
[group Artigas]
   <div class="selectbox ">
       [select country-region "Select a region" "Canelones" "Cerro Largo" "Colonia" "Durazno" "FLorida" "Flores" "Lavalleja" "Maldonado" "Montevideo" "Paysandu" "Rio Negro" "Rivera" "Rocha" "Salto" "San Jose" "Soriano" "Tacuarembo" "Treinta y Tres"]   </div>
[/group]
</div>

<div class="input country">
[group Uzbekistan]
   <div class="selectbox ">
       [select country-region "Select a region" "Andijon" "Buhoro" "Buxoro Viloyati" "Cizah" "Fargona" "Horazm" "Kaskadar" "Korakalpogiston" "Namangan" "Navoi" "Samarkand" "Sirdare" "Surhondar" "Toskent" ]   </div>
[/group]
</div>

<div class="input country">
[group Vanuatu]
   <div class="selectbox ">
       [select country-region "Select a region" "Malampa" "Penama" "Sanma" "Shefa" "Tafea" "Torba"]   </div>
[/group]
</div>

<div class="input country">
[group Vatican-City-State-(Holy-See)]
   <div class="selectbox ">
       [select country-region "Select a region" "Vatican City State (Holy See)" ]   </div>
[/group]
</div>

<div class="input country">
[group Venezuela]
   <div class="selectbox ">
       [select country-region "Select a region" "Amazonas" "Anzoategui" "Apure" "Aragua" "Barinas" "Bolivar" "Carabobo" "Cojedes" "Delta Amacuro" "Distrito Federal" "Falcon" "Guarico" "Lara" "Merida" "Miranda" "Monagas" "Nueva Esparta" "Portuguesa" "Sucre" "Tachira" "Trujillo" "Vargas" "Yaracuy" "Zulia"]   </div>
[/group]
</div>

<div class="input country">
[group Vietnam]
   <div class="selectbox ">
       [select country-region "Select a region" "Bac Giang" "Binh Dinh" "Binh Duong" "Da Nang" "Dong Bang Song Cuu Long" "Dong Bang Song Hong" "Dong Nai" "Dong Nam Bo" "Duyen Hai Mien Trung" "Hanoi" "Hung Yen" "Khu Bon Cu" "Long An" "Mien Nui Va Trung Du" "Thai Nguyen" "Thanh Pho Ho Chi Minh" "Thu Do Ha Noi" "Tinh Can Tho" "Tinh Da Nang" "Tinh Gia Lai" ]   </div>
[/group]
</div>

<div class="input country">
[group Virgin-Islands-(British)]
   <div class="selectbox ">
       [select country-region "Select a region" "Anegada" "Jost van Dyke" "Tortola"]   </div>
[/group]
</div>

<div class="input country">
[group Virgin-Islands-(US)]
   <div class="selectbox ">
       [select country-region "Select a region" "Saint Croix" "Saint John" "Saint Thomas"]   </div>
[/group]
</div>

<div class="input country">
[group Wallis-And-Futuna-Islands]
   <div class="selectbox ">
       [select country-region "Select a region" "Alo" "Singave" "Wallis"]   </div>
[/group]
</div>

<div class="input country">
[group Western-Sahara]
   <div class="selectbox ">
       [select country-region "Select a region" "Bu Jaydur" "Wad-adh-Dhahab" "al-'Ayun" "as-Samarah"]   </div>
[/group]
</div>

<div class="input country">
[group Yemen]
   <div class="selectbox ">
       [select country-region "Select a region" "'Adan" "Abyan" "Dhamar" "Hadramaut" "Hajjah" "Hudaydah" "Ibb" "Lahij" "Ma'rib" "Madinat San'a" "Sa'dah" "Sana" "Shabwah" "Ta'izz" "al-Bayda" "al-Hudaydah" "al-Jawf" "al-Mahrah" "al-Mahwit" ]   </div>
[/group]
</div>

<div class="input country">
[group Yugoslavia]
   <div class="selectbox ">
       [select country-region "Select a region" "Central Serbia" "Kosovo and Metohija" "Montenegro" "Republic of Serbia" "Serbia" "Vojvodina"]   </div>
[/group]
</div>

<div class="input country">
[group Zambia]
   <div class="selectbox ">
       [select country-region "Select a region" "Central" "Copperbelt" "Eastern" "Luapala" "Lusaka" "North-Western" "Northern" "Southern" "Western"]   </div>
[/group]
</div>

<div class="input country">
[group Zimbabwe]
   <div class="selectbox ">
       [select country-region "Select a region" "Bulawayo" "Harare" "Manicaland" "Mashonaland Central" "Mashonaland East" "Mashonaland West" "Masvingo" "Matabeleland North" "Matabeleland South" "Midlands"]   </div>
[/group]
</div>
