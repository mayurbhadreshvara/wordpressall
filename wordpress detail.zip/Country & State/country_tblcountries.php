

"Afghanistan" "Albania" "Algeria" "American Samoa" "Andorra" "Angola" "Anguilla" "Antarctica" "Antigua And Barbuda" "Argentina" "Armenia" "Aruba" "Australia" "Austria" "Azerbaijan" "Bahamas The" "Bahrain" "Bangladesh" "Barbados" "Belarus" "Belgium" "Belize" "Benin" "Bermuda" "Bhutan" "Bolivia" "Bosnia and Herzegovina" "Botswana" "Bouvet Island" "Brazil" "British Indian Ocean Territory" "Brunei" "Bulgaria" "Burkina Faso" "Burundi" "Cambodia" "Cameroon" "Canada" "Cape Verde" "Cayman Islands" "Central African Republic" "Chad" "Chile" "China" "Christmas Island" "Cocos (Keeling) Islands" "Colombia" "Comoros" "Republic Of The Congo" "Democratic Republic Of The Congo" "Cook Islands" "Costa Rica" "Cote D'Ivoire (Ivory Coast)" "Croatia (Hrvatska)" "Cuba" "Cyprus" "Czech Republic" "Denmark" "Djibouti" "Dominica" "Dominican Republic" "East Timor" "Ecuador" "Egypt" "El Salvador" "Equatorial Guinea" "Eritrea" "Estonia" "Ethiopia" "External Territories of Australia" "Falkland Islands" "Faroe Islands" "Fiji Islands" "Finland" "France" "French Guiana" "French Polynesia" "French Southern Territories" "Gabon" "Gambia The" "Georgia" "Germany" "Ghana" "Gibraltar" "Greece" "Greenland" "Grenada" "Guadeloupe" "Guam" "Guatemala" "Guernsey and Alderney" "Guinea" "Guinea-Bissau" "Guyana" "Haiti" "Heard and McDonald Islands" "Honduras" "Hong Kong S.A.R." "Hungary" "Iceland" "India" "Indonesia" "Iran" "Iraq" "Ireland" "Israel" "Italy" "Jamaica" "Japan" "Jersey" "Jordan" "Kazakhstan" "Kenya" "Kiribati" "Korea North" "Korea South" "Kuwait" "Kyrgyzstan" "Laos" "Latvia" "Lebanon" "Lesotho" "Liberia" "Libya" "Liechtenstein" "Lithuania" "Luxembourg" "Macau S.A.R." "Macedonia" "Madagascar" "Malawi" "Malaysia" "Maldives" "Mali" "Malta" "Man (Isle of)" "Marshall Islands" "Martinique" "Mauritania" "Mauritius" "Mayotte" "Mexico" "Micronesia" "Moldova" "Monaco" "Mongolia" "Montserrat" "Morocco" "Mozambique" "Myanmar" "Namibia" "Nauru" "Nepal" "Netherlands Antilles" "Netherlands The" "New Caledonia" "New Zealand" "Nicaragua" "Niger" "Nigeria" "Niue" "Norfolk Island" "Northern Mariana Islands" "Norway" "Oman" "Pakistan" "Palau" "Palestinian Territory Occupied" "Panama" "Papua new Guinea" "Paraguay" "Peru" "Philippines" "Pitcairn Island" "Poland" "Portugal" "Puerto Rico" "Qatar" "Reunion" "Romania" "Russia" "Rwanda" "Saint Helena" "Saint Kitts And Nevis" "Saint Lucia" "Saint Pierre and Miquelon" "Saint Vincent And The Grenadines" "Samoa" "San Marino" "Sao Tome and Principe" "Saudi Arabia" "Senegal" "Serbia" "Seychelles" "Sierra Leone" "Singapore" "Slovakia" "Slovenia" "Smaller Territories of the UK" "Solomon Islands" "Somalia" "South Africa" "South Georgia" "South Sudan" "Spain" "Sri Lanka" "Sudan" "Suriname" "Svalbard" "Swaziland" "Sweden" "Switzerland" "Syria" "Taiwan" "Tajikistan" "Tanzania" "Thailand" "Togo" "Tokelau" "Tonga" "Trinidad And Tobago" "Tunisia" "Turkey" "Turkmenistan" "Turks And Caicos Islands" "Tuvalu" "Uganda" "Ukraine" "United Arab Emirates" "United Kingdom" "United States" "United States Minor Outlying Islands" "Uruguay" "Uzbekistan" "Vanuatu" "Vatican City State (Holy See)" "Venezuela" "Vietnam" "Virgin Islands (British)" "Virgin Islands (US)" "Wallis And Futuna Islands" "Western Sahara" "Yemen" "Yugoslavia" "Zambia" "Zimbabwe"









<div class="input country">
    [group Afghanistan]
    <div class="selectbox ">
        [select country-region "Select a region" "Badakhshan" "Badgis" "Baglan" "Balkh" "Bamiyan" "Farah" "Faryab" "Gawr" "Gazni" "Herat" "Hilmand" "Jawzjan" "Kabul" "Kapisa" "Khawst" "Kunar" "Lagman" "Lawghar" "Nangarhar" "Nimruz" "Nuristan" "Paktika" "Paktiya" "Parwan" "Qandahar" "Qunduz" "Samangan" "Sar-e Pul" "Takhar" "Uruzgan" "Wardag" "Zabul"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Albania]
    <div class="selectbox ">
        [select country-region "Select a region" "Berat" "Bulqize" "Delvine" "Devoll" "Dibre" "Durres" "Elbasan" "Fier" "Gjirokaster" "Gramsh" "Has" "Kavaje" "Kolonje" "Korce" "Kruje" "Kucove" "Kukes" "Kurbin" "Lezhe" "Librazhd" "Lushnje" "Mallakaster" "Malsi e Madhe" "Mat" "Mirdite" "Peqin" "Permet" "Pogradec" "Puke" "Sarande" "Shkoder" "Skrapar" "Tepelene" "Tirane" "Tropoje" "Vlore"]
    </div>
    [/group]
</div>


<div class="input country">
    [group Algeria]
    <div class="selectbox ">
        [select country-region "Select a region" "Ayn Daflah" "Ayn Tamushanat" "Adrar" "Algiers" "Annabah" "Bashshar" "Batnah" "Bijayah" "Biskrah" "Blidah" "Buirah" "Bumardas" "Burj Bu Arririj" "Ghalizan" "Ghardayah" "Ilizi" "Jijili" "Jilfah" "Khanshalah" "Masilah" "Midyah" "Milah" "Muaskar" "Mustaghanam" "Naama" "Oran" "Ouargla" "Qalmah" "Qustantinah" "Sakikdah" "Satif" "Sayda'" "Sidi ban-al-'Abbas" "Suq Ahras" "Tamanghasat" "Tibazah" "Tibissah" "Tilimsan" "Tinduf" "Tisamsilt" "Tiyarat" "Tizi Wazu" "Umm-al-Bawaghi" "Wahran" "Warqla" "Wilaya d Alger" "Wilaya de Bejaia" "Wilaya de Constantine" "al-Aghwat" "al-Bayadh" "al-Jaza'ir" "al-Wad" "ash-Shalif" "at-Tarif"]
    </div>
    [/group]
</div>

<div class="input country">
    [group American-Samoa]
    <div class="selectbox ">
        [select country-region "Select a region" "Eastern" "Manu'a" "Swains Island" "Western"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Andorra]
    <div class="selectbox ">
        [select country-region "Select a region" "Andorra la Vella" "Canillo" "Encamp" "La Massana" "Les Escaldes" "Ordino" "Sant Julia de Loria"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Angola]
    <div class="selectbox ">
        [select country-region "Select a region" "Bengo" "Benguela" "Bie" "Cabinda" "Cunene" "Huambo" "Huila" "Kuando-Kubango" "Kwanza Norte" "Kwanza Sul" "Luanda" "Lunda Norte" "Lunda Sul" "Malanje" "Moxico" "Namibe" "Uige" "Zaire"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Anguilla]
    <div class="selectbox ">
        [select country-region "Select a region" "Other Provinces"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Antarctica]
    <div class="selectbox ">
        [select country-region "Select a region" "Sector claimed by Argentina/Ch" "Sector claimed by Argentina/UK" "Sector claimed by Australia" "Sector claimed by France" "Sector claimed by New Zealand" "Sector claimed by Norway" "Unclaimed Sector"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Antigua-And-Barbuda]
    <div class="selectbox ">
        [select country-region "Select a region" "Barbuda" "Saint George" "Saint John" "Saint Mary" "Saint Paul" "Saint Peter" "Saint Philip"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Argentina]
    <div class="selectbox ">
        [select country-region "Select a region" "Buenos Aires" "Catamarca" "Chaco" "Chubut" "Cordoba" "Corrientes" "Distrito Federal" "Entre Rios" "Formosa" "Jujuy" "La Pampa" "La Rioja" "Mendoza" "Misiones" "Neuquen" "Rio Negro" "Salta" "San Juan" "San Luis" "Santa Cruz" "Santa Fe" "Santiago del Estero" "Tierra del Fuego" "Tucuman"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Armenia]
    <div class="selectbox ">
        [select country-region "Select a region" "Aragatsotn" "Ararat" "Armavir" "Gegharkunik" "Kotaik" "Lori" "Shirak" "Stepanakert" "Syunik" "Tavush" "Vayots Dzor" "Yerevan"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Aruba]
    <div class="selectbox ">
        [select country-region "Select a region" "Aruba"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Australia]
    <div class="selectbox ">
        [select country-region "Select a region" "Auckland" "Australian Capital Territory" "Balgowlah" "Balmain" "Bankstown" "Baulkham Hills" "Bonnet Bay" "Camberwell" "Carole Park" "Castle Hill" "Caulfield" "Chatswood" "Cheltenham" "Cherrybrook" "Clayton" "Collingwood" "Frenchs Forest" "Hawthorn" "Jannnali" "Knoxfield" "Melbourne" "New South Wales" "Northern Territory" "Perth" "Queensland" "South Australia" "Tasmania" "Templestowe" "Victoria" "Werribee south" "Western Australia" "Wheeler"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Austria]
    <div class="selectbox ">
        [select country-region "Select a region" "Bundesland Salzburg" "Bundesland Steiermark" "Bundesland Tirol" "Burgenland" "Carinthia" "Karnten" "Liezen" "Lower Austria" "Niederosterreich" "Oberosterreich" "Salzburg" "Schleswig-Holstein" "Steiermark" "Styria" "Tirol" "Upper Austria" "Vorarlberg" "Wien"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Azerbaijan]
    <div class="selectbox ">
        [select country-region "Select a region" "Abseron" "Baki Sahari" "Ganca" "Ganja" "Kalbacar" "Lankaran" "Mil-Qarabax" "Mugan-Salyan" "Nagorni-Qarabax" "Naxcivan" "Priaraks" "Qazax" "Saki" "Sirvan" "Xacmaz"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bahamas-The]
    <div class="selectbox ">
        [select country-region "Select a region" "Abaco" "Acklins Island" "Andros" "Berry Islands" "Biminis" "Cat Island" "Crooked Island" "Eleuthera" "Exuma and Cays" "Grand Bahama" "Inagua Islands" "Long Island" "Mayaguana" "New Providence" "Ragged Island" "Rum Cay" "San Salvador"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bahrain]
    <div class="selectbox ">
        [select country-region "Select a region" "'Isa" "Badiyah" "Hidd" "Jidd Hafs" "Mahama" "Manama" "Sitrah" "al-Manamah" "al-Muharraq" "ar-Rifa'a"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bangladesh]
    <div class="selectbox ">
        [select country-region "Select a region" "Bagar Hat" "Bandarban" "Barguna" "Barisal" "Bhola" "Bogora" "Brahman Bariya" "Chandpur" "Chattagam" "Chittagong Division" "Chuadanga" "Dhaka" "Dinajpur" "Faridpur" "Feni" "Gaybanda" "Gazipur" "Gopalganj" "Habiganj" "Jaipur Hat" "Jamalpur" "Jessor" "Jhalakati" "Jhanaydah" "Khagrachhari" "Khulna" "Kishorganj" "Koks Bazar" "Komilla" "Kurigram" "Kushtiya" "Lakshmipur" "Lalmanir Hat" "Madaripur" "Magura" "Maimansingh" "Manikganj" "Maulvi Bazar" "Meherpur" "Munshiganj" "Naral" "Narayanganj" "Narsingdi" "Nator" "Naugaon" "Nawabganj" "Netrakona" "Nilphamari" "Noakhali" "Pabna" "Panchagarh" "Patuakhali" "Pirojpur" "Rajbari" "Rajshahi" "Rangamati" "Rangpur" "Satkhira" "Shariatpur" "Sherpur" "Silhat" "Sirajganj" "Sunamganj" "Tangayal" "Thakurgaon"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Barbados]
    <div class="selectbox ">
        [select country-region "Select a region" "Christ Church" "Saint Andrew" "Saint George" "Saint James" "Saint John" "Saint Joseph" "Saint Lucy" "Saint Michael" "Saint Peter" "Saint Philip" "Saint Thomas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Belarus]
    <div class="selectbox ">
        [select country-region "Select a region" "Brest" "Homjel'" "Hrodna" "Mahiljow" "Mahilyowskaya Voblasts" "Minsk" "Minskaja Voblasts'" "Petrik" "Vicebsk"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Belgium]
    <div class="selectbox ">
        [select country-region "Select a region" "Antwerpen" "Berchem" "Brabant" "Brabant Wallon" "Brussel" "East Flanders" "Hainaut" "Liege" "Limburg" "Luxembourg" "Namur" "Ontario" "Oost-Vlaanderen" "Provincie Brabant" "Vlaams-Brabant" "Wallonne" "West-Vlaanderen"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Belize]
    <div class="selectbox ">
        [select country-region "Select a region" "Belize" "Cayo" "Corozal" "Orange Walk" "Stann Creek" "Toledo"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Benin]
    <div class="selectbox ">
        [select country-region "Select a region" "Alibori" "Atacora" "Atlantique" "Borgou" "Collines" "Couffo" "Donga" "Littoral" "Mono" "Oueme" "Plateau" "Zou"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bermuda]
    <div class="selectbox ">
        [select country-region "Select a region" "Hamilton" "Saint George"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bhutan]
    <div class="selectbox ">
        [select country-region "Select a region" "Bumthang" "Chhukha" "Chirang" "Daga" "Geylegphug" "Ha" "Lhuntshi" "Mongar" "Pemagatsel" "Punakha" "Rinpung" "Samchi" "Samdrup Jongkhar" "Shemgang" "Tashigang" "Timphu" "Tongsa" "Wangdiphodrang"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bolivia]
    <div class="selectbox ">
        [select country-region "Select a region" "Beni" "Chuquisaca" "Cochabamba" "La Paz" "Oruro" "Pando" "Potosi" "Santa Cruz" "Tarija"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bosnia-and-Herzegovina]
    <div class="selectbox ">
        [select country-region "Select a region" "Federacija Bosna i Hercegovina" "Republika Srpska"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Botswana]
    <div class="selectbox ">
        [select country-region "Select a region" "Central Bobonong" "Central Boteti" "Central Mahalapye" "Central Serowe-Palapye" "Central Tutume" "Chobe" "Francistown" "Gaborone" "Ghanzi" "Jwaneng" "Kgalagadi North" "Kgalagadi South" "Kgatleng" "Kweneng" "Lobatse" "Ngamiland" "Ngwaketse" "North East" "Okavango" "Orapa" "Selibe Phikwe" "South East" "Sowa"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bouvet-Island]
    <div class="selectbox ">
        [select country-region "Select a region" "Bouvet Island"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Brazil]
    <div class="selectbox ">
        [select country-region "Select a region" "Acre" "Alagoas" "Amapa" "Amazonas" "Bahia" "Ceara" "Distrito Federal" "Espirito Santo" "Estado de Sao Paulo" "Goias" "Maranhao" "Mato Grosso" "Mato Grosso do Sul" "Minas Gerais" "Para" "Paraiba" "Parana" "Pernambuco" "Piaui" "Rio Grande do Norte" "Rio Grande do Sul" "Rio de Janeiro" "Rondonia" "Roraima" "Santa Catarina" "Sao Paulo" "Sergipe" "Tocantins"]
    </div>
    [/group]
</div>

<div class="input country">
    [group British-Indian-Ocean-Territory]
    <div class="selectbox ">
        [select country-region "Select a region" "British Indian Ocean Territory"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Brunei]
    <div class="selectbox ">
        [select country-region "Select a region" "Belait" "Brunei-Muara" "Temburong" "Tutong"]
    </div>
    [/group]
</div>


<div class="input country">
    [group Bulgaria]
    <div class="selectbox ">
        [select country-region "Select a region" "Blagoevgrad" "Burgas" "Dobrich" "Gabrovo" "Haskovo" "Jambol" "Kardzhali" "Kjustendil" "Lovech" "Montana" "Oblast Sofiya-Grad" "Pazardzhik" "Pernik" "Pleven" "Plovdiv" "Razgrad" "Ruse" "Shumen" "Silistra" "Sliven" "Smoljan" "Sofija grad" "Sofijska oblast" "Stara Zagora" "Targovishte" "Varna" "Veliko Tarnovo" "Vidin" "Vraca" "Yablaniza"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Burkina-Faso]
    <div class="selectbox ">
        [select country-region "Select a region" "Bale" "Bam" "Bazega" "Bougouriba" "Boulgou" "Boulkiemde" "Comoe" "Ganzourgou" "Gnagna" "Gourma" "Houet" "Ioba" "Kadiogo" "Kenedougou" "Komandjari" "Kompienga" "Kossi" "Kouritenga" "Kourweogo" "Leraba" "Mouhoun" "Nahouri" "Namentenga" "Noumbiel" "Oubritenga" "Oudalan" "Passore" "Poni" "Sanguie" "Sanmatenga" "Seno" "Sissili" "Soum" "Sourou" "Tapoa" "Tuy" "Yatenga" "Zondoma" "Zoundweogo"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Burundi]
    <div class="selectbox ">
        [select country-region "Select a region" "Bubanza" "Bujumbura" "Bururi" "Cankuzo" "Cibitoke" "Gitega" "Karuzi" "Kayanza" "Kirundo" "Makamba" "Muramvya" "Muyinga" "Ngozi" "Rutana" "Ruyigi"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Bangladesh]
    <div class="selectbox ">
        [select country-region "Select a region" "Bagar Hat" "Bandarban" "Barguna" "Barisal" "Bhola" "Bogora" "Brahman Bariya" "Chandpur" "Chattagam" "Chittagong Division" "Chuadanga" "Dhaka" "Dinajpur" "Faridpur" "Feni" "Gaybanda" "Gazipur" "Gopalganj" "Habiganj" "Jaipur Hat" "Jamalpur" "Jessor" "Jhalakati" "Jhanaydah" "Khagrachhari" "Khulna" "Kishorganj" "Koks Bazar" "Komilla" "Kurigram" "Kushtiya" "Lakshmipur" "Lalmanir Hat" "Madaripur" "Magura" "Maimansingh" "Manikganj" "Maulvi Bazar" "Meherpur" "Munshiganj" "Naral" "Narayanganj" "Narsingdi" "Nator" "Naugaon" "Nawabganj" "Netrakona" "Nilphamari" "Noakhali" "Pabna" "Panchagarh" "Patuakhali" "Pirojpur" "Rajbari" "Rajshahi" "Rangamati" "Rangpur" "Satkhira" "Shariatpur" "Sherpur" "Silhat" "Sirajganj" "Sunamganj" "Tangayal" "Thakurgaon"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cameroon]
    <div class="selectbox ">
        [select country-region "Select a region" "Adamaoua" "Centre" "Est" "Littoral" "Nord" "Nord Extreme" "Nordouest" "Ouest" "Sud" "Sudouest"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Canada]
    <div class="selectbox ">
        [select country-region "Select a region" "Alberta" "British Columbia" "Manitoba" "New Brunswick" "Newfoundland and Labrador" "Northwest Territories" "Nova Scotia" "Nunavut" "Ontario" "Prince Edward Island" "Quebec" "Saskatchewan" "Yukon"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cape-Verde]
    <div class="selectbox ">
        [select country-region "Select a region" "Boavista" "Brava" "Fogo" "Maio" "Sal" "Santo Antao" "Sao Nicolau" "Sao Tiago" "Sao Vicente"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cayman-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Grand Cayman"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Central-African-Republic]
    <div class="selectbox ">
        [select country-region "Select a region" "Bamingui-Bangoran" "Bangui" "Basse-Kotto" "Haut-Mbomou" "Haute-Kotto" "Kemo" "Lobaye" "Mambere-Kadei" "Mbomou" "Nana-Gribizi" "Nana-Mambere" "Ombella Mpoko" "Ouaka" "Ouham" "Ouham-Pende" "Sangha-Mbaere" "Vakaga"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Chad]
    <div class="selectbox ">
        [select country-region "Select a region" "Batha" "Biltine" "Bourkou-Ennedi-Tibesti" "Chari-Baguirmi" "Guera" "Kanem" "Lac" "Logone Occidental" "Logone Oriental" "Mayo-Kebbi" "Moyen-Chari" "Ouaddai" "Salamat" "Tandjile"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Chile]
    <div class="selectbox ">
        [select country-region "Select a region" "Aisen" "Antofagasta" "Araucania" "Atacama" "Bio Bio" "Coquimbo" "Libertador General Bernardo O'" "Los Lagos" "Magellanes" "Maule" "Metropolitana" "Metropolitana de Santiago" "Tarapaca" "Valparaiso"]
    </div>
    [/group]
</div>

<div class="input country">
    [group China]
    <div class="selectbox ">
        [select country-region "Select a region" "Anhui" "Aomen" "Beijing" "Beijing Shi" "Chongqing" "Fujian" "Gansu" "Guangdong" "Guangxi" "Guizhou" "Hainan" "Hebei" "Heilongjiang" "Henan" "Hubei" "Hunan" "Jiangsu" "Jiangxi" "Jilin" "Liaoning" "Nei Monggol" "Ningxia Hui" "Qinghai" "Shaanxi" "Shandong" "Shanghai" "Shanxi" "Sichuan" "Tianjin" "Xianggang" "Xinjiang" "Xizang" "Yunnan" "Zhejiang"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Christmas-Island]
    <div class="selectbox ">
        [select country-region "Select a region" "Christmas Island"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cocos-(Keeling)-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Cocos (Keeling) Islands"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Colombia]
    <div class="selectbox ">
        [select country-region "Select a region" "Amazonas" "Antioquia" "Arauca" "Atlantico" "Bogota" "Bolivar" "Boyaca" "Caldas" "Caqueta" "Casanare" "Cauca" "Cesar" "Choco" "Cordoba" "Cundinamarca" "Guainia" "Guaviare" "Huila" "La Guajira" "Magdalena" "Meta" "Narino" "Norte de Santander" "Putumayo" "Quindio" "Risaralda" "San Andres y Providencia" "Santander" "Sucre" "Tolima" "Valle del Cauca" "Vaupes" "Vichada"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Comoros]
    <div class="selectbox ">
        [select country-region "Select a region" "Mwali" "Njazidja" "Nzwani"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Republic-Of-The-Congo]
    <div class="selectbox ">
        [select country-region "Select a region" "Bouenza" "Brazzaville" "Cuvette" "Kouilou" "Lekoumou" "Likouala" "Niari" "Plateaux" "Pool" "Sangha"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cook-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Aitutaki" "Atiu" "Mangaia" "Manihiki" "Mauke" "Mitiaro" "Nassau" "Pukapuka" "Rakahanga" "Rarotonga" "Tongareva"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Costa-Rica]
    <div class="selectbox ">
        [select country-region "Select a region" "Alajuela" "Cartago" "Guanacaste" "Heredia" "Limon" "Puntarenas" "San Jose"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cote-D'Ivoire-(Ivory Coast)]
    <div class="selectbox ">
        [select country-region "Select a region" "Abidjan" "Agneby" "Bafing" "Denguele" "Dix-huit Montagnes" "Fromager" "Haut-Sassandra" "Lacs" "Lagunes" "Marahoue" "Moyen-Cavally" "Moyen-Comoe" "N'zi-Comoe" "Sassandra" "Savanes" "Sud-Bandama" "Sud-Comoe" "Vallee du Bandama" "Worodougou" "Zanzan"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Croatia-(Hrvatska)]
    <div class="selectbox ">
        [select country-region "Select a region" "Bjelovar-Bilogora" "Dubrovnik-Neretva" "Grad Zagreb" "Istra" "Karlovac" "Koprivnica-Krizhevci" "Krapina-Zagorje" "Lika-Senj" "Medhimurje" "Medimurska Zupanija" "Osijek-Baranja" "Osjecko-Baranjska Zupanija" "Pozhega-Slavonija" "Primorje-Gorski Kotar" "Shibenik-Knin" "Sisak-Moslavina" "Slavonski Brod-Posavina" "Split-Dalmacija" "Varazhdin" "Virovitica-Podravina" "Vukovar-Srijem" "Zadar" "Zagreb"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cuba]
    <div class="selectbox ">
        [select country-region "Select a region" "Camaguey" "Ciego de Avila" "Cienfuegos" "Ciudad de la Habana" "Granma" "Guantanamo" "Habana" "Holguin" "Isla de la Juventud" "La Habana" "Las Tunas" "Matanzas" "Pinar del Rio" "Sancti Spiritus" "Santiago de Cuba" "Villa Clara"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cyprus]
    <div class="selectbox ">
        [select country-region "Select a region" "Government controlled area" "Limassol" "Nicosia District" "Paphos" "Turkish controlled area"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Czech-Republic]
    <div class="selectbox ">
        [select country-region "Select a region" "Central Bohemian" "Frycovice" "Jihocesky Kraj" "Jihochesky" "Jihomoravsky" "Karlovarsky" "Klecany" "Kralovehradecky" "Liberecky" "Lipov" "Moravskoslezsky" "Olomoucky" "Olomoucky Kraj" "Pardubicky" "Plzensky" "Praha" "Rajhrad" "Smirice" "South Moravian" "Straz nad Nisou" "Stredochesky" "Unicov" "Ustecky" "Valletta" "Velesin" "Vysochina" "Zlinsky"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Denmark]
    <div class="selectbox ">
        [select country-region "Select a region" "Arhus" "Bornholm" "Frederiksborg" "Fyn" "Hovedstaden" "Kobenhavn" "Kobenhavns Amt" "Kobenhavns Kommune" "Nordjylland" "Ribe" "Ringkobing" "Roervig" "Roskilde" "Roslev" "Sjaelland" "Soeborg" "Sonderjylland" "Storstrom" "Syddanmark" "Toelloese" "Vejle" "Vestsjalland" "Viborg"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Djibouti]
    <div class="selectbox ">
        [select country-region "Select a region" "'Ali Sabih" "Dikhil" "Jibuti" "Tajurah" "Ubuk"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Dominica]
    <div class="selectbox ">
        [select country-region "Select a region" "Saint Andrew" "Saint David" "Saint George" "Saint John" "Saint Joseph" "Saint Luke" "Saint Mark" "Saint Patrick" "Saint Paul" "Saint Peter"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Dominican-Republic]
    <div class="selectbox ">
        [select country-region "Select a region" "Azua" "Bahoruco" "Barahona" "Dajabon" "Distrito Nacional" "Duarte" "El Seybo" "Elias Pina" "Espaillat" "Hato Mayor" "Independencia" "La Altagracia" "La Romana" "La Vega" "Maria Trinidad Sanchez" "Monsenor Nouel" "Monte Cristi" "Monte Plata" "Pedernales" "Peravia" "Puerto Plata" "Salcedo" "Samana" "San Cristobal" "San Juan" "San Pedro de Macoris" "Sanchez Ramirez" "Santiago" "Santiago Rodriguez" "Valverde"]
    </div>
    [/group]
</div>

<div class="input country">
    [group East-Timor]
    <div class="selectbox ">
        [select country-region "Select a region" "Aileu" "Ainaro" "Ambeno" "Baucau" "Bobonaro" "Cova Lima" "Dili" "Ermera" "Lautem" "Liquica" "Manatuto" "Manufahi" "Viqueque"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Ecuador]
    <div class="selectbox ">
        [select country-region "Select a region" "Azuay" "Bolivar" "Canar" "Carchi" "Chimborazo" "Cotopaxi" "El Oro" "Esmeraldas" "Galapagos" "Guayas" "Imbabura" "Loja" "Los Rios" "Manabi" "Morona Santiago" "Napo" "Orellana" "Pastaza" "Pichincha" "Sucumbios" "Tungurahua" "Zamora Chinchipe"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Egypt]
    <div class="selectbox ">
        [select country-region "Select a region" "Aswan" "Asyut" "Bani Suwayf" "Bur Sa'id" "Cairo" "Dumyat" "Kafr-ash-Shaykh" "Matruh" "Muhafazat ad Daqahliyah" "Muhafazat al Fayyum" "Muhafazat al Gharbiyah" "Muhafazat al Iskandariyah" "Muhafazat al Qahirah" "Qina" "Sawhaj" "Sina al-Janubiyah" "Sina ash-Shamaliyah" "ad-Daqahliyah" "al-Bahr-al-Ahmar" "al-Buhayrah" "al-Fayyum" "al-Gharbiyah" "al-Iskandariyah" "al-Ismailiyah" "al-Jizah" "al-Minufiyah" "al-Minya" "al-Qahira" "al-Qalyubiyah" "al-Uqsur" "al-Wadi al-Jadid" "as-Suways" "ash-Sharqiyah"]
    </div>
    [/group]
</div>

<div class="input country">
    [group El-Salvador]
    <div class="selectbox ">
        [select country-region "Select a region" "Ahuachapan" "Cabanas" "Chalatenango" "Cuscatlan" "La Libertad" "La Paz" "La Union" "Morazan" "San Miguel" "San Salvador" "San Vicente" "Santa Ana" "Sonsonate" "Usulutan"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Equatorial-Guinea]
    <div class="selectbox ">
        [select country-region "Select a region" "Annobon" "Bioko Norte" "Bioko Sur" "Centro Sur" "Kie-Ntem" "Litoral" "Wele-Nzas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Eritrea]
    <div class="selectbox ">
        [select country-region "Select a region" "Anseba" "Debub" "Debub-Keih-Bahri" "Gash-Barka" "Maekel" "Semien-Keih-Bahri"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Estonia]
    <div class="selectbox ">
        [select country-region "Select a region" "Harju" "Hiiu" "Ida-Viru" "Jarva" "Jogeva" "Laane" "Laane-Viru" "Parnu" "Polva" "Rapla" "Saare" "Tartu" "Valga" "Viljandi" "Voru"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Ethiopia]
    <div class="selectbox ">
        [select country-region "Select a region" "Addis Abeba" "Afar" "Amhara" "Benishangul" "Diredawa" "Gambella" "Harar" "Jigjiga" "Mekele" "Oromia" "Somali" "Southern" "Tigray"]
    </div>
    [/group]
</div>

<div class="input country">
    [group External-Territories-of-Australia]
    <div class="selectbox ">
        [select country-region "Select a region" "Christmas Island" "Cocos Islands" "Coral Sea Islands"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Falkland-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Falkland Islands" "South Georgia"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Faroe-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Klaksvik" "Nor ara Eysturoy" "Nor oy" "Sandoy" "Streymoy" "Su uroy" "Sy ra Eysturoy" "Torshavn" "Vaga"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Fiji-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Central" "Eastern" "Northern" "South Pacific" "Western"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Finland]
    <div class="selectbox ">
        [select country-region "Select a region" "Ahvenanmaa" "Etela-Karjala" "Etela-Pohjanmaa" "Etela-Savo" "Etela-Suomen Laani" "Ita-Suomen Laani" "Ita-Uusimaa" "Kainuu" "Kanta-Hame" "Keski-Pohjanmaa" "Keski-Suomi" "Kymenlaakso" "Lansi-Suomen Laani" "Lappi" "Northern Savonia" "Ostrobothnia" "Oulun Laani" "Paijat-Hame" "Pirkanmaa" "Pohjanmaa" "Pohjois-Karjala" "Pohjois-Pohjanmaa" "Pohjois-Savo" "Saarijarvi" "Satakunta" "Southern Savonia" "Tavastia Proper" "Uleaborgs Lan" "Uusimaa" "Varsinais-Suomi"]
    </div>
    [/group]
</div>

<div class="input country">
    [group France]
    <div class="selectbox ">
        [select country-region "Select a region" "Ain" "Aisne" "Albi Le Sequestre" "Allier" "Alpes-Cote dAzur" "Alpes-Maritimes" "Alpes-de-Haute-Provence" "Alsace" "Aquitaine" "Ardeche" "Ardennes" "Ariege" "Aube" "Aude" "Auvergne" "Aveyron" "Bas-Rhin" "Basse-Normandie" "Bouches-du-Rhone" "Bourgogne" "Bretagne" "Brittany" "Burgundy" "Calvados" "Cantal" "Cedex" "Centre" "Charente" "Charente-Maritime" "Cher" "Correze" "Corse-du-Sud" "Cote-d'Or" "Cotes-d'Armor" "Creuse" "Crolles" "Deux-Sevres" "Dordogne" "Doubs" "Drome" "Essonne" "Eure" "Eure-et-Loir" "Feucherolles" "Finistere" "Franche-Comte" "Gard" "Gers" "Gironde" "Haut-Rhin" "Haute-Corse" "Haute-Garonne" "Haute-Loire" "Haute-Marne" "Haute-Saone" "Haute-Savoie" "Haute-Vienne" "Hautes-Alpes" "Hautes-Pyrenees" "Hauts-de-Seine" "Herault" "Ile-de-France" "Ille-et-Vilaine" "Indre" "Indre-et-Loire" "Isere" "Jura" "Klagenfurt" "Landes" "Languedoc-Roussillon" "Larcay" "Le Castellet" "Le Creusot" "Limousin" "Loir-et-Cher" "Loire" "Loire-Atlantique" "Loiret" "Lorraine" "Lot" "Lot-et-Garonne" "Lower Normandy" "Lozere"]
    </div>
    [/group]
</div>

<div class="input country">
    [group French-Guiana]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]]
    </div>
    [/group]
</div>

<div class="input country">
    [group French-Polynesia]
    <div class="selectbox ">
        [select country-region "Select a region" "Iles du Vent" "Iles sous le Vent" "Marquesas" "Tuamotu" "Tubuai"]
    </div>
    [/group]
</div>

<div class="input country">
    [group French-Southern-Territories]
    <div class="selectbox ">
        [select country-region "Select a region" "Amsterdam" "Crozet Islands" "Kerguelen"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Gabon]
    <div class="selectbox ">
        [select country-region "Select a region" "Estuaire" "Haut-Ogooue" "Moyen-Ogooue" "Ngounie" "Nyanga" "Ogooue-Ivindo" "Ogooue-Lolo" "Ogooue-Maritime" "Woleu-Ntem"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Gambia-The]
    <div class="selectbox ">
        [select country-region "Select a region" "Banjul" "Basse" "Brikama" "Janjanbureh" "Kanifing" "Kerewan" "Kuntaur" "Mansakonko"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Georgia]
    <div class="selectbox ">
        [select country-region "Select a region" "Abhasia" "Ajaria" "Guria" "Imereti" "Kaheti" "Kvemo Kartli" "Mcheta-Mtianeti" "Racha" "Samagrelo-Zemo Svaneti" "Samche-Zhavaheti" "Shida Kartli" "Tbilisi"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Germany]
    <div class="selectbox ">
        [select country-region "Select a region" "Auvergne" "Baden-Wurttemberg" "Bavaria" "Bayern" "Beilstein Wurtt" "Berlin" "Brandenburg" "Bremen" "Dreisbach" "Freistaat Bayern" "Hamburg" "Hannover" "Heroldstatt" "Hessen" "Kortenberg" "Laasdorf" "Land Baden-Wurttemberg" "Land Bayern" "Land Brandenburg" "Land Hessen" "Land Mecklenburg-Vorpommern" "Land Nordrhein-Westfalen" "Land Rheinland-Pfalz" "Land Sachsen" "Land Sachsen-Anhalt" "Land Thuringen" "Lower Saxony" "Mecklenburg-Vorpommern" "Mulfingen" "Munich" "Neubeuern" "Niedersachsen" "Noord-Holland" "Nordrhein-Westfalen" "North Rhine-Westphalia" "Osterode" "Rheinland-Pfalz" "Rhineland-Palatinate" "Saarland" "Sachsen" "Sachsen-Anhalt" "Saxony" "Schleswig-Holstein" "Thuringia" "Webling" "Weinstrabe" "schlobborn"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Ghana]
    <div class="selectbox ">
        [select country-region "Select a region" "Ashanti" "Brong-Ahafo" "Central" "Eastern" "Greater Accra" "Northern" "Upper East" "Upper West" "Volta" "Western"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Gibraltar]
    <div class="selectbox ">
        [select country-region "Select a region" "Gibraltar"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Greece]
    <div class="selectbox ">
        [select country-region "Select a region" "Acharnes" "Ahaia" "Aitolia kai Akarnania" "Argolis" "Arkadia" "Arta" "Attica" "Attiki" "Ayion Oros" "Crete" "Dodekanisos" "Drama" "Evia" "Evritania" "Evros" "Evvoia" "Florina" "Fokis" "Fthiotis" "Grevena" "Halandri" "Halkidiki" "Hania" "Heraklion" "Hios" "Ilia" "Imathia" "Ioannina" "Iraklion" "Karditsa" "Kastoria" "Kavala" "Kefallinia" "Kerkira" "Kiklades" "Kilkis" "Korinthia" "Kozani" "Lakonia" "Larisa" "Lasithi" "Lesvos" "Levkas" "Magnisia" "Messinia" "Nomos Attikis" "Nomos Zakynthou" "Pella" "Pieria" "Piraios" "Preveza" "Rethimni" "Rodopi" "Samos" "Serrai" "Thesprotia" "Thessaloniki" "Trikala" "Voiotia" "West Greece" "Xanthi" "Zakinthos"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Greenland]
    <div class="selectbox ">
        [select country-region "Select a region" "Aasiaat" "Ammassalik" "Illoqqortoormiut" "Ilulissat" "Ivittuut" "Kangaatsiaq" "Maniitsoq" "Nanortalik" "Narsaq" "Nuuk" "Paamiut" "Qaanaaq" "Qaqortoq" "Qasigiannguit" "Qeqertarsuaq" "Sisimiut" "Udenfor kommunal inddeling" "Upernavik" "Uummannaq"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Grenada]
    <div class="selectbox ">
        [select country-region "Select a region" "Carriacou-Petite Martinique" "Saint Andrew" "Saint Davids" "Saint George's" "Saint John" "Saint Mark" "Saint Patrick"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Guadeloupe]
    <div class="selectbox ">
        [select country-region "Select a region" "Basse-Terre" "Grande-Terre" "Iles des Saintes" "La Desirade" "Marie-Galante" "Saint Barthelemy" "Saint Martin"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Guam]
    <div class="selectbox ">
        [select country-region "Select a region" "Agana Heights" "Agat" "Barrigada" "Chalan-Pago-Ordot" "Dededo" "Hagatna" "Inarajan" "Mangilao" "Merizo" "Mongmong-Toto-Maite" "Santa Rita" "Sinajana" "Talofofo" "Tamuning" "Yigo" "Yona"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Guatemala]
    <div class="selectbox ">
        [select country-region "Select a region" "Alta Verapaz" "Baja Verapaz" "Chimaltenango" "Chiquimula" "El Progreso" "Escuintla" "Guatemala" "Huehuetenango" "Izabal" "Jalapa" "Jutiapa" "Peten" "Quezaltenango" "Quiche" "Retalhuleu" "Sacatepequez" "San Marcos" "Santa Rosa" "Solola" "Suchitepequez" "Totonicapan" "Zacapa"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Guernsey-and-Alderney]
    <div class="selectbox ">
        [select country-region "Select a region" "Alderney" "Castel" "Forest" "Saint Andrew" "Saint Martin" "Saint Peter Port" "Saint Pierre du Bois" "Saint Sampson" "Saint Saviour" "Sark" "Torteval" "Vale"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Guinea]
    <div class="selectbox ">
        [select country-region "Select a region" "Beyla" "Boffa" "Boke" "Conakry" "Coyah" "Dabola" "Dalaba" "Dinguiraye" "Faranah" "Forecariah" "Fria" "Gaoual" "Gueckedou" "Kankan" "Kerouane" "Kindia" "Kissidougou" "Koubia" "Koundara" "Kouroussa" "Labe" "Lola" "Macenta" "Mali" "Mamou" "Mandiana" "Nzerekore" "Pita" "Siguiri" "Telimele" "Tougue" "Yomou"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Guinea-Bissau]
    <div class="selectbox ">
        [select country-region "Select a region" "Bafata" "Bissau" "Bolama" "Cacheu" "Gabu" "Oio" "Quinara" "Tombali"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Guyana]
    <div class="selectbox ">
        [select country-region "Select a region" "Barima-Waini" "Cuyuni-Mazaruni" "Demerara-Mahaica" "East Berbice-Corentyne" "Essequibo Islands-West Demerar" "Mahaica-Berbice" "Pomeroon-Supenaam" "Potaro-Siparuni" "Upper Demerara-Berbice" "Upper Takutu-Upper Essequibo"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Haiti]
    <div class="selectbox ">
        [select country-region "Select a region" "Artibonite" "Centre" "Grand'Anse" "Nord" "Nord-Est" "Nord-Ouest" "Ouest" "Sud" "Sud-Est"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Heard-and-McDonald-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Heard and McDonald Islands"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Honduras]
    <div class="selectbox ">
        [select country-region "Select a region" "Atlantida" "Choluteca" "Colon" "Comayagua" "Copan" "Cortes" "Distrito Central" "El Paraiso" "Francisco Morazan" "Gracias a Dios" "Intibuca" "Islas de la Bahia" "La Paz" "Lempira" "Ocotepeque" "Olancho" "Santa Barbara" "Valle" "Yoro"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Hong-Kong-S.A.R.]
    <div class="selectbox ">
        [select country-region "Select a region" "Hong Kong"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Hungary]
    <div class="selectbox ">
        [select country-region "Select a region" "Bacs-Kiskun" "Baranya" "Bekes" "Borsod-Abauj-Zemplen" "Budapest" "Csongrad" "Fejer" "Gyor-Moson-Sopron" "Hajdu-Bihar" "Heves" "Jasz-Nagykun-Szolnok" "Komarom-Esztergom" "Nograd" "Pest" "Somogy" "Szabolcs-Szatmar-Bereg" "Tolna" "Vas" "Veszprem" "Zala"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Iceland]
    <div class="selectbox ">
        [select country-region "Select a region" "Austurland" "Gullbringusysla" "Hofu borgarsva i" "Nor urland eystra" "Nor urland vestra" "Su urland" "Su urnes" "Vestfir ir" "Vesturland"]
    </div>
    [/group]
</div>

<div class="input country">
    [group India]
    <div class="selectbox ">
        [select country-region "Select a region" "Andaman and Nicobar Islands" "Andhra Pradesh" "Arunachal Pradesh" "Assam" "Bihar" "Chandigarh" "Chhattisgarh" "Dadra and Nagar Haveli" "Daman and Diu" "Delhi" "Goa" "Gujarat" "Haryana" "Himachal Pradesh" "Jammu and Kashmir" "Jharkhand" "Karnataka" "Kenmore" "Kerala" "Lakshadweep" "Madhya Pradesh" "Maharashtra" "Manipur" "Meghalaya" "Mizoram" "Nagaland" "Narora" "Natwar" "Odisha" "Paschim Medinipur" "Pondicherry" "Punjab" "Rajasthan" "Sikkim" "Tamil Nadu" "Telangana" "Tripura" "Uttar Pradesh" "Uttarakhand" "Vaishali" "West Bengal"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Indonesia]
    <div class="selectbox ">
        [select country-region "Select a region" "Aceh" "Bali" "Bangka-Belitung" "Banten" "Bengkulu" "Gandaria" "Gorontalo" "Jakarta" "Jambi" "Jawa Barat" "Jawa Tengah" "Jawa Timur" "Kalimantan Barat" "Kalimantan Selatan" "Kalimantan Tengah" "Kalimantan Timur" "Kendal" "Lampung" "Maluku" "Maluku Utara" "Nusa Tenggara Barat" "Nusa Tenggara Timur" "Papua" "Riau" "Riau Kepulauan" "Solo" "Sulawesi Selatan" "Sulawesi Tengah" "Sulawesi Tenggara" "Sulawesi Utara" "Sumatera Barat" "Sumatera Selatan" "Sumatera Utara" "Yogyakarta"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Iran]
    <div class="selectbox ">
        [select country-region "Select a region" "Ardabil" "Azarbayjan-e Bakhtari" "Azarbayjan-e Khavari" "Bushehr" "Chahar Mahal-e Bakhtiari" "Esfahan" "Fars" "Gilan" "Golestan" "Hamadan" "Hormozgan" "Ilam" "Kerman" "Kermanshah" "Khorasan" "Khuzestan" "Kohgiluyeh-e Boyerahmad" "Kordestan" "Lorestan" "Markazi" "Mazandaran" "Ostan-e Esfahan" "Qazvin" "Qom" "Semnan" "Sistan-e Baluchestan" "Tehran" "Yazd" "Zanjan"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Iraq]
    <div class="selectbox ">
        [select country-region "Select a region" "Babil" "Baghdad" "Dahuk" "Dhi Qar" "Diyala" "Erbil" "Irbil" "Karbala" "Kurdistan" "Maysan" "Ninawa" "Salah-ad-Din" "Wasit" "al-Anbar" "al-Basrah" "al-Muthanna" "al-Qadisiyah" "an-Najaf" "as-Sulaymaniyah" "at-Ta'mim"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Ireland]
    <div class="selectbox ">
        [select country-region "Select a region" "Armagh" "Carlow" "Cavan" "Clare" "Cork" "Donegal" "Dublin" "Galway" "Kerry" "Kildare" "Kilkenny" "Laois" "Leinster" "Leitrim" "Limerick" "Loch Garman" "Longford" "Louth" "Mayo" "Meath" "Monaghan" "Offaly" "Roscommon" "Sligo" "Tipperary North Riding" "Tipperary South Riding" "Ulster" "Waterford" "Westmeath" "Wexford" "Wicklow"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Israel]
    <div class="selectbox ">
        [select country-region "Select a region" "Beit Hanania" "Ben Gurion Airport" "Bethlehem" "Caesarea" "Centre" "Gaza" "Hadaron" "Haifa District" "Hamerkaz" "Hazafon" "Hebron" "Jaffa" "Jerusalem" "Khefa" "Kiryat Yam" "Lower Galilee" "Qalqilya" "Talme Elazar" "Tel Aviv" "Tsafon" "Umm El Fahem" "Yerushalayim"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Italy]
    <div class="selectbox ">
        [select country-region "Select a region" "Abruzzi" "Abruzzo" "Agrigento" "Alessandria" "Ancona" "Arezzo" "Ascoli Piceno" "Asti" "Avellino" "Bari" "Basilicata" "Belluno" "Benevento" "Bergamo" "Biella" "Bologna" "Bolzano" "Brescia" "Brindisi" "Calabria" "Campania" "Cartoceto" "Caserta" "Catania" "Chieti" "Como" "Cosenza" "Cremona" "Cuneo" "Emilia-Romagna" "Ferrara" "Firenze" "Florence" "Forli-Cesena " "Friuli-Venezia Giulia" "Frosinone" "Genoa" "Gorizia" "L'Aquila" "Lazio" "Lecce" "Lecco" "Liguria" "Lodi" "Lombardia" "Lombardy" "Macerata" "Mantova" "Marche" "Messina" "Milan" "Modena" "Molise" "Molteno" "Montenegro" "Monza and Brianza" "Naples" "Novara" "Padova" "Parma" "Pavia" "Perugia" "Pesaro-Urbino" "Piacenza" "Piedmont" "Piemonte" "Pisa" "Pordenone" "Potenza" "Puglia" "Reggio Emilia" "Rimini" "Roma" "Salerno" "Sardegna" "Sassari" "Savona" "Sicilia" "Siena" "Sondrio" "South Tyrol" "Taranto" "Teramo" "Torino" "Toscana" "Trapani" "Trentino-Alto Adige" "Trento" "Treviso" "Udine" "Umbria" "Valle d'Aosta" "Varese" "Veneto" "Venezia" "Verbano-Cusio-Ossol"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Jamaica]
    <div class="selectbox ">
        [select country-region "Select a region" "Buxoro Viloyati" "Clarendon" "Hanover" "Kingston" "Manchester" "Portland" "Saint Andrews" "Saint Ann" "Saint Catherine" "Saint Elizabeth" "Saint James" "Saint Mary" "Saint Thomas" "Trelawney" "Westmoreland"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Japan]
    <div class="selectbox ">
        [select country-region "Select a region" "Aichi" "Akita" "Aomori" "Chiba" "Ehime" "Fukui" "Fukuoka" "Fukushima" "Gifu" "Gumma" "Hiroshima" "Hokkaido" "Hyogo" "Ibaraki" "Ishikawa" "Iwate" "Kagawa" "Kagoshima" "Kanagawa" "Kanto" "Kochi" "Kumamoto" "Kyoto" "Mie" "Miyagi" "Miyazaki" "Nagano" "Nagasaki" "Nara" "Niigata" "Oita" "Okayama" "Okinawa" "Osaka" "Saga" "Saitama" "Shiga" "Shimane" "Shizuoka" "Tochigi" "Tokushima" "Tokyo" "Tottori" "Toyama" "Wakayama" "Yamagata" "Yamaguchi" "Yamanashi"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Jersey]
    <div class="selectbox ">
        [select country-region "Select a region" "Grouville" "Saint Brelade" "Saint Clement" "Saint Helier" "Saint John" "Saint Lawrence" "Saint Martin" "Saint Mary" "Saint Peter" "Saint Saviour" "Trinity"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Jordan]
    <div class="selectbox ">
        [select country-region "Select a region" "'Ajlun" "Amman" "Irbid" "Jarash" "Ma'an" "Madaba" "al-'Aqabah" "al-Balqa'" "al-Karak" "al-Mafraq" "at-Tafilah" "az-Zarqa'"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Kazakhstan]
    <div class="selectbox ">
        [select country-region "Select a region" "Akmecet" "Akmola" "Aktobe" "Almati" "Atirau" "Batis Kazakstan" "Burlinsky Region" "Karagandi" "Kostanay" "Mankistau" "Ontustik Kazakstan" "Pavlodar" "Sigis Kazakstan" "Soltustik Kazakstan" "Taraz"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Kenya]
    <div class="selectbox ">
        [select country-region "Select a region" "Central" "Coast" "Eastern" "Nairobi" "North Eastern" "Nyanza" "Rift Valley" "Western"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Kiribati]
    <div class="selectbox ">
        [select country-region "Select a region" "Abaiang" "Abemana" "Aranuka" "Arorae" "Banaba" "Beru" "Butaritari" "Kiritimati" "Kuria" "Maiana" "Makin" "Marakei" "Nikunau" "Nonouti" "Onotoa" "Phoenix Islands" "Tabiteuea North" "Tabiteuea South" "Tabuaeran" "Tamana" "Tarawa North" "Tarawa South" "Teraina"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Korea-North]
    <div class="selectbox ">
        [select country-region "Select a region" "Chagangdo" "Hamgyeongbukto" "Hamgyeongnamdo" "Hwanghaebukto" "Hwanghaenamdo" "Kaeseong" "Kangweon" "Nampo" "Pyeonganbukto" "Pyeongannamdo" "Pyeongyang" "Yanggang"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Korea-South]
    <div class="selectbox ">
        [select country-region "Select a region" "Busan" "Cheju" "Chollabuk" "Chollanam" "Chungbuk" "Chungcheongbuk" "Chungcheongnam" "Chungnam" "Daegu" "Gangwon-do" "Goyang-si" "Gyeonggi-do" "Gyeongsang " "Gyeongsangnam-do" "Incheon" "Jeju-Si" "Jeonbuk" "Kangweon" "Kwangju" "Kyeonggi" "Kyeongsangbuk" "Kyeongsangnam" "Kyonggi-do" "Kyungbuk-Do" "Kyunggi-Do" "Kyunggi-do" "Pusan" "Seoul" "Sudogwon" "Taegu" "Taejeon" "Taejon-gwangyoksi" "Ulsan" "Wonju" "gwangyoksi"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Kuwait]
    <div class="selectbox ">
        [select country-region "Select a region" "Al Asimah" "Hawalli" "Mishref" "Qadesiya" "Safat" "Salmiya" "al-Ahmadi" "al-Farwaniyah" "al-Jahra" "al-Kuwayt"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Kyrgyzstan]
    <div class="selectbox ">
        [select country-region "Select a region" "Batken" "Bishkek" "Chui" "Issyk-Kul" "Jalal-Abad" "Naryn" "Osh" "Talas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Laos]
    <div class="selectbox ">
        [select country-region "Select a region" "Attopu" "Bokeo" "Bolikhamsay" "Champasak" "Houaphanh" "Khammouane" "Luang Nam Tha" "Luang Prabang" "Oudomxay" "Phongsaly" "Saravan" "Savannakhet" "Sekong" "Viangchan Prefecture" "Viangchan Province" "Xaignabury" "Xiang Khuang"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Latvia]
    <div class="selectbox ">
        [select country-region "Select a region" "Aizkraukles" "Aluksnes" "Balvu" "Bauskas" "Cesu" "Daugavpils" "Daugavpils City" "Dobeles" "Gulbenes" "Jekabspils" "Jelgava" "Jelgavas" "Jurmala City" "Kraslavas" "Kuldigas" "Liepaja" "Liepajas" "Limbazhu" "Ludzas" "Madonas" "Ogres" "Preilu" "Rezekne" "Rezeknes" "Riga" "Rigas" "Saldus" "Talsu" "Tukuma" "Valkas" "Valmieras" "Ventspils" "Ventspils City"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Lebanon]
    <div class="selectbox ">
        [select country-region "Select a region" "Beirut" "Jabal Lubnan" "Mohafazat Liban-Nord" "Mohafazat Mont-Liban" "Sidon" "al-Biqa" "al-Janub" "an-Nabatiyah" "ash-Shamal"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Lesotho]
    <div class="selectbox ">
        [select country-region "Select a region" "Berea" "Butha-Buthe" "Leribe" "Mafeteng" "Maseru" "Mohale's Hoek" "Mokhotlong" "Qacha's Nek" "Quthing" "Thaba-Tseka"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Liberia]
    <div class="selectbox ">
        [select country-region "Select a region" "Bomi" "Bong" "Grand Bassa" "Grand Cape Mount" "Grand Gedeh" "Loffa" "Margibi" "Maryland and Grand Kru" "Montserrado" "Nimba" "Rivercess" "Sinoe"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Libya]
    <div class="selectbox ">
        [select country-region "Select a region" "Ajdabiya" "Fezzan" "Banghazi" "Darnah" "Ghadamis" "Gharyan" "Misratah" "Murzuq" "Sabha" "Sawfajjin" "Surt" "Tarabulus" "Tarhunah" "Tripolitania" "Tubruq" "Yafran" "Zlitan" "al-'Aziziyah" "al-Fatih" "al-Jabal al Akhdar" "al-Jufrah" "al-Khums" "al-Kufrah" "an-Nuqat al-Khams" "ash-Shati'" "az-Zawiyah"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Liechtenstein]
    <div class="selectbox ">
        [select country-region "Select a region" "Balzers" "Eschen" "Gamprin" "Mauren" "Planken" "Ruggell" "Schaan" "Schellenberg" "Triesen" "Triesenberg" "Vaduz"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Lithuania]
    <div class="selectbox ">
        [select country-region "Select a region" "Alytaus" "Anyksciai" "Kauno" "Klaipedos" "Marijampoles" "Panevezhio" "Panevezys" "Shiauliu" "Taurages" "Telshiu" "Telsiai" "Utenos" "Vilniaus"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Luxembourg]
    <div class="selectbox ">
        [select country-region "Select a region" "Capellen" "Clervaux" "Diekirch" "Echternach" "Esch-sur-Alzette" "Grevenmacher" "Luxembourg" "Mersch" "Redange" "Remich" "Vianden" "Wiltz"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Macau-S.A.R.]
    <div class="selectbox ">
        [select country-region "Select a region" "Macau"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Macedonia]
    <div class="selectbox ">
        [select country-region "Select a region" "Berovo" "Bitola" "Brod" "Debar" "Delchevo" "Demir Hisar" "Gevgelija" "Gostivar" "Kavadarci" "Kichevo" "Kochani" "Kratovo" "Kriva Palanka" "Krushevo" "Kumanovo" "Negotino" "Ohrid" "Prilep" "Probishtip" "Radovish" "Resen" "Shtip" "Skopje" "Struga" "Strumica" "Sveti Nikole" "Tetovo" "Valandovo" "Veles" "Vinica"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Madagascar]
    <div class="selectbox ">
        [select country-region "Select a region" "Antananarivo" "Antsiranana" "Fianarantsoa" "Mahajanga" "Toamasina" "Toliary"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Malawi]
    <div class="selectbox ">
        [select country-region "Select a region" "Balaka" "Blantyre City" "Chikwawa" "Chiradzulu" "Chitipa" "Dedza" "Dowa" "Karonga" "Kasungu" "Lilongwe City" "Machinga" "Mangochi" "Mchinji" "Mulanje" "Mwanza" "Mzimba" "Mzuzu City" "Nkhata Bay" "Nkhotakota" "Nsanje" "Ntcheu" "Ntchisi" "Phalombe" "Rumphi" "Salima" "Thyolo" "Zomba Municipality"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Malaysia]
    <div class="selectbox ">
        [select country-region "Select a region" "Johor" "Kedah" "Kelantan" "Kuala Lumpur" "Labuan" "Melaka" "Negeri Johor" "Negeri Sembilan" "Pahang" "Penang" "Perak" "Perlis" "Pulau Pinang" "Sabah" "Sarawak" "Selangor" "Sembilan" "Terengganu"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Maldives]
    <div class="selectbox ">
        [select country-region "Select a region" "Alif Alif" "Alif Dhaal" "Baa" "Dhaal" "Faaf" "Gaaf Alif" "Gaaf Dhaal" "Ghaviyani" "Haa Alif" "Haa Dhaal" "Kaaf" "Laam" "Lhaviyani" "Male" "Miim" "Nuun" "Raa" "Shaviyani" "Siin" "Thaa" "Vaav"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Mali]
    <div class="selectbox ">
        [select country-region "Select a region" "Bamako" "Gao" "Kayes" "Kidal" "Koulikoro" "Mopti" "Segou" "Sikasso" "Tombouctou"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Malta]
    <div class="selectbox ">
        [select country-region "Select a region" "Gozo and Comino" "Inner Harbour" "Northern" "Outer Harbour" "South Eastern" "Valletta" "Western"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Man-(Isle of)]
    <div class="selectbox ">
        [select country-region "Select a region" "Castletown" "Douglas" "Laxey" "Onchan" "Peel" "Port Erin" "Port Saint Mary" "Ramsey"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Marshall Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Ailinlaplap" "Ailuk" "Arno" "Aur" "Bikini" "Ebon" "Enewetak" "Jabat" "Jaluit" "Kili" "Kwajalein" "Lae" "Lib" "Likiep" "Majuro" "Maloelap" "Mejit" "Mili" "Namorik" "Namu" "Rongelap" "Ujae" "Utrik" "Wotho" "Wotje"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Martinique]
    <div class="selectbox ">
        [select country-region "Select a region" "Fort-de-France" "La Trinite" "Le Marin" "Saint-Pierre"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Mauritania]
    <div class="selectbox ">
        [select country-region "Select a region" "Adrar" "Assaba" "Brakna" "Dhakhlat Nawadibu" "Hudh-al-Gharbi" "Hudh-ash-Sharqi" "Inshiri" "Nawakshut" "Qidimagha" "Qurqul" "Taqant" "Tiris Zammur" "Trarza"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Mauritius]
    <div class="selectbox ">
        [select country-region "Select a region" "Black River" "Eau Coulee" "Flacq" "Floreal" "Grand Port" "Moka" "Pamplempousses" "Plaines Wilhelm" "Port Louis" "Riviere du Rempart" "Rodrigues" "Rose Hill" "Savanne"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Mayotte]
    <div class="selectbox ">
        [select country-region "Select a region" "Mayotte" "Pamanzi"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Mexico]
    <div class="selectbox ">
        [select country-region "Select a region" "Aguascalientes" "Baja California" "Baja California Sur" "Campeche" "Chiapas" "Chihuahua" "Coahuila" "Colima" "Distrito Federal" "Durango" "Estado de Mexico" "Guanajuato" "Guerrero" "Hidalgo" "Jalisco" "Mexico" "Michoacan" "Morelos" "Nayarit" "Nuevo Leon" "Oaxaca" "Puebla" "Queretaro" "Quintana Roo" "San Luis Potosi" "Sinaloa" "Sonora" "Tabasco" "Tamaulipas" "Tlaxcala" "Veracruz" "Yucatan" "Zacatecas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Micronesia]
    <div class="selectbox ">
        [select country-region "Select a region" "Chuuk" "Kusaie" "Pohnpei" "Yap"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Moldova]
    <div class="selectbox ">
        [select country-region "Select a region" "Balti" "Cahul" "Chisinau" "Chisinau Oras" "Edinet" "Gagauzia" "Lapusna" "Orhei" "Soroca" "Taraclia" "Tighina" "Transnistria" "Ungheni"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Monaco]
    <div class="selectbox ">
        [select country-region "Select a region" "Fontvieille" "La Condamine" "Monaco-Ville" "Monte Carlo"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Mongolia]
    <div class="selectbox ">
        [select country-region "Select a region" "Arhangaj" "Bajan-Olgij" "Bajanhongor" "Bulgan" "Darhan-Uul" "Dornod" "Dornogovi" "Dundgovi" "Govi-Altaj" "Govisumber" "Hentij" "Hovd" "Hovsgol" "Omnogovi" "Orhon" "Ovorhangaj" "Selenge" "Suhbaatar" "Tov" "Ulaanbaatar" "Uvs" "Zavhan"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Montserrat]
    <div class="selectbox ">
        [select country-region "Select a region" "Montserrat"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Morocco]
    <div class="selectbox ">
        [select country-region "Select a region" "Agadir" "Casablanca" "Chaouia-Ouardigha" "Doukkala-Abda" "Fes-Boulemane" "Gharb-Chrarda-Beni Hssen" "Guelmim" "Kenitra" "Marrakech-Tensift-Al Haouz" "Meknes-Tafilalet" "Oriental" "Oujda" "Province de Tanger" "Rabat-Sale-Zammour-Zaer" "Sala Al Jadida" "Settat" "Souss Massa-Draa" "Tadla-Azilal" "Tangier-Tetouan" "Taza-Al Hoceima-Taounate" "Wilaya de Casablanca" "Wilaya de Rabat-Sale"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Mozambique]
    <div class="selectbox ">
        [select country-region "Select a region" "Cabo Delgado" "Gaza" "Inhambane" "Manica" "Maputo" "Maputo Provincia" "Nampula" "Niassa" "Sofala" "Tete" "Zambezia"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Myanmar]
    <div class="selectbox ">
        [select country-region "Select a region" "Ayeyarwady" "Bago" "Chin" "Kachin" "Kayah" "Kayin" "Magway" "Mandalay" "Mon" "Nay Pyi Taw" "Rakhine" "Sagaing" "Shan" "Tanintharyi" "Yangon"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Namibia]
    <div class="selectbox ">
        [select country-region "Select a region" "Caprivi" "Erongo" "Hardap" "Karas" "Kavango" "Khomas" "Kunene" "Ohangwena" "Omaheke" "Omusati" "Oshana" "Oshikoto" "Otjozondjupa"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Nauru]
    <div class="selectbox ">
        [select country-region "Select a region" "Yaren"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Nepal]
    <div class="selectbox ">
        [select country-region "Select a region" "Bagmati" "Bheri" "Dhawalagiri" "Gandaki" "Janakpur" "Karnali" "Koshi" "Lumbini" "Mahakali" "Mechi" "Narayani" "Rapti" "Sagarmatha" "Seti"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Netherlands-Antilles]
    <div class="selectbox ">
        [select country-region "Select a region" "Bonaire" "Curacao" "Saba" "Sint Eustatius" "Sint Maarten"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Netherlands-The]
    <div class="selectbox ">
        [select country-region "Select a region" "Amsterdam" "Benelux" "Drenthe" "Flevoland" "Friesland" "Gelderland" "Groningen" "Limburg" "Noord-Brabant" "Noord-Holland" "Overijssel" "South Holland" "Utrecht" "Zeeland" "Zuid-Holland"]
    </div>
    [/group]
</div>

<div class="input country">
    [group New-Caledonia]
    <div class="selectbox ">
        [select country-region "Select a region" "Iles" "Nord" "Sud"]
    </div>
    [/group]
</div>

<div class="input country">
    [group New-Zealand]
    <div class="selectbox ">
        [select country-region "Select a region" "Area Outside Region" "Auckland" "Bay of Plenty" "Canterbury" "Christchurch" "Gisborne" "Hawke's Bay" "Manawatu-Wanganui" "Marlborough" "Nelson" "Northland" "Otago" "Rodney" "Southland" "Taranaki" "Tasman" "Waikato" "Wellington" "West Coast"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Nicaragua]
    <div class="selectbox ">
        [select country-region "Select a region" "Atlantico Norte" "Atlantico Sur" "Boaco" "Carazo" "Chinandega" "Chontales" "Esteli" "Granada" "Jinotega" "Leon" "Madriz" "Managua" "Masaya" "Matagalpa" "Nueva Segovia" "Rio San Juan" "Rivas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Niger]
    <div class="selectbox ">
        [select country-region "Select a region" "Agadez" "Diffa" "Dosso" "Maradi" "Niamey" "Tahoua" "Tillabery" "Zinder"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Nigeria]
    <div class="selectbox ">
        [select country-region "Select a region" "Abia" "Abuja Federal Capital Territor" "Adamawa" "Akwa Ibom" "Anambra" "Bauchi" "Bayelsa" "Benue" "Borno" "Cross River" "Delta" "Ebonyi" "Edo" "Ekiti" "Enugu" "Gombe" "Imo" "Jigawa" "Kaduna" "Kano" "Katsina" "Kebbi" "Kogi" "Kwara" "Lagos" "Nassarawa" "Niger" "Ogun" "Ondo" "Osun" "Oyo" "Plateau" "Rivers" "Sokoto" "Taraba" "Yobe" "Zamfara"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Niue]
    <div class="selectbox ">
        [select country-region "Select a region" "Niue"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Norfolk-Island]
    <div class="selectbox ">
        [select country-region "Select a region" "Norfolk Island"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Northern-Mariana-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Northern Islands" "Rota" "Saipan" "Tinian"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Norway]
    <div class="selectbox ">
        [select country-region "Select a region" "Akershus" "Aust Agder" "Bergen" "Buskerud" "Finnmark" "Hedmark" "Hordaland" "Moere og Romsdal" "Nord Trondelag" "Nordland" "Oestfold" "Oppland" "Oslo" "Rogaland" "Soer Troendelag" "Sogn og Fjordane" "Stavern" "Sykkylven" "Telemark" "Troms" "Vest Agder" "Vestfold" "Ãstfold"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Oman]
    <div class="selectbox ">
        [select country-region "Select a region" "Al Buraimi" "Dhufar" "Masqat" "Musandam" "Rusayl" "Wadi Kabir" "ad-Dakhiliyah" "adh-Dhahirah" "al-Batinah" "ash-Sharqiyah"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Pakistan]
    <div class="selectbox ">
        [select country-region "Select a region" "Baluchistan" "Federal Capital Area" "Federally administered Tribal " "North-West Frontier" "Northern Areas" "Punjab" "Sind"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Palau]
    <div class="selectbox ">
        [select country-region "Select a region" "Aimeliik" "Airai" "Angaur" "Hatobohei" "Kayangel" "Koror" "Melekeok" "Ngaraard" "Ngardmau" "Ngaremlengui" "Ngatpang" "Ngchesar" "Ngerchelong" "Ngiwal" "Peleliu" "Sonsorol"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Palestinian-Territory-Occupied]
    <div class="selectbox ">
        [select country-region "Select a region" "Ariha" "Bayt Lahm" "Bethlehem" "Dayr-al-Balah" "Ghazzah" "Ghazzah ash-Shamaliyah" "Janin" "Khan Yunis" "Nabulus" "Qalqilyah" "Rafah" "Ram Allah wal-Birah" "Salfit" "Tubas" "Tulkarm" "al-Khalil" "al-Quds"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Panama]
    <div class="selectbox ">
        [select country-region "Select a region" "Bocas del Toro" "Chiriqui" "Cocle" "Colon" "Darien" "Embera" "Herrera" "Kuna Yala" "Los Santos" "Ngobe Bugle" "Panama" "Veraguas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Papua-new-Guinea]
    <div class="selectbox ">
        [select country-region "Select a region" "East New Britain" "East Sepik" "Eastern Highlands" "Enga" "Fly River" "Gulf" "Madang" "Manus" "Milne Bay" "Morobe" "National Capital District" "New Ireland" "North Solomons" "Oro" "Sandaun" "Simbu" "Southern Highlands" "West New Britain" "Western Highlands"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Paraguay]
    <div class="selectbox ">
        [select country-region "Select a region" "Alto Paraguay" "Alto Parana" "Amambay" "Asuncion" "Boqueron" "Caaguazu" "Caazapa" "Canendiyu" "Central" "Concepcion" "Cordillera" "Guaira" "Itapua" "Misiones" "Neembucu" "Paraguari" "Presidente Hayes" "San Pedro"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Peru]
    <div class="selectbox ">
        [select country-region "Select a region" "Amazonas" "Ancash" "Apurimac" "Arequipa" "Ayacucho" "Cajamarca" "Cusco" "Huancavelica" "Huanuco" "Ica" "Junin" "La Libertad" "Lambayeque" "Lima y Callao" "Loreto" "Madre de Dios" "Moquegua" "Pasco" "Piura" "Puno" "San Martin" "Tacna" "Tumbes" "Ucayali"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Philippines]
    <div class="selectbox ">
        [select country-region "Select a region" "Batangas" "Bicol" "Bulacan" "Cagayan" "Caraga" "Central Luzon" "Central Mindanao" "Central Visayas" "Cordillera" "Davao" "Eastern Visayas" "Greater Metropolitan Area" "Ilocos" "Laguna" "Luzon" "Mactan" "Metropolitan Manila Area" "Muslim Mindanao" "Northern Mindanao" "Southern Mindanao" "Southern Tagalog" "Western Mindanao" "Western Visayas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Pitcairn-Island]
    <div class="selectbox ">
        [select country-region "Select a region" "Pitcairn Island"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Poland]
    <div class="selectbox ">
        [select country-region "Select a region" "Biale Blota" "Dobroszyce" "Dolnoslaskie" "Dziekanow Lesny" "Hopowo" "Kartuzy" "Koscian" "Krakow" "Kujawsko-Pomorskie" "Lodzkie" "Lubelskie" "Lubuskie" "Malomice" "Malopolskie" "Mazowieckie" "Mirkow" "Opolskie" "Ostrowiec" "Podkarpackie" "Podlaskie" "Polska" "Pomorskie" "Poznan" "Pruszkow" "Rymanowska" "Rzeszow" "Slaskie" "Stare Pole" "Swietokrzyskie" "Warminsko-Mazurskie" "Warsaw" "Wejherowo" "Wielkopolskie" "Wroclaw" "Zachodnio-Pomorskie" "Zukowo"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Portugal]
    <div class="selectbox ">
        [select country-region "Select a region" "Abrantes" "Acores" "Alentejo" "Algarve" "Braga" "Centro" "Distrito de Leiria" "Distrito de Viana do Castelo" "Distrito de Vila Real" "Distrito do Porto" "Lisboa e Vale do Tejo" "Madeira" "Norte" "Paivas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Puerto-Rico]
    <div class="selectbox ">
        [select country-region "Select a region" "Arecibo" "Bayamon" "Carolina" "Florida" "Guayama" "Humacao" "Mayaguez-Aguadilla" "Ponce" "Salinas" "San Juan"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Qatar]
    <div class="selectbox ">
        [select country-region "Select a region" "Doha" "Jarian-al-Batnah" "Umm Salal" "ad-Dawhah" "al-Ghuwayriyah" "al-Jumayliyah" "al-Khawr" "al-Wakrah" "ar-Rayyan" "ash-Shamal"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Reunion]
    <div class="selectbox ">
        [select country-region "Select a region" "Saint-Benoit" "Saint-Denis" "Saint-Paul" "Saint-Pierre"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Romania]
    <div class="selectbox ">
        [select country-region "Select a region" "Alba" "Arad" "Arges" "Bacau" "Bihor" "Bistrita-Nasaud" "Botosani" "Braila" "Brasov" "Bucuresti" "Buzau" "Calarasi" "Caras-Severin" "Cluj" "Constanta" "Covasna" "Dambovita" "Dolj" "Galati" "Giurgiu" "Gorj" "Harghita" "Hunedoara" "Ialomita" "Iasi" "Ilfov" "Maramures" "Mehedinti" "Mures" "Neamt" "Olt" "Prahova" "Salaj" "Satu Mare" "Sibiu" "Sondelor" "Suceava" "Teleorman" "Timis" "Tulcea" "Valcea" "Vaslui" "Vrancea"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Russia]
    <div class="selectbox ">
        [select country-region "Select a region" "Adygeja" "Aga" "Alanija" "Altaj" "Amur" "Arhangelsk" "Astrahan" "Bashkortostan" "Belgorod" "Brjansk" "Burjatija" "Chechenija" "Cheljabinsk" "Chita" "Chukotka" "Chuvashija" "Dagestan" "Evenkija" "Gorno-Altaj" "Habarovsk" "Hakasija" "Hanty-Mansija" "Ingusetija" "Irkutsk" "Ivanovo" "Jamalo-Nenets" "Jaroslavl" "Jevrej" "Kabardino-Balkarija" "Kaliningrad" "Kalmykija" "Kaluga" "Kamchatka" "Karachaj-Cherkessija" "Karelija" "Kemerovo" "Khabarovskiy Kray" "Kirov" "Komi" "Komi-Permjakija" "Korjakija" "Kostroma" "Krasnodar" "Krasnojarsk" "Krasnoyarskiy Kray" "Kurgan" "Kursk" "Leningrad" "Lipeck" "Magadan" "Marij El" "Mordovija" "Moscow" "Moskovskaja Oblast" "Moskovskaya Oblast" "Moskva" "Murmansk" "Nenets" "Nizhnij Novgorod" "Novgorod" "Novokusnezk" "Novosibirsk" "Omsk" "Orenburg" "Orjol" "Penza" "Perm" "Primorje" "Pskov" "Pskovskaya Oblast" "Rjazan" "Rostov" "Saha" "Sahalin" "Samara" "Samarskaya" "Sankt-Peterburg" "Saratov" "Smolensk" "Stavropol" "Sverdlovsk" "Tajmyrija" "Tambov" "Tatarstan" "Tjumen" "Tomsk" "Tula"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Rwanda]
    <div class="selectbox ">
        [select country-region "Select a region" "Butare" "Byumba" "Cyangugu" "Gikongoro" "Gisenyi" "Gitarama" "Kibungo" "Kibuye" "Kigali-ngali" "Ruhengeri"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Saint-Helena]
    <div class="selectbox ">
        [select country-region "Select a region" "Ascension" "Gough Island" "Saint Helena" "Tristan da Cunha"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Saint-Kitts-And-Nevis]
    <div class="selectbox ">
        [select country-region "Select a region" "Christ Church Nichola Town" "Saint Anne Sandy Point" "Saint George Basseterre" "Saint George Gingerland" "Saint James Windward" "Saint John Capesterre" "Saint John Figtree" "Saint Mary Cayon" "Saint Paul Capesterre" "Saint Paul Charlestown" "Saint Peter Basseterre" "Saint Thomas Lowland" "Saint Thomas Middle Island" "Trinity Palmetto Point"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Saint-Lucia]
    <div class="selectbox ">
        [select country-region "Select a region" "Anse-la-Raye" "Canaries" "Castries" "Choiseul" "Dennery" "Gros Inlet" "Laborie" "Micoud" "Soufriere" "Vieux Fort"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Saint-Pierre-and-Miquelon]
    <div class="selectbox ">
        [select country-region "Select a region" "Miquelon-Langlade" "Saint-Pierre"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Saint-Vincent-And-The-Grenadines]
    <div class="selectbox ">
        [select country-region "Select a region" "Charlotte" "Grenadines" "Saint Andrew" "Saint David" "Saint George" "Saint Patrick"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Samoa]
    <div class="selectbox ">
        [select country-region "Select a region" "A'ana" "Aiga-i-le-Tai" "Atua" "Fa'asaleleaga" "Gaga'emauga" "Gagaifomauga" "Palauli" "Satupa'itea" "Tuamasaga" "Va'a-o-Fonoti" "Vaisigano"]
    </div>
    [/group]
</div>

<div class="input country">
    [group San-Marino]
    <div class="selectbox ">
        [select country-region "Select a region" "Acquaviva" "Borgo Maggiore" "Chiesanuova" "Domagnano" "Faetano" "Fiorentino" "Montegiardino" "San Marino" "Serravalle"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Sao-Tome-and-Principe]
    <div class="selectbox ">
        [select country-region "Select a region" "Agua Grande" "Cantagalo" "Lemba" "Lobata" "Me-Zochi" "Pague"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Saudi-Arabia]
    <div class="selectbox ">
        [select country-region "Select a region" "Al Khobar" "Aseer" "Ash Sharqiyah" "Asir" "Central Province" "Eastern Province" "Ha'il" "Jawf" "Jizan" "Makkah" "Najran" "Qasim" "Tabuk" "Western Province" "al-Bahah" "al-Hudud-ash-Shamaliyah" "al-Madinah" "ar-Riyad"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Senegal]
    <div class="selectbox ">
        [select country-region "Select a region" "Dakar" "Diourbel" "Fatick" "Kaolack" "Kolda" "Louga" "Saint-Louis" "Tambacounda" "Thies" "Ziguinchor"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Serbia]
    <div class="selectbox ">
        [select country-region "Select a region" "Central Serbia" "Kosovo and Metohija" "Vojvodina"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Seychelles]
    <div class="selectbox ">
        [select country-region "Select a region" "Anse Boileau" "Anse Royale" "Cascade" "Takamaka" "Victoria"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Sierra-Leone]
    <div class="selectbox ">
        [select country-region "Select a region" "Eastern" "Northern" "Southern" "Western"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Singapore]
    <div class="selectbox ">
        [select country-region "Select a region" "Singapore"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Slovakia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banskobystricky" "Bratislavsky" "Kosicky" "Nitriansky" "Presovsky" "Trenciansky" "Trnavsky" "Zilinsky"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Slovenia]
    <div class="selectbox ">
        [select country-region "Select a region" "Benedikt" "Gorenjska" "Gorishka" "Jugovzhodna Slovenija" "Koroshka" "Notranjsko-krashka" "Obalno-krashka" "Obcina Domzale" "Obcina Vitanje" "Osrednjeslovenska" "Podravska" "Pomurska" "Savinjska" "Slovenian Littoral" "Spodnjeposavska" "Zasavska"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Smaller-Territories-of-the-UK]
    <div class="selectbox ">
        [select country-region "Select a region" "Pitcairn"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Solomon-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Central" "Choiseul" "Guadalcanal" "Isabel" "Makira and Ulawa" "Malaita" "Rennell and Bellona" "Temotu" "Western"]
    </div>
    [/group]
</div>


<div class="input country">
    [group Somalia]
    <div class="selectbox ">
        [select country-region "Select a region" "Awdal" "Bakol" "Banadir" "Bari" "Bay" "Galgudug" "Gedo" "Hiran" "Jubbada Hose" "Jubbadha Dexe" "Mudug" "Nugal" "Sanag" "Shabellaha Dhexe" "Shabellaha Hose" "Togdher" "Woqoyi Galbed"]
    </div>
    [/group]
</div>

<div class="input country">
    [group South-Africa]
    <div class="selectbox ">
        [select country-region "Select a region" "Eastern Cape" "Free State" "Gauteng" "Kempton Park" "Kramerville" "KwaZulu Natal" "Limpopo" "Mpumalanga" "North West" "Northern Cape" "Parow" "Table View" "Umtentweni" "Western Cape"]
    </div>
    [/group]
</div>

<div class="input country">
    [group South-Georgia]
    <div class="selectbox ">
        [select country-region "Select a region" "South Georgia"]
    </div>
    [/group]
</div>

<div class="input country">
    [group South-Sudan]
    <div class="selectbox ">
        [select country-region "Select a region" "Central Equatoria"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Spain]
    <div class="selectbox ">
        [select country-region "Select a region" "A Coruna" "Alacant" "Alava" "Albacete" "Almeria" "Asturias" "Avila" "Badajoz" "Balears" "Barcelona" "Burgos" "Caceres" "Cadiz" "Cantabria" "Castello" "Ceuta" "Ciudad Real" "Cordoba" "Cuenca" "Girona" "Granada" "Guadalajara" "Guipuzcoa" "Huelva" "Huesca" "Jaen" "La Rioja" "Las Palmas" "Leon" "Lleida" "Lugo" "Madrid" "Malaga" "Melilla" "Murcia" "Navarra" "Ourense" "Pais Vasco" "Palencia" "Pontevedra" "Salamanca" "Segovia" "Sevilla" "Soria" "Tarragona" "Santa Cruz de Tenerife" "Teruel" "Toledo" "Valencia" "Valladolid" "Vizcaya" "Zamora" "Zaragoza"]
    </div>
    [/group]
</div>

<div class="input country">
    [group SriLanka]
    <div class="selectbox ">
        [select country-region "Select a region" "Amparai" "Anuradhapuraya" "Badulla" "Boralesgamuwa" "Colombo" "Galla" "Gampaha" "Hambantota" "Kalatura" "Kegalla" "Kilinochchi" "Kurunegala" "Madakalpuwa" "Maha Nuwara" "Malwana" "Mannarama" "Matale" "Matara" "Monaragala" "Mullaitivu" "North Eastern Province" "North Western Province" "Nuwara Eliya" "Polonnaruwa" "Puttalama" "Ratnapuraya" "Southern Province" "Tirikunamalaya" "Tuscany" "Vavuniyawa" "Western Province" "Yapanaya" "kadawatha"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Sudan]
    <div class="selectbox ">
        [select country-region "Select a region" "A'ali-an-Nil" "Bahr-al-Jabal" "Central Equatoria" "Gharb Bahr-al-Ghazal" "Gharb Darfur" "Gharb Kurdufan" "Gharb-al-Istiwa'iyah" "Janub Darfur" "Janub Kurdufan" "Junqali" "Kassala" "Nahr-an-Nil" "Shamal Bahr-al-Ghazal" "Shamal Darfur" "Shamal Kurdufan" "Sharq-al-Istiwa'iyah" "Sinnar" "Warab" "Wilayat al Khartum" "al-Bahr-al-Ahmar" "al-Buhayrat" "al-Jazirah" "al-Khartum" "al-Qadarif" "al-Wahdah" "an-Nil-al-Abyad" "an-Nil-al-Azraq" "ash-Shamaliyah"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Suriname]
    <div class="selectbox ">
        [select country-region "Select a region" "Brokopondo" "Commewijne" "Coronie" "Marowijne" "Nickerie" "Para" "Paramaribo" "Saramacca" "Wanica"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Svalbard-And-Jan-Mayen-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Svalbard"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Swaziland]
    <div class="selectbox ">
        [select country-region "Select a region" "Hhohho" "Lubombo" "Manzini" "Shiselweni"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Sweden]
    <div class="selectbox ">
        [select country-region "Select a region" "Alvsborgs Lan" "Angermanland" "Blekinge" "Bohuslan" "Dalarna" "Gavleborg" "Gaza" "Gotland" "Halland" "Jamtland" "Jonkoping" "Kalmar" "Kristianstads" "Kronoberg" "Norrbotten" "Orebro" "Ostergotland" "Saltsjo-Boo" "Skane" "Smaland" "Sodermanland" "Stockholm" "Uppsala" "Varmland" "Vasterbotten" "Vastergotland" "Vasternorrland" "Vastmanland" "Vastra Gotaland"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Switzerland]
    <div class="selectbox ">
        [select country-region "Select a region" "Aargau" "Appenzell Inner-Rhoden" "Appenzell-Ausser Rhoden" "Basel-Landschaft" "Basel-Stadt" "Bern" "Canton Ticino" "Fribourg" "Geneve" "Glarus" "Graubunden" "Heerbrugg" "Jura" "Kanton Aargau" "Luzern" "Morbio Inferiore" "Muhen" "Neuchatel" "Nidwalden" "Obwalden" "Sankt Gallen" "Schaffhausen" "Schwyz" "Solothurn" "Thurgau" "Ticino" "Uri" "Valais" "Vaud" "Vauffelin" "Zug" "Zurich"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Syria]
    <div class="selectbox ">
        [select country-region "Select a region" "Aleppo" "Dar'a" "Dayr-az-Zawr" "Dimashq" "Halab" "Hamah" "Hims" "Idlib" "Madinat Dimashq" "Tartus" "al-Hasakah" "al-Ladhiqiyah" "al-Qunaytirah" "ar-Raqqah" "as-Suwayda"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Taiwan]
    <div class="selectbox ">
        [select country-region "Select a region" "Chiayi County" "Chiayi City" "Taipei City" "Hsinchu County" "Hsinchu City" "Hualien County" "Kaohsiung City" "Keelung City" "Kinmen County" "Miaoli County" "Nantou County" "Penghu County" "Pingtung County" "Taichung City" "Tainan City" "New Taipei City" "Taitung County" "Taoyuan City" "Yilan County" "YunLin County" "Lienchiang County"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Tajikistan]
    <div class="selectbox ">
        [select country-region "Select a region" "Dushanbe" "Gorno-Badakhshan" "Karotegin" "Khatlon" "Sughd"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Tanzania]
    <div class="selectbox ">
        [select country-region "Select a region" "Arusha" "Dar es Salaam" "Dodoma" "Iringa" "Kagera" "Kigoma" "Kilimanjaro" "Lindi" "Mara" "Mbeya" "Morogoro" "Mtwara" "Mwanza" "Pwani" "Rukwa" "Ruvuma" "Shinyanga" "Singida" "Tabora" "Tanga" "Zanzibar and Pemba"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Thailand]
    <div class="selectbox ">
        [select country-region "Select a region" "Amnat Charoen" "Ang Thong" "Bangkok" "Buri Ram" "Chachoengsao" "Chai Nat" "Chaiyaphum" "Changwat Chaiyaphum" "Chanthaburi" "Chiang Mai" "Chiang Rai" "Chon Buri" "Chumphon" "Kalasin" "Kamphaeng Phet" "Kanchanaburi" "Khon Kaen" "Krabi" "Krung Thep" "Lampang" "Lamphun" "Loei" "Lop Buri" "Mae Hong Son" "Maha Sarakham" "Mukdahan" "Nakhon Nayok" "Nakhon Pathom" "Nakhon Phanom" "Nakhon Ratchasima" "Nakhon Sawan" "Nakhon Si Thammarat" "Nan" "Narathiwat" "Nong Bua Lam Phu" "Nong Khai" "Nonthaburi" "Pathum Thani" "Pattani" "Phangnga" "Phatthalung" "Phayao" "Phetchabun" "Phetchaburi" "Phichit" "Phitsanulok" "Phra Nakhon Si Ayutthaya" "Phrae" "Phuket" "Prachin Buri" "Prachuap Khiri Khan" "Ranong" "Ratchaburi" "Rayong" "Roi Et" "Sa Kaeo" "Sakon Nakhon" "Samut Prakan" "Samut Sakhon" "Samut Songkhran" "Saraburi" "Satun" "Si Sa Ket" "Sing Buri" "Songkhla" "Sukhothai" "Suphan Buri" "Surat Thani" "Surin" "Tak" "Trang" "Trat" "Ubon Ratchathani" "Udon Thani" "Uthai Thani" "Uttaradit" "Yala" "Yasothon"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Togo]
    <div class="selectbox ">
        [select country-region "Select a region" "Centre" "Kara" "Maritime" "Plateaux" "Savanes"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Tokelau]
    <div class="selectbox ">
        [select country-region "Select a region" "Atafu" "Fakaofo" "Nukunonu"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Tonga]
    <div class="selectbox ">
        [select country-region "Select a region" "Eua" "Ha'apai" "Niuas" "Tongatapu" "Vava'u"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Trinidad-And-Tobago]
    <div class="selectbox ">
        [select country-region "Select a region" "Arima-Tunapuna-Piarco" "Caroni" "Chaguanas" "Couva-Tabaquite-Talparo" "Diego Martin" "Glencoe" "Penal Debe" "Point Fortin" "Port of Spain" "Princes Town" "Saint George" "San Fernando" "San Juan" "Sangre Grande" "Siparia" "Tobago"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Tunisia]
    <div class="selectbox ">
        [select country-region "Select a region" "Aryanah" "Bajah" "Bin 'Arus" "Binzart" "Gouvernorat de Ariana" "Gouvernorat de Nabeul" "Gouvernorat de Sousse" "Hammamet Yasmine" "Jundubah" "Madaniyin" "Manubah" "Monastir" "Nabul" "Qabis" "Qafsah" "Qibili" "Safaqis" "Sfax" "Sidi Bu Zayd" "Silyanah" "Susah" "Tatawin" "Tawzar" "Tunis" "Zaghwan" "al-Kaf" "al-Mahdiyah" "al-Munastir" "al-Qasrayn" "al-Qayrawan"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Turkey]
    <div class="selectbox ">
        [select country-region "Select a region" "Adana" "Adiyaman" "Afyon" "Agri" "Aksaray" "Amasya" "Ankara" "Antalya" "Ardahan" "Artvin" "Aydin" "Balikesir" "Bartin" "Batman" "Bayburt" "Bilecik" "Bingol" "Bitlis" "Bolu" "Burdur" "Bursa" "Canakkale" "Cankiri" "Corum" "Denizli" "Diyarbakir" "Duzce" "Edirne" "Elazig" "Erzincan" "Erzurum" "Eskisehir" "Gaziantep" "Giresun" "Gumushane" "Hakkari" "Hatay" "Icel" "Igdir" "Isparta" "Istanbul" "Izmir" "Kahramanmaras" "Karabuk" "Karaman" "Kars" "Karsiyaka" "Kastamonu" "Kayseri" "Kilis" "Kirikkale" "Kirklareli" "Kirsehir" "Kocaeli" "Konya" "Kutahya" "Lefkosa" "Malatya" "Manisa" "Mardin" "Mugla" "Mus" "Nevsehir" "Nigde" "Ordu" "Osmaniye" "Rize" "Sakarya" "Samsun" "Sanliurfa" "Siirt" "Sinop" "Sirnak" "Sivas" "Tekirdag" "Tokat" "Trabzon" "Tunceli" "Usak" "Van" "Yalova" "Yozgat" "Zonguldak"]
    </div>
    [/group]
</div>


<div class="input country">
    [group Turkmenistan]
    <div class="selectbox ">
        [select country-region "Select a region" "Ahal" "Asgabat" "Balkan" "Dasoguz" "Lebap" "Mari"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Turks-And-Caicos-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Grand Turk" "South Caicos and East Caicos"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Tuvalu]
    <div class="selectbox ">
        [select country-region "Select a region" "Funafuti" "Nanumanga" "Nanumea" "Niutao" "Nui" "Nukufetau" "Nukulaelae" "Vaitupu"]  
    </div>
    [/group]
</div>

<div class="input country">
    [group Uganda]
    <div class="selectbox ">
        [select country-region "Select a region" "Central" "Eastern" "Northern" "Western"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Ukraine]
    <div class="selectbox ">
        [select country-region "Select a region" "Cherkas'ka" "Chernihivs'ka" "Chernivets'ka" "Crimea" "Dnipropetrovska" "Donets'ka" "Ivano-Frankivs'ka" "Kharkiv" "Kharkov" "Khersonska" "Khmel'nyts'ka" "Kirovohrad" "Krym" "Kyyiv" "Kyyivs'ka" "L'vivs'ka" "Luhans'ka" "Mykolayivs'ka" "Odes'ka" "Odessa" "Poltavs'ka" "Rivnens'ka" "Sevastopol'" "Sums'ka" "Ternopil's'ka" "Volyns'ka" "Vynnyts'ka" "Zakarpats'ka" "Zaporizhia" "Zhytomyrs'ka" ]  
    </div>
    [/group]
</div>

<div class="input country">
    [group United-Arab-Emirates]
    <div class="selectbox ">
        [select country-region "Select a region" "Abu Zabi" "Ajman" "Dubai" "Ras al-Khaymah" "Sharjah" "Sharjha" "Umm al Qaywayn" "al-Fujayrah" "ash-Shariqah"]  
    </div>
    [/group]
</div>

<div class="input country">
    [group United-Kingdom]
    <div class="selectbox ">
        [select country-region "Select a region" "Aberdeen" "Aberdeenshire" "Argyll" "Armagh" "Bedfordshire" "Belfast" "Berkshire" "Birmingham" "Brechin" "Bridgnorth" "Bristol" "Buckinghamshire" "Cambridge" "Cambridgeshire" "Channel Islands" "Cheshire" "Cleveland" "Co Fermanagh" "Conwy" "Cornwall" "Coventry" "Craven Arms" "Cumbria" "Denbighshire" "Derby" "Derbyshire" "Devon" "Dial Code Dungannon" "Didcot" "Dorset" "Dunbartonshire" "Durham" "East Dunbartonshire" "East Lothian" "East Midlands" "East Sussex" "East Yorkshire" "England" "Essex" "Fermanagh" "Fife" "Flintshire" "Fulham" "Gainsborough" "Glocestershire" "Gwent" "Hampshire" "Hants" "Herefordshire" "Hertfordshire" "Ireland" "Isle Of Man" "Isle of Wight" "Kenford" "Kent" "Kilmarnock" "Lanarkshire" "Lancashire" "Leicestershire" "Lincolnshire" "Llanymynech" "London" "Ludlow" "Manchester" "Mayfair" "Merseyside" "Mid Glamorgan" "Middlesex" "Mildenhall" "Monmouthshire" "Newton Stewart" "Norfolk" "North Humberside" "North Yorkshire" "Northamptonshire" "Northants" "Northern Ireland" "Northumberland" "Nottingh"]
    </div>
    [/group]
</div>

<div class="input country">
    [group United-States]
    <div class="selectbox ">
        [select country-region "Select a region" "Alabama" "Alaska" "Arizona" "Arkansas" "Byram" "California" "Cokato" "Colorado" "Connecticut" "Delaware" "District of Columbia" "Florida" "Georgia" "Hawaii" "Idaho" "Illinois" "Indiana" "Iowa" "Kansas" "Kentucky" "Louisiana" "Lowa" "Maine" "Maryland" "Massachusetts" "Medfield" "Michigan" "Minnesota" "Mississippi" "Missouri" "Montana" "Nebraska" "Nevada" "New Hampshire" "New Jersey" "New Jersy" "New Mexico" "New York" "North Carolina" "North Dakota" "Ohio" "Oklahoma" "Ontario" "Oregon" "Pennsylvania" "Ramey" "Rhode Island" "South Carolina" "South Dakota" "Sublimity" "Tennessee" "Texas" "Trimble" "Utah" "Vermont" "Virginia" "Washington" "West Virginia" "Wisconsin" "Wyoming" ]  
    </div>
    [/group]
</div>

<div class="input country">
    [group United-States-Minor-Outlying-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "United States Minor Outlying I"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Uruguay]
    <div class="selectbox ">
        [select country-region "Select a region" "Canelones" "Cerro Largo" "Colonia" "Durazno" "FLorida" "Flores" "Lavalleja" "Maldonado" "Montevideo" "Paysandu" "Rio Negro" "Rivera" "Rocha" "Salto" "San Jose" "Soriano" "Tacuarembo" "Treinta y Tres"]   
    </div>
    [/group]
</div>

<div class="input country">
    [group Uzbekistan]
    <div class="selectbox ">
        [select country-region "Select a region" "Andijon" "Buhoro" "Buxoro Viloyati" "Cizah" "Fargona" "Horazm" "Kaskadar" "Korakalpogiston" "Namangan" "Navoi" "Samarkand" "Sirdare" "Surhondar" "Toskent" ] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Vanuatu]
    <div class="selectbox ">
        [select country-region "Select a region" "Malampa" "Penama" "Sanma" "Shefa" "Tafea" "Torba"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Vatican-City-State-(Holy-See)]
    <div class="selectbox ">
        [select country-region "Select a region" "Vatican City State (Holy See)" ]  
    </div>
    [/group]
</div>

<div class="input country">
    [group Venezuela]
    <div class="selectbox ">
        [select country-region "Select a region" "Amazonas" "Anzoategui" "Apure" "Aragua" "Barinas" "Bolivar" "Carabobo" "Cojedes" "Delta Amacuro" "Distrito Federal" "Falcon" "Guarico" "Lara" "Merida" "Miranda" "Monagas" "Nueva Esparta" "Portuguesa" "Sucre" "Tachira" "Trujillo" "Vargas" "Yaracuy" "Zulia"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Vietnam]
    <div class="selectbox ">
        [select country-region "Select a region" "Bac Giang" "Binh Dinh" "Binh Duong" "Da Nang" "Dong Bang Song Cuu Long" "Dong Bang Song Hong" "Dong Nai" "Dong Nam Bo" "Duyen Hai Mien Trung" "Hanoi" "Hung Yen" "Khu Bon Cu" "Long An" "Mien Nui Va Trung Du" "Thai Nguyen" "Thanh Pho Ho Chi Minh" "Thu Do Ha Noi" "Tinh Can Tho" "Tinh Da Nang" "Tinh Gia Lai" ]  
    </div>
    [/group]
</div>

<div class="input country">
    [group Virgin-Islands-(British)]
    <div class="selectbox ">
        [select country-region "Select a region" "Anegada" "Jost van Dyke" "Tortola"]  
    </div>
    [/group]
</div>

<div class="input country">
    [group Virgin-Islands-(US)]
    <div class="selectbox ">
        [select country-region "Select a region" "Saint Croix" "Saint John" "Saint Thomas"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Wallis-And-Futuna-Islands]
    <div class="selectbox ">
        [select country-region "Select a region" "Alo" "Singave" "Wallis"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Western-Sahara]
    <div class="selectbox ">
        [select country-region "Select a region" "Bu Jaydur" "Wad-adh-Dhahab" "al-'Ayun" "as-Samarah"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Yemen]
    <div class="selectbox ">
        [select country-region "Select a region" "'Adan" "Abyan" "Dhamar" "Hadramaut" "Hajjah" "Hudaydah" "Ibb" "Lahij" "Ma'rib" "Madinat San'a" "Sa'dah" "Sana" "Shabwah" "Ta'izz" "al-Bayda" "al-Hudaydah" "al-Jawf" "al-Mahrah" "al-Mahwit" ] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Yugoslavia]
    <div class="selectbox ">
        [select country-region "Select a region" "Central Serbia" "Kosovo and Metohija" "Montenegro" "Republic of Serbia" "Serbia" "Vojvodina"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Zambia]
    <div class="selectbox ">
        [select country-region "Select a region" "Central" "Copperbelt" "Eastern" "Luapala" "Lusaka" "North-Western" "Northern" "Southern" "Western"] 
    </div>
    [/group]
</div>

<div class="input country">
    [group Zimbabwe]
    <div class="selectbox ">
        [select country-region "Select a region" "Bulawayo" "Harare" "Manicaland" "Mashonaland Central" "Mashonaland East" "Mashonaland West" "Masvingo" "Matabeleland North" "Matabeleland South" "Midlands"]  
    </div>
    [/group]
</div>



















<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>

<div class="input country">
    [group Cambodia]
    <div class="selectbox ">
        [select country-region "Select a region" "Banteay Mean Chey" "Bat Dambang" "Kampong Cham" "Kampong Chhnang" "Kampong Spoeu" "Kampong Thum" "Kampot" "Kandal" "Kaoh Kong" "Kracheh" "Krong Kaeb" "Krong Pailin" "Krong Preah Sihanouk" "Mondol Kiri" "Otdar Mean Chey" "Phnum Penh" "Pousat" "Preah Vihear" "Prey Veaeng" "Rotanak Kiri" "Siem Reab" "Stueng Traeng" "Svay Rieng" "Takaev"]
    </div>
    [/group]
</div>




Barbados
Select a region









<li>

    <div class="input">
        <div class="selectbox ">
            [select country-gujarat "Select Country" "Afghanistan" "Albania" "Algeria" "American Samoa" "Andorra" "Angola" "Anguilla" "Antigua and Barbuda" "Argentina" "Armenia" "Armenia" "Aruba" "Australia" "Austria" "Azerbaijan" "Azerbaijan" "Bahamas" "Bahrain" "Bangladesh" "Barbados" "Belarus" "Belgium" "Belize" "Benin" "Bermuda" "Bhutan" "Bolivia" "Bonaire" "Bosnia and Herzegovina" "Botswana" "Bouvet Island (Bouvetoya)" "Brazil" "British Indian Ocean Territory (Chagos Archipelago)" "British Virgin Islands" "Brunei Darussalam" "Bulgaria" "Burkina Faso" "Burundi" "Canada" "Cambodia" "Cameroon" "Cape Verde" "Cayman Islands" "Central African Republic" "Chad" "Chile" "China" "Christmas Island" "Cocos (Keeling) Islands" "Colombia" "Comoros" "Congo" "Congo" "Cook Islands" "Costa Rica" "Cote d'Ivoire" "Croatia" "Cuba" "Cura�ao" "Cyprus" "Cyprus" "Czech Republic" "Denmark" "Djibouti" "Dominica" "Dominican Republic" "Ecuador" "Egypt" "El Salvador" "Equatorial Guinea" "Eritrea" "Estonia" "Ethiopia" "Falkland Islands (Malvinas)" "Faroe Islands" "Fiji" "Finland" "France" "French Guiana" "French Polynesia" "French Southern Territories" "Gabon" "Gambia" "Georgia" "Georgia" "Germany" "Ghana" "Gibraltar" "Greece" "Greenland" "Grenada" "Guadeloupe" "Guam" "Guatemala" "Guernsey" "Guinea" "Guinea-Bissau" "Guyana" "Haiti" "Heard Island and McDonald Islands" "Holy See (Vatican City State)" "Honduras" "Hong Kong" "Hungary" "Iceland" "India" "Indonesia" "Iran" "Iraq" "Ireland" "Isle of Man" "Israel" "Italy" "Jamaica" "Japan" "Jersey" "Jordan" "Kazakhstan" "Kazakhstan" "Kenya" "Kiribati" "Korea" "Korea" "Kuwait" "Kyrgyz Republic" "Lao People's Democratic Republic" "Latvia" "Lebanon" "Lesotho" "Liberia" "Libyan Arab Jamahiriya" "Liechtenstein" "Lithuania" "Luxembourg" "Macao" "Macedonia" "Madagascar" "Malawi" "Malaysia" "Maldives" "Mali" "Malta" "Marshall Islands" "Martinique" "Mauritania" "Mauritius" "Mayotte" "Mexico" "Micronesia" "Moldova" "Monaco" "Mongolia" "Montenegro" "Montserrat" "Morocco" "Mozambique" "Myanmar" "Namibia" "Nauru" "Nepal" "Netherlands" "Netherlands Antilles" "New Caledonia" "New Zealand" "Nicaragua" "Niger" "Nigeria" "Niue" "Norfolk Island" "Northern Mariana Islands" "Norway" "Oman" "Pakistan" "Palau" "Palestinian Territory" "Panama" "Papua New Guinea" "Paraguay" "Peru" "Philippines" "Pitcairn Islands" "Poland" "Portugal" "Puerto Rico" "Qatar" "Reunion" "Romania" "Russian Federation" "Rwanda" "Saint Barthelemy" "Saint Helena" "Saint Kitts and Nevis" "Saint Lucia" "Saint Martin" "Saint Pierre and Miquelon" "Saint Vincent and the Grenadines" "Samoa" "San Marino" "Sao Tome and Principe" "Saudi Arabia" "Senegal" "Serbia" "Seychelles" "Sierra Leone" "Singapore" "Sint Maarten (Netherlands)" "Slovakia (Slovak Republic)" "Slovenia" "Solomon Islands" "Somalia" "South Africa" "South Georgia & S. Sandwich Islands" "Spain" "Sri Lanka" "Sudan" "Suriname" "Svalbard & Jan Mayen Islands" "Swaziland" "Sweden" "Switzerland" "Syrian Arab Republic" "Taiwan" "Tajikistan" "Tanzania" "Thailand" "Timor-Leste" "Togo" "Tokelau" "Tonga" "Trinidad and Tobago" "Tunisia" "Turkey" "Turkey" "Turkmenistan" "Turks and Caicos Islands" "Tuvalu" "U.S. Virgin Islands" "U.S. Minor Outlying Islands" "Uganda" "Ukraine" "United Arab Emirates" "United Kingdom" "United States" "Uruguay" "Uzbekistan" "Vanuatu" "Venezuela" "Vietnam" "Wallis and Futuna" "Western Sahara" "Yemen" "Zambia" "Zimbabwe"]
        </div>
    </div>


    <div class="input country">
        [group teen]
        <div class="selectbox ">
            [select country-demo "Gujarat" "Maharastra" "Rajastan" "Goa" "Mp" "UP"]
        </div>
        [/group]
    </div>




    <div class="input country">
        [group seniors]
        <div class="selectbox ">
            [select country-demo "Karachi" "Islamabad" "demo1" "demo2"]
        </div>
        [/group]
    </div>


</li>