-- Drop table

-- DROP TABLE affiliations

CREATE TABLE affiliations (
	ID INTEGER NOT NULL,
	affiliation VARCHAR(255),
	CONSTRAINT SYS_PK_10598 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10363 ON affiliations (ID);

-- Drop table

-- DROP TABLE cases

CREATE TABLE cases (
	ID INTEGER NOT NULL,
	patient_ID INTEGER DEFAULT 0,
	clinician_ID INTEGER DEFAULT 0,
	doctor_notes VARCHAR(16777216),
	gc_notes VARCHAR(16777216),
	genetic_test_ID INTEGER DEFAULT 0,
	CONSTRAINT SYS_PK_10602 PRIMARY KEY (ID)
);
CREATE INDEX CASES_CLINICIAN_ID ON cases (clinician_ID);
CREATE INDEX CASES_GENETIC_TEST_ID ON cases (genetic_test_ID);
CREATE INDEX CASES_PATIENT_ID ON cases (patient_ID);
CREATE UNIQUE INDEX SYS_IDX_10371 ON cases (ID);

-- Drop table

-- DROP TABLE cities

CREATE TABLE cities (
	ID INTEGER NOT NULL,
	city VARCHAR(255),
	CONSTRAINT SYS_PK_10606 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10375 ON cities (ID);

-- Drop table

-- DROP TABLE clinician_status

CREATE TABLE clinician_status (
	ID INTEGER NOT NULL,
	clinician_status VARCHAR(255),
	CONSTRAINT SYS_PK_10610 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10379 ON clinician_status (ID);

-- Drop table

-- DROP TABLE clinician_type

CREATE TABLE clinician_type (
	ID INTEGER NOT NULL,
	clinician_type VARCHAR(255),
	CONSTRAINT SYS_PK_10614 PRIMARY KEY (ID)
);
CREATE INDEX CLINICIAN_TYPE_CLINICIAN_TYPECLINICIAN_TYPE ON clinician_type (clinician_type);
CREATE UNIQUE INDEX SYS_IDX_10383 ON clinician_type (ID);

-- Drop table

-- DROP TABLE clinicians

CREATE TABLE clinicians (
	ID INTEGER NOT NULL,
	record_status BIGINT DEFAULT 0,
	family_name VARCHAR(255),
	first_name VARCHAR(255),
	second_name VARCHAR(255),
	third_name VARCHAR(255),
	registration_number VARCHAR(255),
	gender VARCHAR(1),
	qualifications_1 INTEGER DEFAULT 0,
	qualifications_2 INTEGER DEFAULT 0,
	qualifications_3 INTEGER DEFAULT 0,
	qualifications_4 INTEGER DEFAULT 0,
	qualifications_5 INTEGER DEFAULT 0,
	register_type INTEGER DEFAULT 0,
	clinician_type INTEGER DEFAULT 0,
	specialty_1 INTEGER DEFAULT 0,
	specialty_2 INTEGER DEFAULT 0,
	specialty_3 INTEGER DEFAULT 0,
	practice_place VARCHAR(255),
	practice_address_1 VARCHAR(255),
	practice_place_2 VARCHAR(255),
	practice_place_3 VARCHAR(255),
	office_phone VARCHAR(255),
	mobile_phone VARCHAR(255),
	affiliations_1 INTEGER DEFAULT 0,
	affiliations_2 INTEGER DEFAULT 0,
	affiliations_3 INTEGER DEFAULT 0,
	cg_membership_status INTEGER DEFAULT 0,
	cg_membership_date TIMESTAMP,
	fourth_name VARCHAR(255),
	practice_city VARCHAR(255),
	practice_country INTEGER DEFAULT 0,
	CONSTRAINT SYS_PK_10618 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10417 ON clinicians (ID);

-- Drop table

-- DROP TABLE countries

CREATE TABLE countries (
	country VARCHAR(255),
	country_code VARCHAR(255),
	ID INTEGER NOT NULL,
	ethnicity VARCHAR(255),
	CONSTRAINT SYS_PK_10622 PRIMARY KEY (ID)
);
CREATE INDEX COUNTRIES_COUNTRY_CODE ON countries (country_code);
CREATE UNIQUE INDEX SYS_IDX_10423 ON countries (ID);

-- Drop table

-- DROP TABLE currencies

CREATE TABLE currencies (
	ID INTEGER NOT NULL,
	currency VARCHAR(255),
	CONSTRAINT SYS_PK_10626 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10427 ON currencies (ID);

-- Drop table

-- DROP TABLE ethinicities

CREATE TABLE ethinicities (
	ID INTEGER NOT NULL,
	ethnicity_name VARCHAR(255),
	CONSTRAINT SYS_PK_10630 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10431 ON ethinicities (ID);

-- Drop table

-- DROP TABLE genetic_counsellors

CREATE TABLE genetic_counsellors (
	ID INTEGER NOT NULL,
	record_status INTEGER DEFAULT 0,
	family_name VARCHAR(255),
	first_name VARCHAR(255),
	second_name VARCHAR(255),
	third_name VARCHAR(255),
	fourth_name VARCHAR(255),
	gender VARCHAR(255),
	qualifications_1 INTEGER DEFAULT 0,
	qualifications_2 INTEGER DEFAULT 0,
	qualifications_3 INTEGER DEFAULT 0,
	qualifications_4 INTEGER DEFAULT 0,
	qualifications_5 INTEGER DEFAULT 0,
	affiliations_1 INTEGER DEFAULT 0,
	affilitations_2 INTEGER DEFAULT 0,
	affiliations_3 INTEGER DEFAULT 0,
	record_creation_date TIMESTAMP,
	record_last_updated TIMESTAMP,
	CONSTRAINT SYS_PK_10634 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10451 ON genetic_counsellors (ID);

-- Drop table

-- DROP TABLE genetic_tests

CREATE TABLE genetic_tests (
	ID INTEGER NOT NULL,
	update_date TIMESTAMP,
	test_status INTEGER DEFAULT 0,
	test_name VARCHAR(255),
	test_creator INTEGER DEFAULT 0,
	test_supplier INTEGER DEFAULT 0,
	test_category INTEGER DEFAULT 0,
	technical_type INTEGER DEFAULT 0,
	description VARCHAR(16777216),
	tat VARCHAR(255),
	price DECIMAL(100,4) DEFAULT 0,
	price_currency INTEGER DEFAULT 0,
	price_date TIMESTAMP,
	test_contact INTEGER DEFAULT 0,
	specimen_type INTEGER DEFAULT 0,
	testing_location1 INTEGER DEFAULT 0,
	version_number VARCHAR(255),
	specimen_amount VARCHAR(255),
	MOH_level INTEGER DEFAULT 0,
	GC_info VARCHAR(255),
	notes VARCHAR(255),
	variant_type1 INTEGER DEFAULT 0,
	variant_type2 INTEGER DEFAULT 0,
	variant_type3 INTEGER DEFAULT 0,
	testing_location2 INTEGER DEFAULT 0,
	testing_location3 INTEGER DEFAULT 0,
	ordering_info VARCHAR(255),
	provider_code VARCHAR(255),
	keywords VARCHAR(16777216),
	CONSTRAINT SYS_PK_10638 PRIMARY KEY (ID)
);
CREATE INDEX GENETIC_TESTS_PROVIDER_CODE ON genetic_tests (provider_code);
CREATE UNIQUE INDEX SYS_IDX_10482 ON genetic_tests (ID);

-- Drop table

-- DROP TABLE identification_type

CREATE TABLE identification_type (
	ID INTEGER NOT NULL,
	ID_type VARCHAR(255),
	CONSTRAINT SYS_PK_10642 PRIMARY KEY (ID)
);
CREATE INDEX IDENTIFICATION_TYPE_ID_TYPE ON identification_type (ID_type);
CREATE UNIQUE INDEX SYS_IDX_10486 ON identification_type (ID);

-- Drop table

-- DROP TABLE martial_status

CREATE TABLE martial_status (
	ID INTEGER NOT NULL,
	marital_status VARCHAR(255),
	CONSTRAINT SYS_PK_10646 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10490 ON martial_status (ID);

-- Drop table

-- DROP TABLE membership_status

CREATE TABLE membership_status (
	ID INTEGER NOT NULL,
	membership_status VARCHAR(255),
	CONSTRAINT SYS_PK_10650 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10494 ON membership_status (ID);

-- Drop table

-- DROP TABLE patients

CREATE TABLE patients (
	ID INTEGER NOT NULL,
	record_status INTEGER DEFAULT 0,
	family_name VARCHAR(255),
	first_name VARCHAR(255),
	second_name VARCHAR(255),
	third_name VARCHAR(255),
	fourth_name VARCHAR(255),
	gender VARCHAR(1),
	ID_number VARCHAR(255),
	ID_type INTEGER DEFAULT 0,
	ID_country INTEGER DEFAULT 0,
	ethnicity INTEGER DEFAULT 0,
	DOB TIMESTAMP,
	marital_status INTEGER DEFAULT 0,
	eye_color VARCHAR(255),
	hair_color VARCHAR(255),
	weight_kg INTEGER DEFAULT 0,
	height_cm INTEGER DEFAULT 0,
	blood_pressure VARCHAR(255),
	heart_rate VARCHAR(255),
	next_of_kin VARCHAR(255),
	next_of_kin_relationship VARCHAR(255),
	distinguishing_marks VARCHAR(255),
	place_of_residency VARCHAR(255),
	birthplace VARCHAR(255),
	current_occupation VARCHAR(255),
	last_updated TIMESTAMP,
	record_creation_date TIMESTAMP,
	referring_clinician1 INTEGER DEFAULT 0,
	referring_clinician2 INTEGER DEFAULT 0,
	number_of_children INTEGER DEFAULT 0,
	number_of_grandchildren INTEGER DEFAULT 0,
	number_of_siblings INTEGER DEFAULT 0,
	initial_referral_reason VARCHAR(255),
	initial_doctor_notes VARCHAR(16777216),
	initial_gc_notes VARCHAR(16777216),
	CONSTRAINT SYS_PK_10654 PRIMARY KEY (ID)
);
CREATE INDEX PATIENTS_ID_COUNTRY ON patients (ID_country);
CREATE INDEX PATIENTS_ID_NUMBER ON patients (ID_number);
CREATE INDEX PATIENTS_ID_TYPE ON patients (ID_type);
CREATE INDEX PATIENTS_NUMBER_OF_CHILDREN ON patients (number_of_children);
CREATE INDEX PATIENTS_NUMBER_OF_GRANDCHILDREN ON patients (number_of_grandchildren);
CREATE INDEX PATIENTS_NUMBER_OF_SIBLINGS ON patients (number_of_siblings);
CREATE UNIQUE INDEX SYS_IDX_10532 ON patients (ID);

-- Drop table

-- DROP TABLE protein_coding_genes

CREATE TABLE protein_coding_genes (
	hgnc_id VARCHAR(255),
	symbol VARCHAR(255),
	name VARCHAR(255),
	location VARCHAR(255),
	entrez_id DOUBLE,
	ensembl_gene_id VARCHAR(255),
	refseq_accession VARCHAR(255),
	uniprot_ids VARCHAR(255),
	pubmed_id VARCHAR(255),
	cosmic VARCHAR(255),
	omim_id INTEGER,
	ID INTEGER NOT NULL,
	CONSTRAINT SYS_PK_10658 PRIMARY KEY (ID)
);
CREATE INDEX PROTEIN_CODING_GENES_ENSEMBL_GENE_ID ON protein_coding_genes (ensembl_gene_id);
CREATE INDEX PROTEIN_CODING_GENES_ENTREZ_ID ON protein_coding_genes (entrez_id);
CREATE INDEX PROTEIN_CODING_GENES_HGNC_ID ON protein_coding_genes (hgnc_id);
CREATE INDEX PROTEIN_CODING_GENES_OMIM_ID ON protein_coding_genes (omim_id);
CREATE INDEX PROTEIN_CODING_GENES_PUBMED_ID ON protein_coding_genes (pubmed_id);
CREATE UNIQUE INDEX SYS_IDX_10546 ON protein_coding_genes (ID);

-- Drop table

-- DROP TABLE qualifications

CREATE TABLE qualifications (
	ID INTEGER NOT NULL,
	qualifications VARCHAR(255),
	CONSTRAINT SYS_PK_10662 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10550 ON qualifications (ID);

-- Drop table

-- DROP TABLE register_type

CREATE TABLE register_type (
	ID INTEGER NOT NULL,
	register_type VARCHAR(255),
	CONSTRAINT SYS_PK_10666 PRIMARY KEY (ID)
);
CREATE INDEX REGISTER_TYPE_REGISTERREGISTER_TYPE ON register_type (register_type);
CREATE UNIQUE INDEX SYS_IDX_10554 ON register_type (ID);

-- Drop table

-- DROP TABLE specialties

CREATE TABLE specialties (
	ID INTEGER NOT NULL,
	specialty VARCHAR(255),
	CONSTRAINT SYS_PK_10670 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10558 ON specialties (ID);

-- Drop table

-- DROP TABLE specimen_types

CREATE TABLE specimen_types (
	ID INTEGER NOT NULL,
	specimen_type VARCHAR(255),
	CONSTRAINT SYS_PK_10674 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10562 ON specimen_types (ID);

-- Drop table

-- DROP TABLE technologies

CREATE TABLE technologies (
	ID INTEGER NOT NULL,
	technology VARCHAR(255),
	CONSTRAINT SYS_PK_10678 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10566 ON technologies (ID);

-- Drop table

-- DROP TABLE test_categories

CREATE TABLE test_categories (
	ID INTEGER NOT NULL,
	test_category VARCHAR(255),
	CONSTRAINT SYS_PK_10682 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10570 ON test_categories (ID);

-- Drop table

-- DROP TABLE test_contacts

CREATE TABLE test_contacts (
	ID INTEGER NOT NULL,
	contact_name VARCHAR(255),
	contact_company VARCHAR(255),
	contact_email VARCHAR(255),
	contact_phone VARCHAR(255),
	CONSTRAINT SYS_PK_10686 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10577 ON test_contacts (ID);

-- Drop table

-- DROP TABLE test_creator

CREATE TABLE test_creator (
	ID INTEGER NOT NULL,
	creator_name VARCHAR(255),
	CONSTRAINT SYS_PK_10690 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10581 ON test_creator (ID);

-- Drop table

-- DROP TABLE test_status

CREATE TABLE test_status (
	ID INTEGER NOT NULL,
	status VARCHAR(255),
	CONSTRAINT SYS_PK_10694 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10585 ON test_status (ID);

-- Drop table

-- DROP TABLE test_supplier

CREATE TABLE test_supplier (
	ID INTEGER NOT NULL,
	test_supplier VARCHAR(255),
	supplier_location INTEGER DEFAULT 0,
	CONSTRAINT SYS_PK_10698 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10590 ON test_supplier (ID);

-- Drop table

-- DROP TABLE testing_locations

CREATE TABLE testing_locations (
	ID INTEGER NOT NULL,
	testing_location VARCHAR(255),
	CONSTRAINT SYS_PK_10702 PRIMARY KEY (ID)
);
CREATE UNIQUE INDEX SYS_IDX_10594 ON testing_locations (ID);
