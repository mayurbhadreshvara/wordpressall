Defult Logo Get

<?php
$custom_logo_id = get_theme_mod('custom_logo');
$image = wp_get_attachment_image_src($custom_logo_id, 'full');
?>


<?php echo $image[0]; ?>


Defult logo Skip option Function
+============================================
add_action('customize_register', 'vg_theme_customizer_setting');
//for skip crop enble
function myfunction() {

   remove_theme_support('custom-logo');

   add_theme_support('custom-logo', array(
       'flex-width' => true,
       'flex-height' => true,
   ));
}

add_action('after_setup_theme', 'myfunction');
=================================================================





admin login screen background image


function custom_loginlogo() {
echo '<style type="text/css">
    h1 a {background-image: url('.site_url().'/wp-content/uploads/2020/12/irving-domain-logo.png) !important; height:120px !important; background-size: auto !important; }
    .login h1 a {    width: 100% !important;     background-size: 240px !important;}
    #wp-admin-bar-wp-logo {display:none !important;}
    body{ background: #EBEFE8
; background-image: url('.site_url().'/wp-content/uploads/2020/12/landing-page-bg.jpg) !important; background-position: center center;background-size: cover !important;}
    #loginform #wp-submit{ background: #fff !important;  color: #496241
!important;  border-color: #496241
!important;}
.login form{ background: #496241
;}
.login label{ color: #fff;}
</style>';
}
add_action('login_head', 'custom_loginlogo');



Custom admin logof
--------------------------

function custom_loginlogo() {
echo '<style type="text/css">
    h1 a {background-image: url('.site_url().'/wp-content/uploads/2019/02/logo-nhs.png) !important; height:92px !important; background-size: auto !important; }
    .login h1 a {    width: 100% !important;     background-size: 125px !important;}    
    #wp-admin-bar-wp-logo {display:none !important;}
</style>';
}
add_action('login_head', 'custom_loginlogo');


---------------------------------
function adminwplogo() {
echo '<style type="text/css">
    #wp-admin-bar-wp-logo {display:none !important;}
</style>';
}
add_action('admin_footer', 'adminwplogo');

add_filter( 'login_headerurl', 'custom_loginlogo_url' );

function custom_loginlogo_url($url) {
return site_url();
}

function my_url_login_hover(){
return 'New Home Shop';
}
add_filter('login_headertitle', 'my_url_login_hover');






Custom logo Skip option Function
==============================================================
function vg_theme_customizer_setting($wp_customize) {
// add a setting
$wp_customize->add_setting('vg_theme_hover_logo');
// Add a control to upload the hover logo
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'vg_theme_hover_logo', array(
'label' => 'Upload White Logo',
'section' => 'title_tagline', //this is the section where the custom-logo from WordPress is
'settings' => 'vg_theme_hover_logo',
'priority' => 8 // show it just below the custom-logo
)));
}





-------------------------------------------------------------------------------------------------
admin panel background change (Add image like - http://13.251.140.13/wordpress/irving/wp-login.php?itsec-hb-token=wploginir)


