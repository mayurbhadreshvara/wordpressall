Project Name: NHS
Page Single floorplan paage

https://www.codexworld.com/wordpress-custom-post-type-related-posts/


<!-- THis is for get post Category Name -->
<?php
        $id = get_the_id();
        $terms = get_the_terms($id, 'floorplan_categories');
        foreach ($terms as $term) {
            $category_title = $term->name;
        }
        ?>



<!-- Demo -->
  
        <h4>Similar Plans from <span><?php echo $category_title; ?></span></h4>
        <ul class="cf plan-list">
            <?php
            $customTaxonomyTerms = wp_get_object_terms($post->ID, 'floorplan_categories', array('fields' => 'ids'));

            $args = array(
                'post_type' => 'floorplans',
                'post_status' => 'publish',
                'posts_per_page' => 5,
                'orderby' => 'rand',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'floorplan_categories',
                        'field' => 'id',
                        'terms' => $customTaxonomyTerms
                    )
                ),
                'post__not_in' => array($post->ID),
            );
            $relatedPosts = new WP_Query($args);

            foreach ($relatedPosts->posts as $related) {
                $releted_img = get_the_post_thumbnail_url($related->ID);
                ?>
                <li>
                    <a href = "<?php echo get_permalink($related->ID); ?>" class = "link"></a>
                    <div class = "image">
                        <img src = "<?php echo $releted_img; ?>" alt = "" title = "">
                    </div>
                    <div class = "desc">
                        <h5><?php echo $related->post_title;
                ?>
                        </h5>
                        <div class="desc-area cf">
                            <div>
                                <strong><?php echo get_field('total_area', $related->ID); ?> <em>M</em>2</strong>
                                <span>Total area</span>
                            </div>
                            <div>
                                <strong><?php echo get_field('residense', $related->ID); ?> <em>M</em>2</strong>
                                <span>Residense</span>
                            </div>
                            <div>
                                <strong><?php echo get_field('alfresco', $related->ID); ?> <em>M</em>2</strong>
                                <span>Garage</span>
                            </div>
                        </div>
                    </div>
                </li>
                <?php
            }
            ?>
        </ul>