

		<!-- header file -->


(1)  language_attributes()
=>   Displays the language attributes for the html tag.


(2)  bloginfo()
=>   Displays information about the current site.

(3)  get_bloginfo()
=>   Retrieves information about the current site.
Z

(3)  echo esc_url( get_template_directory_uri() )  ****************
=>	 Retrieve theme directory URI.


(4)  wp_head() ***************	
=>   Prints scripts or data in the head tag on the front end.


(5)  body_class()
=>   Display the classes for the body element.


(6)  _e()
=>   Display translated text.


(7)  the_custom_logo()
=>   Displays a custom logo, linked to home.


(8)  is_front_page()
=>   Is the query for the front page of the site?  ************


(9)  is_home()
=>   Determines if the query is for the blog homepage.


(10)  home_url()  *****************
=>   Retrieves the URL for the current site where the front end is accessible.


(11)  get_sidebar()
=>    Load sidebar template.

(12)  is_singular()   ***************
=>    Is the query for an existing single post of any post type (post, attachment, page, custom post types)?

(13)  pings_open()    ***************
=>    Whether the current post is open for pings

(14)  get_queried_object()
=>    Retrieve the currently-queried object.


(15)  is_customize_preview()
=>    Whether the site is being previewed in the Customizer.


													











	<!-- footer file -->


(1)  has_nav_menu()
=>    Determines whether a registered nav menu location has a menu assigned to it.
		Filters whether a nav menu is assigned to the specified location.





(2)  esc_attr_e()
=> 	 Display translated text that has been escaped for safe use in an attribute.


(3)  wp_nav_menu()
=>   Displays a navigation menu.



(4)  do_action()
=>	 Execute functions hooked on a specific action hook.


(5)   function_exists()
=>

(6)   wp_footer()
=>    Fire the wp_footer action.




	<!-- index file -->

(1)  have_posts()
=>   Whether current WordPress query has results to loop over.

(2)  single_post_title()
=>   Display or retrieve page title for post.


(4)  the_posts()
=>   Iterate the post index in the loop.

(5)  get_template_part()
=>   Loads a template part into a template.

(6)  get_post_format()
=>	 Returns the post format of a post. This will usually be called in the the loop, but can be used anywhere if a post ID is provided.
=>   Retrieve the format slug for a post.

(7)  the_posts_pagination()
=>   Displays a paginated navigation to next/previous set of posts, when applicable.

(8)  get_footer()
=>   load footer part(template)







		<!-- Sidebar file -->

(1)  is_active_sidebar()
=>   Whether a sidebar is in use.

(2)  dynamic_sidebar()
=>   Display the dynamic sidebar.

(3)  wp_nav_menu()
=>   Displays a navigation menu.

(4)  has_nav_menu()
=>   Determines whether a registered nav menu location has a menu assigned to it.



		<!-- Single file -->

(1)  comments_open()
=>    Whether the current post is open for comments.

(2)  get_comments_number()
=>    Retrieves the amount of comments a post has.


(3)  comments_template()
=>    Load the comment template specified in $file.






(1)   get_search_form()
=>    Display search form


(2)  the_archive_title()
=>   Display the archive title based on the queried object.


(3)   the_archive_description()
=>    Display category, tag, term, or author description.

  
(4)  apply_filters()
=>   Call the functions added to a filter hook.


(5)  get_the_author()
=>   Retrieve the author of the current post.



(5)  get_the_author_meta()
=>   Retrieves the requested data of the author of the current post.



(6)  the_author_meta()
=>   Outputs the field from the user’s DB object. Defaults to current post’s author.



(7)   get_author_posts_url()
=>    Retrieve the URL to the author page for the user with the ID provided.


(*)   post_password_required()
=>    Whether post requires password and correct password has been provided.


(*)   have_comments()
=>    Whether there are comments to loop over.


(*)   get_the_title()
=>    Retrieve post title.


(*)   _x()
=>    Retrieve translated string with gettext context.



(*)   _nx()
=>    Translates and retrieves the singular or plural form based on the supplied number, with gettext context.



(*)   number_format_i18n()
=>    Convert float number to format based on the locale.	


(*)   wp_list_comments()
=>    List Comments


(*)   post_type_supports()
=>    Check a post type’s support for a given feature.	


(*)   comment_form()
=>    Outputs a complete commenting form for use within a template.



(*)   the_ID()
=>    Display the ID of the current item in the WordPress Loop.


(*)   post_class()
=>    Display the classes for the post div.

(*)   sprintf()
=>    WordPress implementation of PHP sprintf() with filters.
=>    

(*)  the_permalink()
=>   Current post the permalink(set a link)


(*)   get_permalink()
=>    Retrieves the full permalink for the current post or post ID.


(*)   the_excerpt()
=>    Display the excerpt


(*)   get_template_directory()
=>    Retrieve current theme directory.

(*)   load_theme_textdomain()
=>     load the child themes translated strings



        <!-- Single file -->

(*)   previous_image_link()
=>    Display previous image link that has the same post parent.

(*)   next_image_link()
=>    Display next image link that has same post parent.

(*)   wp_get_attachment_image_src()
=>     Retrieve an image to represent an attachment.


(*)   the_content()
=>     Display the post content.
























