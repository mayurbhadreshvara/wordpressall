<?php
/**
 * Template Name: Floor Plans & Designs page
 */
get_header();
?>

<!-- home-video -->
<div class="inner-banner cf">
    <div class="inner-banner-right">
        <video poster="<?php echo get_field('floor_plans_designs_image'); ?>" autobuffer="" autoplay="" loop="" muted="">
            <source src="<?php echo get_field('floor_plans_designs_video_mp4')['url']; ?>" type="video/mp4">
            <source src="<?php echo get_field('floor_plans_designs_video_webm')['url']; ?>" type="video/webm">
        </video>
    </div>
    <div class="inner-banner-left">
        <div class="inner-banner-left-inner">
            <div>
                <h3><?php echo get_field('floor_plans_designs_green_title'); ?></h3>
                <h1><?php echo get_field('floor_plans_designs_black_title'); ?></h1>
                <p><?php echo get_field('floor_plans_designs_short_description'); ?></p>
            </div>
        </div>
    </div>
</div>


<div class="main-container cf">
    <div class="container-big">
        <h3><?php echo get_field('floor_plans_title'); ?></h3>
        <p><?php echo get_field('floor_plans_short_content'); ?></p>
        <div class="plan-tab cf">
            <a href="new-homes-single.html" class="single-storey active"><span>Single Storey</span></a>
            <a href="new-homes-double.html" class="double-storey"><span>Double Storey</span></a>
            <a href="new-homes-invest.html" class="invest-range"><span>Invest Range</span></a>
        </div>


        <?php
        $args = array(
            'taxonomy' => 'floorplan_categories',
        );

        $cats = get_categories($args);

        foreach ($cats as $cat) :
            $cate_id = $cat->term_id;
            $cate_name = $cat->name;
            ?>

            <h4><?php echo get_field('floor_plan_category_title', 'floorplan_categories_' . $cate_id); ?> – <?php echo $cate_name; ?> </h4>
            <p></p>
            <p><?php echo category_description($cate_id); ?> </p>

            <ul class = "cf plan-list">
                <?php
                $category = array(
                    'post_type' => 'floorplans',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'floorplan_categories',
                            'field' => 'id',
                            'terms' => $cate_id
                        )
                    ),
                    'post__not_in' => array($post->ID),
                );

                $get_post = get_posts($category);

                foreach ($get_post as $post1) :
                    $post_title1 = $post1->post_title;
                    $floor_img = get_the_post_thumbnail_url($post1->ID);
                    ?>
                    <li>
                        <a href = "<?php echo get_permalink($post1->ID); ?>" class = "link"></a>
                        <div class = "image">
                            <img src = "<?php echo $floor_img; ?>" alt = "" title = "">
                        </div>
                        <div class = "desc">
                            <h5><?php echo $post_title1; ?></h5>
                            <div class = "desc-area cf">
                                <div>
                                    <strong><?php echo get_field('total_area', $post1->ID); ?> <em>M</em>2</strong>
                                    <span>Total area</span>
                                </div>
                                <div>
                                    <strong><?php echo get_field('residense', $post1->ID); ?> <em>M</em>2</strong>
                                    <span>Residense</span>
                                </div>
                                <div>
                                    <strong><?php echo get_field('alfresco', $post1->ID); ?> <em>M</em>2</strong>
                                    <span>Garage</span>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach ?>
            </ul>
        <?php endforeach; ?>
    </div>
</div>



<?php get_footer();
?>




