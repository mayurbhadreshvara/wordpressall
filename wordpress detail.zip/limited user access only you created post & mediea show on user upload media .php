First create AAm plugin user (limited access user)
Post & mediea show only this user upload & create post only 



/ Limit post user  access
function wpse14230_load_edit() {
    add_action('request', 'wpse14230_request');
}function wpse14230_request($query_vars) {
    if (!current_user_can($GLOBALS['post_type_object']->cap->edit_others_posts)) {
        $query_vars['author'] = get_current_user_id();
    }
    return $query_vars;
}add_filter('views_edit-home-designs', 'wp37_update_homedesigns_quicklinks', 1);function wp37_update_homedesigns_quicklinks($views) {    global $current_user, $wp_query;
    if (!current_user_can($GLOBALS['post_type_object']->cap->edit_others_posts)) {
        unset($views['all']);
        unset($views['publish']);
    }
    return $views;
}// Limit media library accessadd_filter('ajax_query_attachments_args', 'wpb_show_current_user_attachments');function wpb_show_current_user_attachments($query) {
    $user_id = get_current_user_id();
    if ($user_id && !current_user_can('activate_plugins') && !current_user_can('edit_others_posts
')) {
        $query['author'] = $user_id;
    }
    return $query;
}