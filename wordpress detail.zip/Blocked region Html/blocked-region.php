<?php
/**
 * Template Name: Blocked Region Page
 */
//get_header();
?>
<header class="page-header alignwide">

</header><!-- .page-header -->


<style>
    .blocked-region{
        height: 100%;
        width: 100%;
        padding: 0;
        margin: 0;
        display: table;
    }
    .blocked-region-inner{
        height: 100%;
        width: 100%;
        display: table-cell;
        vertical-align: middle;
        text-align: center;
    }
    .error-404-inner img{
        display: block;
        margin: 0 auto;
        max-width: 100%;
    }
</style>
<div class="blocked-region">
    <div class="blocked-region-inner">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/blocked-region.jpg">
    </div>
</div><!-- .error-404 -->