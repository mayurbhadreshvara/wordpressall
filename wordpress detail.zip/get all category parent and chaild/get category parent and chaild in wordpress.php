https://wordpress.stackexchange.com/questions/26770/get-posts-assigned-to-a-specific-custom-taxonomy-term-and-not-the-terms-childr


//example my nhs project floor plan page


<?php
$terms_array = array(
    'taxonomy' => 'floorplan_categories', // you can change it according to your taxonomy
    'parent' => false,
// If parent => 0 is passed, only top-level terms will be returned
);
$services_terms = get_terms($terms_array);






foreach ($services_terms as $service):

    $defaults = array('taxonomy' => 'floorplan_categories', 'child_of' => $service->term_id);
    $subcats = get_categories($defaults);
    ?>
    <h4><?php echo $service->name; ?></h4>
    <?php
    foreach ($subcats as $servicec => $keys) {

        //echo '<pre>';
        //print_r($keys->term_id);
        ?>

        <h5><?php echo $keys->name; ?></h5>
        <?php
        $post_args = array(
            'posts_per_page' => -1,
            'post_type' => 'floorplans', // you can change it according to your custom post type
            'tax_query' => array(
                array(
                    'taxonomy' => 'floorplan_categories', // you can change it according to your taxonomy
                    'field' => 'term_id', // this can be 'term_id', 'slug' & 'name'
                    'terms' => $keys->term_id,
                )
            )
        );
        $myposts = get_posts($post_args);
        ?>
        <ul>
            <?php foreach ($myposts as $post) : setup_postdata($post); ?>
                <li>
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </li>
            <?php endforeach; // Term Post foreach  ?>
        </ul>
        <?php wp_reset_postdata(); ?>

        <?php
    }
endforeach;
// End Term foreach;  
?>  
