<?php
/**
 * Template Name: Double Storey Range page
 */
get_header();
?>


<!-- home-video -->
<div class="inner-banner cf">
    <a href="../../../../../../../vg/NHS/html/for-sale.html"></a>
    <div class="inner-banner-right">
        <video poster="<?php echo get_field('floor_plans_designs_image'); ?>" autobuffer="" autoplay="" loop="" muted="">
            <source src="<?php echo get_field('floor_plans_designs_video_mp4')['url']; ?>" type="video/mp4">
            <source src="<?php echo get_field('floor_plans_designs_video_webm')['url']; ?>" type="video/webm">
        </video>
    </div>
    <div class="inner-banner-left">
        <div class="inner-banner-left-inner">
            <div>
                <h3><?php echo get_field('floor_plans_designs_green_title'); ?></h3>
                <h1><?php echo get_field('floor_plans_designs_black_title'); ?></h1>
                <p><?php echo get_field('floor_plans_designs_short_description'); ?></p>
            </div>
        </div>
    </div>
</div>


<div class="main-container cf">
    <div class="container-big">
        <h3><?php echo get_field('floor_plans_title'); ?></h3>
        <p><?php echo get_field('floor_plans_short_content'); ?></p>
        <div class="plan-tab cf">
            <a href="<?php echo site_url(); ?>/floor-plans-designs/" class="single-storey"><span>Single Storey</span></a>
            <a href="<?php echo site_url(); ?>/double-storey-range/" class="double-storey active"><span>Double Storey</span></a>
            <a href="<?php echo site_url(); ?>/invest-range/" class="invest-range"><span>Invest Range</span></a>
        </div>


        <?php
        $acf_category_id = get_field('select_category');
        $term_id = $acf_category_id;
        $taxonomy_name = 'floorplan_categories';
        $term_children = get_term_children($term_id, $taxonomy_name);


        foreach ($term_children as $child) :
            $term = get_term_by('id', $child, $taxonomy_name);
            //echo $term->name;
            ?> 

            <h4><?php echo get_field('floor_plan_category_title', 'floorplan_categories_' . $term->term_id); ?> – <?php echo $term->name; ?> </h4>
            <p><?php echo category_description($term->term_id); ?> </p>

            <ul class = "cf plan-list">
                <?php
                $category = array(
                    'post_type' => 'floorplans',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'floorplan_categories',
                            'field' => 'id',
                            'terms' => $term->term_id
                        )
                    ),
                    'post__not_in' => array($post->ID),
                );

                $get_post = get_posts($category);

                foreach ($get_post as $post1) :
                    $post_title1 = $post1->post_title;
                    $floor_img = get_the_post_thumbnail_url($post1->ID);
                    ?>
                    <li>
                        <a href = "<?php echo get_permalink($post1->ID); ?>" class = "link"></a>
                        <div class = "image">
                            <img src = "<?php echo $floor_img; ?>" alt = "" title = "">
                        </div>
                        <div class = "desc">
                            <h5><?php echo $post_title1; ?></h5>
                            <div class = "desc-area cf">
                                <div>
                                    <strong><?php echo get_field('total_area', $post1->ID); ?> <em>M</em>2</strong>
                                    <span>Total area</span>
                                </div>
                                <div>
                                    <strong><?php echo get_field('residense', $post1->ID); ?> <em>M</em>2</strong>
                                    <span>Residense</span>
                                </div>
                                <div>
                                    <strong><?php echo get_field('alfresco', $post1->ID); ?> <em>M</em>2</strong>
                                    <span>Garage</span>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach ?>
            </ul>
        <?php endforeach; ?>
    </div>
</div>



<?php get_footer();
?>




