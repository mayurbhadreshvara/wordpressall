radio

wordpress defult page file 



page-pageid.php

page-home.php

example: page-101.php


Working  on direct file do not need page attributes

*********************************************************************************************************************************************




(1)Post id get function
=>   <?php get_the_ID(); ?>

(1)Dynamic logo
=>   <?php the_custom_logo(); ?>
Note: select a logo after click the  skip croping logo option. 

*********************************************************************************************************************************************
LOGO Skip option in theme


add_action('customize_register', 'vg_theme_customizer_setting');
//for skip crop enble
function myfunction() {

remove_theme_support('custom-logo');

add_theme_support('custom-logo', array(
'flex-width' => true,
'flex-height' => true,
));
}

add_action('after_setup_theme', 'myfunction');

*********************************************************************************************************************************************
Image File upload Size 

httaccess file Add this code

php_value memory_limit 256M
php_value upload_max_filesize 200M
php_value post_max_size 200M
php_value max_execution_time 300
php_value max_input_time 1000


*********************************************************************************************************************************************
Body class condition
-----------------------------------------------------------

    <?php if (is_page('privacy-policy') || is_page('disclaimer')){ ?>
        <body <?php body_class('content-page'); ?>>
   <?php  } ?>



<?php if (is_front_page() || is_page('services')) { ?>
<body <?php body_class('home-page'); ?>>
    <?php } elseif (is_page('lifestyle-range')) {
    ?>
<body <?php body_class('white-header lifestyle-range-page'); ?>></body>
<?php } else { ?>
<body <?php body_class(); ?>>
    <?php } ?>


    *********************************************************************************************************************************************

    Is Page ID Condition

    <?php if (is_page('contact-us') || is_page('rsvp') || is_front_page() || is_page('display-homes') || is_page('where-we-do-it') ) { ?>
    <?php } ?>
    
    <?php if (is_page('3861') || is_page('3861')){ ?>sdsd<?php } ?>
    
    is working 
        <?php if (is_page([3861,3865,3869])) { ?>
    
    is_page( 42 );

    Custom post type single post
    -----
    <?php if (is_single(array(253, 247))) { ?>

    not show in page or post -  >>>>>>>>>>>> (!is_page('contact-us')


    OR is page template condition (Multiple page condition)

    if(  !is_page_template(array('templates/microsite-template1.php', 'templates/microsite-template3.php'))){


    *********************************************************************************************************************************************

    (1)Dynamic Post Category 

    $cats = get_categories();
    //echo '<pre>';
   // print_r($cats);

        <?php
        foreach ($cats as $cat) :
        $cname = $cat->name;
        ?>
       <option><?php echo $cname; ?></option>
        <?php endforeach; ?>



-----------  http://wpcodesnippet.com/get-category-slug-wordpress/------------------------------


GET Current Category 

        <?php
        // get category slug in wordpress
        if ( is_single() ) {
        $cats = get_the_category();
        $cat = $cats[0];
        } else {
        $cat = get_category( get_query_var( 'cat' ) );
        }
        $cat_slug = $cat->slug;
        echo $cat_slug;
        $cat_id = $cat->cat_ID;
        $cat_name = $cat->name;
        $cat_description = $cat->description;
        ?>

------------------------------------------------------------


        <?php
        $categories = get_the_category();
        $separator = ' ';
        $output = '';
        if (!empty( $categories ) ) {
        foreach( $categories as $category ) {
        $output .= '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '" alt="' . esc_attr( sprintf( __( 'View all posts in %s', 'textdomain' ), $category->name ) ) . '">' . esc_html( $category->name ) . '</a>' . $separator;
        }
        echo trim( $output, $separator );
        }
        ?>
 
------------------------------------------------------------

CPT UI custom post category checkbox to radio Button 

//category checkbox to radio
add_action('add_meta_boxes','mysite_add_meta_boxes',10,2);
function mysite_add_meta_boxes($post_type, $post) {
  ob_start();
}
add_action('dbx_post_sidebar','mysite_dbx_post_sidebar');
function mysite_dbx_post_sidebar() {
  $html = ob_get_clean();
  $html = str_replace('"checkbox"','"radio"',$html);
  echo $html;
}



*********************************************************************************************************************************************

Get COntact FOrm Dynamic

        <?php echo do_shortcode(get_field("contact_form_shortcode")); ?>

https://stackoverflow.com/questions/14386341/using-advanced-custom-fields-and-contact-form-7-to-display-a-form

        <?php
        $formCode = get_field('contact_id');
        echo do_shortcode($formCode);
        ?>



*********************************************************************************************************************************************

Foreach Loop First Class As Active

https://stackoverflow.com/questions/20940057/adding-a-class-to-first-div-in-foreach-loop

<div id="NewsCarousel" class="carousel slide">
<div class="carousel-inner">
                <?php
                $args = array( 'numberposts' => '2', 'category' => 5 );
                $recent_posts = wp_get_recent_posts( $args );
                $count = 0;
                foreach( $recent_posts as $recent ){
                $count++;
                echo '<div class="item';
                if($count == 1){echo ' active';
                }"><a href="' . get_permalink($recent["ID"]) . '" title="Look '.esc_attr($recent["post_title"]).'" >' . get_the_post_thumbnail($recent["ID"], array(200,200)) .$recent["post_title"].'</a> </div> ';
}
?>
</div>
</div>









*********************************************************************************************************************************************

 
 *********************************************************************************************************************************************
logo dynamical
    <?php
    $custom_logo_id = get_theme_mod('custom_logo');
    $image = wp_get_attachment_image_src($custom_logo_id, 'full');
    //echo '<pre>';
    //print_r($image);
    ?>

<a href="<?php echo site_url();
                ?>" class="logo"><img src="<?php echo $image[0]; ?>" alt="" title=""></a>

error logo skip option problum 
Add this code function file's

add_theme_support( 'custom-logo' );
function themename_custom_logo_setup() {
 $defaults = array(
 'height'      => 100,
 'width'       => 480,
 'flex-height' => true,
 'flex-width'  => true,
 'header-text' => array( 'site-title', 'site-description' ),
 );
 add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'themename_custom_logo_setup' );


***********************************************************
custom Logo Option & Get Two logo One Site
***********************************************************


//This is For function file
function hatch_theme_customizer_setting($wp_customize) {
// add a setting 
    $wp_customize->add_setting('your_theme_hover_logo');
// Add a control to upload the hover logo
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'your_theme_hover_logo', array(
        'label' => 'Upload Black Logo',
        'section' => 'title_tagline', //this is the section where the custom-logo from WordPress is
        'settings' => 'your_theme_hover_logo',
        'priority' => 8 // show it just below the custom-logo
    )));
}

add_action('customize_register', 'hatch_theme_customizer_setting');



for get image --------------> <?php echo get_theme_mod('your_theme_hover_logo'); ?>

________________________________________________

Coustom menu's
______________________________________________________________________________________________________


This is for defult menu 

                <?php
                wp_nav_menu(array(
                'theme_location' => 'primary',
                'menu_class' => 'primary-menu navigation cf',
                'container_id'    => 'navigation-menu' //this is for id 
                ));
                ?>  



This is for create multiple  menu 

  TYPE 1
  ------------

                <?php
                wp_nav_menu(array(
                'menu' => 'Main Menu',
                'sub_menu' => true,
                'show_parent' => true,
                'container_class' => "test",
                'menu_class' => 'navigation cf'
                ));
                ?>
  TYPE 2
  ------------------------------------------------------

                <?php
                $menufooter = get_nav_menu_locations();
                $menuID = 'Services Menu'; //$menuLocations['primary'];   this is menu name
                $primaryNav = wp_get_nav_menu_items($menuID);
                foreach ($primaryNav as $navItem) {


                //print_r($navItem);
                echo '<li><a href="' . $navItem->url . '" title="' . $navItem->title . '">' . $navItem->title . '</a></li>';
                }
                ?>
  
  
  you can add function.php this function
  
  function twentytwenty_menus() {

    $locations = array(
        'primary' => __('Desktop Horizontal Menu', 'twentytwenty'),
        'expanded' => __('Desktop Expanded Menu', 'twentytwenty'),
        'mobile' => __('Mobile Menu', 'twentytwenty'),
        'service' => __('Services Menu', 'twentytwenty'),
    );

    register_nav_menus($locations);
}

add_action('init', 'twentytwenty_menus');


------------------------------------------------------








 *********************************************************************************************************************************************

(1)Get Theme Logo
Example :-   https://developer.wordpress.org/reference/functions/the_custom_logo/

Step for wp-admin/Appearance/Customize insert logo and save it

**-- THis is website example  

$custom_logo_id = get_theme_mod( 'custom_logo' );
$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
echo $image[0];


///this is my example
                <?php
                $custom_logo_id = get_theme_mod('custom_logo');
                $image = wp_get_attachment_image_src($custom_logo_id, 'full');
                //echo '<pre>';
                //print_r($image);
                ?>
                    <a href="<?php echo site_url(); ?>" class="logo"><img src="<?php echo $image[0]; ?>" alt="nhs-group-logo" title="NHS Group Logo"></a>

 *********************************************************************************************************************************************






(2)Dynamic menu list 
=>  <?php wp_nav_menu(); ?>

*********************************************************************************************************************************************
(3)Dynamic Posts list Display
=>
                <?php while (have_posts()) : the_post(); ?>
    <h2><?php the_title(); ?></h2>
    <ul>
                    <?php
                    $myposts = get_posts('numberposts=-1&offset=$debut');
                    foreach ($myposts as $post) :
                    ?>
            <li><?php the_time('d/m/y') ?>: <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                    <?php endforeach; ?>
    </ul>
                <?php endwhile; ?>

*********************************************************************************************************************************************

(3)Dynamic Posts list Display image & time & excerpt
=>

                <?php
                $myposts = get_posts('numberposts=-1');
                foreach ($myposts as $post) :
                ?>

    <li>
        <div class="image">

            <img src="<?php echo get_the_post_thumbnail_url() ?>" alt="" title="">
            <span><strong><?php the_time('d') ?></strong> <?php the_time('M') ?></span>


        </div>
        <p><?php echo get_the_excerpt() ?></p>


                    <?php endforeach ?>
</li>



********************************************************************************************************************************************* 

(*)Get the post image
=> <?php echo get_the_post_thumbnail_url() ?>




(4)Display the date
=>  <?php the_time('d/m/y') ?>

                <?php the_time('D/M/Y') ?>

get year dynamic
                <?php date("Y"); ?>

Display the post time (example: 5 mins ago)

                <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?>	



(5)Link The page
=><a href="<?php the_permalink(); ?>"></a>

(6)Display the Post image (featured image)
=><?php echo get_the_post_thumbnail_url() ?>
Example
=><img src="<?php echo get_the_post_thumbnail_url() ?>" alt="" title="">


(7)Display the post Excerpt data show
=><?php get_the_excerpt() ?>


(8)Display the dynamic Categories 
=> <?php wp_list_categories(); ?>

(9) Wordpress defult editor add auto tage example:- p / h1 to h5 tage
 
  both tage working
  
  -->   apply_filters('the_content',$post->post_content);
  
  -->wpautop($post->post_content)   

--------------------------------------------------------------------------

(*)Dynamic logo url
<a href="index.html" class="site-header__logo-image"><img src="<?php echo site_url(); ?>/wp-content/themes/twentysixteen/images/logo-black.png"></a>


(*)Set the css Example
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css">


(*)Get the post tag
$tag_list = get_the_tags($post->ID);

loop tag
                <?php
                if ($tag_list) {
                foreach ($tag_list as $tag) {
                echo $tag->name . ' | ';
                }
                }
                ?>
-----------------------------------------
Full Get Tag
                <?php
                $tags = get_tags();
                $html = '<div class="post_tags">';
                foreach ($tags as $tag) {
                $tag_link = get_tag_link($tag->term_id);

                $html .= "<a href='{$tag_link}' title='{$tag->name} Tag' class='{$tag->slug}'>";
                $html .= "{$tag->name}</a>";
                }
                $html .= '</div>';
                echo $html;
                ?>

-----------------------------------------

Get Post Using Tage Id


https://wordpress.stackexchange.com/questions/35736/how-to-query-with-get-posts-for-posts-with-any-tag's

                <?php
                $all_tags = get_tags();
                $tag_id = array();
                foreach ($all_tags as $tag) {
                $tag_id[] = $tag->term_id;
                }

                $args = array(
                'numberposts' => 5,
                'tag__in' => $tag_id
                );
                $myposts = get_posts($args);


                if ($posts):
                foreach ($posts as $post) :
                $featured_img_url = get_the_post_thumbnail_url($post->ID, 'full');
                $posttitle = $post->post_title;
                $news_short_title = get_field('news_short_title', $post->ID)
                ?>
                                        <li>
                    <?php //echo $cat_id;      ?>
                                            <a href = "<?php echo get_permalink($post->ID); ?>" class = "image"><img src = "<?php echo $featured_img_url; ?>"></a>
                                            <div class = "desc">
                                                <div class = "desc-inner">
                                                    <h4><a href ="<?php echo get_permalink($post->ID); ?>"><?php echo $posttitle; ?></a></h4>
                                                    <span><?php the_time('D, d F Y') ?></span>
                                                    <p><?php echo $news_short_title ?></p>
                                                </div>
                                            </div>
                                        </li>
                <?php
                endforeach;

                endif;
                ?>

---------------------------------------------------------------------------------

Note: how to get post tag -- if condition is tag exist or not 



(*)Dynamic post link
                <?php echo get_permalink($post->ID); ?>

*********************************************************************************************************************************************

Wordpress Default edtior p tag problem

Use This is Code
                <?php echo apply_filters('the_content', $post->post_content); ?>



*********************************************************************************************************************************************

(*)How to get releted post
https://wordpress.stackexchange.com/questions/41272/how-to-show-related-posts-by-category

                <?php
                $related = get_posts(array('category__in' => wp_get_post_categories($post->ID), 'numberposts' => 5, 'post__not_in' => array($post->ID)));
                if ($related)
                foreach ($related as $post) {
                setup_postdata($post);
                ?>
        <ul> 
            <li>
                <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                        <?php the_content('Read the rest of this entry &raquo;'); ?>
            </li>
        </ul>   
                <?php
                }
                wp_reset_postdata();
                ?>


<!-------------------this is my demo ------->

                <?php
                $related = get_posts(array('category__in' => wp_get_post_categories($post->ID), 'numberposts' => 3, 'post__not_in' => array($post->ID)));
                if ($related)
                foreach ($related as $reletedpost) {
                setup_postdata($post);
                $releted_video = get_field('upload_file', $reletedpost->ID);
                ?>
        <li>
            <div class="image">
                <img src="<?php echo site_url(); ?>/wp-content/themes/Compass-Genetics/images/image_1.png" alt="" title="">
                <a data-fancybox="" href="<?php echo $releted_video['url']; ?>" class="video"></a>
            </div>
            <a href=" <?php echo get_permalink($reletedpost->ID); ?>" class="link"><h4><?php the_title(); ?></h4></a>
            <p><?php the_excerpt(); ?></p>
        </li>
                <?php
                }
                wp_reset_postdata();
                ?>


        <!-------------------this is my demo ------->



                <?php
                $post_args = array(
                'posts_per_page' => 3,
                'post__not_in' => array(get_the_ID()), //////This is Line For Current post hide and anthor post whatch
                'post_type' => 'news_post', // you can change it according to your custom post type
                );
                $myposts = get_posts($post_args);
                }
                ?>


            *********************************************************************************************************************************************
            (*)class If condition
            note: jo class ma video hase to avse else ma pdf vado class run thase.
            example : http://localhost:8383/compass-genetics/learning-center




            $second_video = get_field('upload_video', $post_second->ID);
            $second_document = get_field('upload_document', $post_second->ID);

                <?php if (empty($second_video)) {
                ?>
                                                                                                                                                                                    <a download  href="<?php echo $second_document['url']; ?>" class="download"></a>
                <?php } else { ?>
                                                                                                                                                                                    <a data-fancybox="" href="<?php echo $second_video['url']; ?>" class="video"></a>

                <?php } ?>

        *********************************************************************************************************************************************

        /*
        Theme Name: Twenty Fifteen
        Theme URI: https://wordpress.org/themes/twentyfifteen/
        Author: the WordPress team
        Author URI: https://wordpress.org/
        Description: Our 2015 default theme is clean, blog-focused, and designed for clarity. Twenty Fifteen's simple, straightforward typography is readable on a wide variety of screen sizes, and suitable for multiple languages. We designed it using a mobile-first approach, meaning your content takes center-stage, regardless of whether your visitors arrive by smartphone, tablet, laptop, or desktop computer.
        Version: 2.0
        License: GNU General Public License v2 or later
        License URI: http://www.gnu.org/licenses/gpl-2.0.html
        Tags: blog, two-columns, left-sidebar, accessibility-ready, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready
        Text Domain: twentyfifteen

        This theme, like WordPress, is licensed under the GPL.
        Use it to make something cool, have fun, and share what you've learned with others.
        */


        (dynamic original image)
                <?php
                $myposts = get_posts('numberposts=-1');
                foreach ($myposts as $post) :

                $url = wp_get_attachment_url(get_post_thumbnail_id($post->id));
                $src = wp_get_attachment_image_src(get_post_thumbnail_id($post->id), 'full');
                ?>


                                                                                                                                                                                    <li>
                                                                                                                                                                                        <div class="image">
                                                                                                                                                                                            <a href="<?php the_permalink() ?>" class="image"><img src="<?php echo $url = $src[0]; ?>" alt="" title="">
                                                                                                                                                                                                </div>
                                                                                                                                                                                                <div class="desc">
                                                                                                                                                                                                    <h5><a href="<?php the_permalink() ?>"><?php the_title(); ?> Think Design, Think Style, Think Rugs</a></h5>
                                                                                                                                                                                                    <span class="author">Posted by <?php the_author() ?>  |  <strong><?php the_time('d M') ?></strong></span>
                                                                                                                                                                                                    <p><?php echo get_the_excerpt() ?></p>
                                                                                                                                                                                                    <a href="#" class="read-more">read more</a>
                                                                                                                                                                                                </div>
                            <?php endforeach ?>
                    </li>

                    *********************************************************************************************************************************************                                             

                    (*) image file exits or not condition

                            <?php
                            $myposts = get_posts('numberposts=-1');
                            foreach ($myposts as $post) :

                            $img = get_the_post_thumbnail_url();
                            if (empty($img)) {
                            $img = site_url() . '/wp-content/uploads/2018/07/download.png';
                            }
                            ?>


                                                                                                                                                                                                <li>

                                                                                                                                                                                                    <div class="image">
                                                                                                                                                                                                        <a href="<?php the_permalink() ?>"><img src="<?php echo $img ?>" alt="" title=""></a>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                    <div class="desc">
                                                                                                                                                                                                        <h5><a href="<?php the_permalink() ?>"><?php the_title(); ?> Think Design, Think Style, Think Rugs</a></h5>
                                                                                                                                                                                                        <span class="author">Posted by <?php the_author() ?>  |  <strong><?php the_time('d M') ?></strong></span>
                                                                                                                                                                                                        <p><?php echo get_the_excerpt() ?></p>
                                                                                                                                                                                                        <a href="<?php the_permalink() ?>" class="read-more">read more</a>
                                                                                                                                                                                                    </div>
                                <?php endforeach ?>
                    </li>


                    *********************************************************************************************************************************************                                          

                    (*)Craete a sidebar or widget  //how to create widget area in wordpress
                    step 1= function.php

                    function smallenvelop_widgets_init() {
                    register_sidebar( array(
                    'name' => __( 'mayur', 'smallenvelop' ),
                    'id' => 'mayur-sidebar',
                    'before_widget' => '<div>',
                        'after_widget' => '</div>',
                    'before_title' => '<h1>',
                        'after_title' => '</h1>',
                    ) );
                    }
                    add_action( 'widgets_init', 'smallenvelop_widgets_init' );


                    step 2 open your page

                    print_r(dynamic_sidebar('mayur-sidebar') );











                    (*)Dynamic widget 
                            <?php echo (dynamic_sidebar('mayur-sidebar')); ?>z



                    *********************************************************************************************************************************************


                    get the post id

                    note: featured post is custom field 

                            <?php
                            $post_id = get_the_ID();
                            $post_get = get_field('featured post', $post_id);
                            echo "<pre>";
                            print_r($post_get->post_title);
                            ?>
                    <h1><?php echo $post_get->post_title; ?></h1>
                    <p><?php //echo $post_get->post_content;  ?></p>




                    dynamic post link	<a href="<?php echo get_permalink($post_get->ID); ?> ">FIND OUT MORE</a>  




                    *********************************************************************************************************************************************	




                    (*)Dynamic category post
                    example  http://localhost:8383/cement-fondu/project-space/

                    //post_per_page mens per page 1 post
                    //category mens category ID

                    $currentcat = get_posts(array(
                    'posts_per_page' => 1,
                    'category' => 8));
                    $passcat = get_posts(array(
                    'posts_per_page' => 1,
                    'category' => 9));
                    //echo "<pre>";
        $feaucat = get_posts(array(
            'posts_per_page' => 1,
            'category' => 10));

        	
        	 <div class="exhibition-box">
                        <h2 class="title"><a href="#"><?php echo get_cat_name(9); ?></a></h2>
                                    <?php
                                    foreach ($passcat as $postf) : setup_postdata($postf);
                                    $ffeatured_img_url = get_the_post_thumbnail_url($postf->ID, 'full');
                                    $posttitle = $postf->post_title;
                                    ?>
                                                                                                                                                                                                        <div class="blog-article-header">
                                                                                                                                                                                                            <div class="blog-article-header-date"> </div>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                        <div class="image"><a href="<?php echo get_permalink($postf->ID); ?>"> <img src="<?php echo $ffeatured_img_url ?>" alt="<?php echo $posttitle ?>"> </a></div>
                                                                                                                                                                                                        <div>
                                                                                                                                                                                                            <h2><a href="<?php echo get_permalink($postf->ID); ?>"><?php echo $posttitle ?></a></h2>
                                                                                                                                                                                                            <a href="<?php echo get_permalink($postf->ID); ?>" class="link">Find out more</a> </div>
                                    <?php endforeach; ?>
                    </div>
        	
        	
        *********************************************************************************************************************************************

        (*)Get Coustom Field
        Note: right_sidebar_content mens Field Name 	
        example:
                                <?php echo get_field('right_sidebar_content'); ?>

        *********************************************************************************************************************************************
        Repeater Field
*********************************************************************************************************************************************
        Example Of http://localhost:8080/nhs-group/wp-admin/post.php?post=489&action=edit
        Example of acf admin site
        **First 
        Type Your Name : Gallery Image
        Select Filed Type Repeater
        Create New Sub Field Name should be (floor_plan_gallery_image) Type Imge
        And Select Layout Row

                                <?php
                                $rows = get_field('gallery_image', page id);
                                if ($rows) {
                                foreach ($rows as $row) {
                                ?>
                                                                                                                                                                                                                                                                                                                                                                                        <li>
                                         $row['fieldname'];                                                                                                                                                                                                                                                                                                                                                   <a href="<?php echo $row['floor_plan_gallery_image']; ?>" data-fancybox="gallery1"><img src="<?php echo $row['floor_plan_gallery_image']; ?>" alt="<?php the_title(); ?>" title="<?php the_title(); ?>"></a>
                                                                                                                                                                                                                                                                                                                                                                                        </li>
                                <?php
                                }
                                }
                                ?>
        



*********************************************************************************************************************************************
        ACF POST OBJECT Field
*********************************************************************************************************************************************  
 1111
<?php
$shopgiftcard = get_field('shop_gift_card');
foreach ($shopgiftcard as $shopvalue) {
$giftcardimg = get_the_post_thumbnail_url($shopvalue->ID, 'full');
$giftcardurl = get_field('add_gift_card_link', $shopvalue->ID);
?>

                <li><a href="<?php echo $giftcardurl; ?>"><img src="<?php echo $giftcardimg; ?>"></a></li>
<?php } ?>

2222
post object

<?php
$proposts = get_field('case_studies_selection');
foreach ($proposts as $proj) {
$pro_title = $proj->post_title;
$pro_img = get_the_post_thumbnail_url($proj->ID, 'full');
$pro_subtitle = get_field('projects_sub_title', $proj->ID);
$pro_pagedetailurl = get_field('project_detail_url', $proj->ID);
$pro_banner = get_field('project_banner', $post->ID);
$pro_permalink = get_permalink($proj->ID);
?>

<?php } ?>
          
         ********************************************************************************************************************************************* 
          (*) WordPress change login default logo function
          
          //example of https://codex.wordpress.org/Customizing_the_Login_Form
          
          //Note : This is code copy And paste in function File
          
          function my_login_logo() { ?>
            <style type="text/css">
                                    #login h1 a, .login h1 a {
                                        background-image: url(<?php echo site_url(); ?>/wp-content/themes/twentysixteen/images/logo-black.png );

                                        height:65px;
                                        width:320px;
                                        background-size: 320px 65px;
                                        background-repeat: no-repeat;
                                        padding-bottom: 30px;
                                    }
            </style>
                                <?php
                                }
                                add_action( 'login_enqueue_scripts', 'my_login_logo' );

                                *********************************************************************************************************************************************
                                ?>
*********************************************************************************************************************************************
*********************************************************************************************************************************************


(*)WordPress Default login change default link function

//example of http://extracatchy.net/wordpress-login-logo-url/

//Note : This is code copy And paste in function File

function annointed_admin_bar_remove() {
        global $wp_admin_bar;

        /* Remove their stuff */
        $wp_admin_bar->remove_menu('wp-logo');
}
add_action('wp_before_admin_bar_render', 'annointed_admin_bar_remove', 0); 
  
  
  *********************************************************************************************************************************************
  (*) WordPress Default Admin Hide logo(left side corner hide logo)

  
  function annointed_admin_bar_remove() {
        global $wp_admin_bar;

        /* Remove their stuff */
        $wp_admin_bar->remove_menu('wp-logo');
}
add_action('wp_before_admin_bar_render', 'annointed_admin_bar_remove', 0);


 
  *********************************************************************************************************************************************
(*)Change login Logo Default name (Powerd By wordpress to Powered By Cement fondu)
 
  Note : example of https://codex.wordpress.org/Customizing_the_Login_Form
  
  function my_login_logo_url_title() {
    return 'Powered By Cement fondu';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );




*********************************************************************************************************************************************
(*) Multile Image Insert In one Post 

Note: download plugin (Dynamic Featured Image)  https://wordpress.org/plugins/dynamic-featured-image/

note: create loop
example https://github.com/ankitpokhrel/Dynamic-Featured-Image/wiki/Retrieving-data-in-a-theme 

NOTE : get the multiple image in One Post


while ( have_posts() ) : the_post();

   if( class_exists('Dynamic_Featured_Image') ) {
       global $dynamic_featured_image;
       $featured_images = $dynamic_featured_image->get_featured_images( );
       //echo "<pre>";
        //print_r($featured_images);
       //You can now loop through the image to display them as required
   }
   
   endwhile;

   
   
   THis is code is image path
   
                                    <?php
                                    foreach ($featured_images as $image) {
                                    //  echo $image['full'];
                                    //echo $image['thub'];
                                    ?>
                                                                                                                                                                                                                                                                                                                                                                                                                        	this is image path
                                                                                                                                                                                                                                                                                                                                                                                                                        	<img class="" src="<?php echo $image['full'] ?> " alt="<?php echo $posttitle ?>"> 

                                                                                                                                                                                                                                                                                                                                                                                                                        	After ENd foreach loop
                                    <?php } ?>


*********************************************************************************************************************************************
(*)How to set character limit on the_content() and the_excerpt() in wordpress

Note: https://stackoverflow.com/questions/3147898/how-to-set-character-limit-on-the-content-and-the-excerpt-in-wordpress

<?php
$char_limit = 100; //character limit
$content = $post_get->post_content; //contents saved in a variable
echo substr(strip_tags($content), 0, $char_limit) . "...";
?>


OR

https://stackoverflow.com/questions/3161816/truncate-a-string-to-first-n-characters-of-a-string-and-add-three-dots-if-any-ch

without string cut & word Less three dots characters are removed

<?php
$string = "sgadj dfdhgf fdghfk fdg";

  $string = trim($string);

  if(strlen($string) > 100) {
    $string = wordwrap($string, 100);
    $string = explode("\n", $string, 2);
    $string = $string[0] . '...';
  }
echo $string;
?>





*********************************************************************************************************************************************



(*)Add Wordpress New Menu
NOte: Save this code function.php 
Patients/Cases Name is Your Menu Name

function create_posttype() {
  register_post_type( 'wpll_Patients/Cases',
    array(
      'labels' => array(
        'name' => __( 'Patients/Cases' ),
        'singular_name' => __( 'Patients/Cases' )
      ),
      'public' => true,
      'has_archive' => true,
      'rewrite' => array('slug' => 'patients/Cases'),
    )
  );
}
add_action( 'init', 'create_posttype' );


*********************************************************************************************************************************************
Get Wordpress Defult Post
*********************************************************************************************************************************************

                                    <?php
                                    $blogposts = get_posts(array(
                                    'posts_per_page' => 3,
                                    'category' => 85
                                    ));

                                    if ($blogposts) {
                                    foreach ($blogposts as $post) :
                                    setup_postdata($post);
                                    $imgpath = get_the_post_thumbnail_url($post->ID, 'full');
                                    if ($imgpath) {
                                    $gifimg = $imgpath;
                                    } else {
                                    $gifimg = site_url('/wp-content/uploads/2020/10/default.jpg');
                                    }
                                    ?>


        <img src="<?php echo $gifimg; ?>">
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <p><?php echo get_the_date('F, j Y'); ?></p>
                                    <?php the_content(); ?>
                                    <?php
                                    endforeach;
                                    wp_reset_postdata();
                                    }
                                    ?>


*********************************************************************************************************************************************
Wordpress custom Post Type How to get Post Detail
example https://code.tutsplus.com/tutorials/a-guide-to-wordpress-custom-post-types-creation-display-and-meta-boxes--wp-27645

(this is while loop)
                                    <?php
                                    $mypost = array('post_type' => 't-database', );
                                    $loop = new WP_Query($mypost);
                                    ?>
                                    <?php while ($loop->have_posts()) : $loop->the_post(); ?>
                                                                                                                                                                                                                                                                                                                                                                                                                                                <strong>Title: </strong><?php the_title(); ?><br />
                                                                                                                                                                                                                                                                                                                                                                                                                                                <strong>content: </strong><?php the_content(); ?><br />
                                                                                                                                                                                                                                                                                                                                                                                                                                                <strong>Excerpt: </strong><?php the_excerpt(); ?><br />
                                                                                                                                                                                                                                                                                                                                                                                                                                                <strong>ID: </strong><?php the_ID(); ?><br />
                                    <?php endwhile; ?>
						
(this is Foreach loop)

                                    <?php
                                    global $post;
                                    $posts = get_posts(array('post_type' => 'latest-news-updates'));
                                    if ($posts):
                                    foreach ($posts as $post) :
                                    setup_postdata($post);
                                    ?>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        								
                                    <?php echo get_permalink($post->ID); ?>                                  
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <strong><?php echo get_the_title(); ?></strong>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <em><?php echo get_the_content(); ?></em>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        										the_excerpt();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        										
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        										
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        										
                                    <?php
                                    endforeach;
                                    wp_reset_postdata();
                                    endif;
                                    ?>
				



                                    <?php
                                    $posts = get_posts(array('post_type' => 'work_post',
                                    'post_status' => 'publish',
                                    'posts_per_page' => -1));
                                    //echo '<pre>';
                                    /// print_r($get_post);
                                    foreach ($posts as $post1) :
                                    $char_limit = 50;
                                    $post_content = $post1->post_content;
                                    $post_title = $post1->post_title;
                                    $featured_img_url = get_the_post_thumbnail_url($post1->ID, 'full');
                                    $filmname = get_field('film_name', $post1->ID);
                                    $digisheds_name = get_field('digisheds_name', $post1->ID);






                                    (this is Foreach loop with unlimited post)

                                    <?php
                                    $posts = get_posts(array('post_type' => 'learning_center', 'posts_per_page' => -1));
                                    foreach ($posts as $post) :
                                    // $terms = get_the_terms(get_the_ID(), 'learning_center_category');
                                    ?>
                                                                                                                                                                                                                                                                                                                                                                                                                <strong><?php echo $post->post_title . '<br/>'; ?></strong>
                                                                                                                                                                                                                                                                                                                                                                                                            <!--    <h5><strong>Category: <?php
//            foreach ($terms as $catname) {
//
//                $name = $catname->name;
//                echo $name;
//            }
                                    ?></strong></h5> -->

                                    <?php echo get_permalink($post->ID); ?>
                                    <?php
                                    endforeach;
                                    ?>

*********************************************************************************************************************************************

coustom post type post derail page's

                                    <?php echo $post->post_title; ?>
                                    <?php echo $post->post_excerpt; ?>

$featured_img_url = get_the_post_thumbnail_url($post->ID, 'full'); 




						
*********************************************************************************************************************************************

Get custom post type by  custom post categoty id
                                    <?php
                                    $proposts = get_posts(array(
                                    'showposts' => 3,
                                    'post_type' => 'projects-post',
                                    'tax_query' => array(
                                    array(
                                    'taxonomy' => 'projects_categories',
                                    'terms' => '4'
                                    ))
                                    ));


                                    foreach ($proposts as $proj) {
                                    $pro_title = $proj->post_title;
                                    $pro_img = get_the_post_thumbnail_url($proj->ID, 'full');
                                    $pro_subtitle = get_field('projects_sub_title', $proj->ID);
                                    ?>
                        <li>
                            <a href="<?php echo get_permalink($post->ID); ?>" class="image"><img src="<?php echo $pro_img; ?>"></a>
                            <div class="desc">
                                <h4><a href="<?php echo get_permalink($post->ID); ?>"><?php echo $pro_title; ?></a></h4>
                                <p><?php echo $pro_subtitle; ?></p>
                            </div>
                        </li>
                                    <?php } ?>

*********************************************************************************************************************************************
custom Post Type How to get Post Category
                                    <?php
                                    $args = array(
                                    'taxonomy' => 'learning_center_category',
                                    'orderby' => 'name',
                                    'order' => 'ASC'
                                    );

                                    $cats = get_categories($args);

                                    foreach ($cats as $cat) {
                                    ?>
                                                                                                                                                                                                                                                                                                                                                                                                            		<a href="<?php echo get_category_link($cat->term_id) ?>">
                                        <?php
                                        echo $cat->name;
                                        $banslidersecection = get_field('banner_slider_section', 'term_' . $cat->term_id);
                                        ?>                                                                                                                                                                                                                                                                                                                                                 		</a>
                                    <?php
                                    }
                                    ?>


*********************************************************************************************************************************************



custom Post Type How to get Post Category and Teg

$terms = get_the_terms(get_the_ID(), 'test-categories');
notes: test-categories is custom post name

<h5><strong>Category: <?php
                                            $num_of_items = count($terms);
                                            $num_count = 0;
                                            foreach ($terms as $catname) {
                                            //echo '<pre>';
                                            // print_r($catname);
                                            $name = $catname->name;
                                            echo $name;
                                            $num_count = $num_count + 1;
                                            if ($num_count < $num_of_items) {
                                            echo ", ";
                                            }
                                            }
                                            ?></strong></h5> 
						
CUSTOM POST TYPE TAGE  GET

$tag = get_the_terms(get_the_ID(), 'test-genes');
notes: test-genes is custom post taxonomy name 

                                    <?php foreach ($tag as $genes) : ?>

                                                                                                                                                                                                                                                                               <a href="#"><?php echo $genes->name; ?></a>
                                    <?php endforeach; ?>
						
						
						
						
	*********************************************************************************************************************************************					
			CUSTOM POST TYPE Releted Post			
						
						<!--  <?php
                                    $related = get_posts(array('category__in' => wp_get_post_categories($post->ID), 'numberposts' => 3, 'post_type' => 'event_calender', 'post__not_in' => array($post->ID)));
                                    if ($related)
                                    foreach ($related as $post) {
                                    setup_postdata($post);
                                    ?>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              <li>
                                    <?php the_post_thumbnail(); ?>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                                    <?php
                                    }
                                    wp_reset_postdata();
                                    ?> -->


						
						
						
*********************************************************************************************************************************************


*********************************************************************************************************************************************		

this is comma seprate value (example :  Test_technology 1, Test_technology 2, Test_technology 3, Test_technology 4, Test_technology 5)
Note: last value not comma in this code


<h5><strong>Category: <?php
                                            $num_of_items = count($terms);
                                            $num_count = 0;
                                            foreach ($terms as $catname) {
                                            //echo '<pre>';
                                            // print_r($catname);
                                            $name = $catname->name;
                                            echo $name;
                                            $num_count = $num_count + 1;
                                            if ($num_count < $num_of_items) {
                                            echo ", ";
                                            }
                                            }
                                            ?></strong></h5>   	

*********************************************************************************************************************************************						
GET USer Role wise
example: https://wordpress.stackexchange.com/questions/219686/how-can-i-get-a-list-of-users-by-their-role

                                    <?php
                                    $args = array(
                                    'role' => 'test-provider',->test provider is user role name
                                    'orderby' => 'user_nicename',
                                    'order' => 'ASC'
                                    );
                                    $users = get_users($args);

                                    echo '<ul>';
                                    foreach ($users as $user) {
                                    echo '<li>' . esc_html($user->display_name) . '[' . esc_html($user->user_email) . ']</li>';
                                    }
                                    echo '</ul>';
                                    ?>	

*********************************************************************************************************************************************		


THis is for fuction using all 			
function searchcg_test_database() {
    $demo = '<form role = "search" method = "get" class = "search-form" action = "'. esc_url(home_url('/')) . '">
    <label>
    <span class = "screen-reader-text">'. _x('Search for:', 'label', 'twentysixteen'). '
    </span>
    <input type="search" class="search-field" placeholder=" ' . esc_attr_x('Search &hellip;', 'placeholder', 'twentysixteen') . '" value="' . get_search_query(). '" name="s" />
    <input type="hidden" name="post_type" value="test_database" />
    </label>
    <button type="submit" class="search-submit"><span class="screen-reader-text">' . _x('Search', 'submit button', 'twentysixteen') . '</span></button>
</form>' 


    return $demo;
}

//add_shortcode('search_testdatabase', 'searchcg_test_database');

*********************************************************************************************************************************************		
*********************************************************************************************************************************************		

THis is for create post using acf field

project compass genetics using add test databasepage

Link  = https://stackoverflow.com/questions/40704991/how-do-i-redirect-after-submission-with-acf-form

                                    <?php
                                    ob_get_clean(); // aa code header ni uper type karvanu
                                    acf_form_head(); // aa code header ni uper type karvanu
                                    acf_form(array(
                                    'post_id' => 'new_post',
                                    'post_title' => true,
                                    'post_content' => false, // this is for conetnt show or hide
                                    'new_post' => array(
                                    'post_type' => 'test_database', // this is for which create post name
                                    'post_status' => 'publish'
                                    ),
                                    'return' => add_query_arg('updated', 'true', home_url('/my-test-database/')), // this is redirect page url 
                                    'submit_value' => 'Save'
                                    ));
                                    ?>   


*********************************************************************************************************************************************		
*********************************************************************************************************************************************		
*********************************************************************************************************************************************		
		

THis is for update post using acf field

project compass genetics using add test databasepage

Link  = https://stackoverflow.com/questions/40704991/how-do-i-redirect-after-submission-with-acf-form

                                    <?php
                                    ob_get_clean(); // aa code header ni uper type karvanu
                                    acf_form_head(); // aa code header ni uper type karvanu
                                    acf_form(array(
                                    'post_id' => $post_id, //get post user id
                                    'post_title' => true,
                                    'post_content' => false,
                                    'field_groups' => array('379'), //this is for show custom field            
                                    'submit_value' => 'Update',
                                    'return' => add_query_arg('updated', 'true', home_url('/my-test-database/')), //Returns to the original page post
                                    'updated_message' => __("Post updated", 'acf')
                                    ));
                                    acf_form($args);
                                    ?> 


*********************************************************************************************************************************************	
 //wordpress one image get two image 
Example Of https://developer.wordpress.org/reference/functions/add_image_size/

                    $floor_img = get_the_post_thumbnail_url($post1->ID, 'full'); //this is for full image
                    $floor_img_thumb = get_the_post_thumbnail_url($post1->ID, 'gallery-size-thumb'); //this is for thumbhail image

//this is function 

add_image_size( 'gallery-size-thumb', 368, 247 , array( 'center', 'center' ));

*********************************************************************************************************************************************


*********************************************************************************************************************************************
ACF radio Button 
*********************************************************************************************************************************************		
Add acf this type data

forsale : For Sale
completedproject : Completed
underconstruction : Under Construction
nowleasing : Now Leasing

                                    <?php $project_status = get_field('project_status', $proj->ID); ?>

                                    <?php if ($project_status['value'] == 'forsale') { ?>
                        <span class="for-sale-tag">For Sale</span>
                                    <?php } else if ($project_status['value'] == 'completedproject') { ?>
                        <span class="completed-tag">Completed</span>
                                    <?php
                                    }






                                    *********************************************************************************************************************************************

                                    Create Acf using option Page :-
                                    example gallary in admin page and use all thing

                                    https://www.advancedcustomfields.com/resources/options-page/




                                    Function.php


                                    if( function_exists('acf_add_options_page') ) {

                                    acf_add_options_page(array(
                                    'page_title' => 'Gallery Section',
                                    'menu_title' => 'Gallery Section'

                                    ));

                                    }



                                    acf - > option page->show Gallery Section option menu

                                    get code

                                    https://www.advancedcustomfields.com/resources/options-page/

                                    <?php echo get_field('acf-field-name', 'option');
                                    ?>

                                    <?php
                                    $images = get_field('gallery', 'option');
                                    $size = 'full';
                                    //echo '<pre>';
                                    // print_r($images);
                                    foreach ($images as $image) {
                                    ?>
                                                                                                                                                                                            <div>
                                                                                                                                                                                                <img src="<?php echo $image['url']; ?>">
                                                                                                                                                                                            </div>
                                    <?php } ?>





************************************************************************************************************************************************
Get ACF Gallery Field

                                    <?php
                                    $images = get_field('portfolio_gallery');

                                    foreach ($images as $image) {
                                    ?>

                <li><img src="<?php echo $image['url']; ?>"></li>
                                    <?php } ?>



*********************************************************************************************************************************************

ACF CREATE ADMIN SITE MENU
EXAMPLE OF THIS URL:------ https://www.advancedcustomfields.com/add-ons/options-page/

FUNCTION.PHP --------

if( function_exists('acf_add_options_page') ) {

    $page = acf_add_options_page(array(
        'page_title' 	=> __('My Theme Options', 'productify'),
        'menu_title' 	=> __('My Theme', 'productify'),
        'menu_slug' 	=> 'my-theme-options',
        'capability' 	=> 'edit_posts',
        'redirect' 	    => false
    ));

}


ACF SITE CREATE NEW ACF FIELD AND RULES SELECT  (OPTION PAGE ) and select open page show it function created name

https://support.advancedcustomfields.com/forums/topic/options-page-not-showing-up/


*********************************************************************************************************************************************		
Create Wordpress Default Audio & Video & Gallery

First Step
 Page->content editor->add media-> left side corner option hear ->select any option->select any video or audio ->insert into page and save it and run



*********************************************************************************************************************************************		

Add Body Class In My page 





*****************************************

Wordpress plugin not install required FTP Information

Go to Config file

define('FS_METHOD', 'direct');

*****************************************

Add function file css/ responsive dynamic

function twentysixteen_scripts() {

Example Of aia/ createstudio
under 


Function file Line noumber  423 after

// load custom css in header
    $style_vere1 = filemtime(get_stylesheet_directory() . '/css/style.css');
    wp_enqueue_style('aia_style', get_stylesheet_directory_uri() . '/css/style.css', '', $style_vere1);

    $style_vere11 = filemtime(get_stylesheet_directory() . '/css/devstyle.css');
    wp_enqueue_style('aia_devstyle', get_stylesheet_directory_uri() . '/css/devstyle.css', '', $style_vere11);

    $style_vere12 = filemtime(get_stylesheet_directory() . '/css/responsive.css');
    wp_enqueue_style('aia_revstyle', get_stylesheet_directory_uri() . '/css/responsive.css', '', $style_vere12);



******************************************************************************************************************

Add Post & Custom Post Type Featured Image Decription

function gv_admin_featured_image() {
        $newsoutput = "Upload Image - 565px (width) / 340px (height)";     <!-- defualt post -->
        $hloutput = "Upload Image - 512px (width) / 367px (height)";      <!-- custom post type (add class example for (post-type-property)) -->
        ?>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $('.post-type-post #postimagediv .inside').append("<?php echo $newsoutput; ?>");
        $('.post-type-property #postimagediv .inside').append("<?php echo $hloutput; ?>");
    });
                </script>

<?php
}
add_action('admin_head', 'gv_admin_featured_image');


                                    ******************************************************************************************************************

                                    Add Center Crop Image Code

                                    add_image_size('custom-size-hl&hd', 512, 367, array('center', 'center')); // House & Land and Home Design - Thumbnail image
                                    add_image_size('custom-size-news', 565, 340, array('center', 'center')); // News - Thumbnail image


                                    Try for example : - <?php echo get_the_post_thumbnail_url(get_the_ID(), 'custom-size-news');
                                    ?>


******************************************************************************************************************

Wordpress update disabled -  https://thomas.vanhoutte.be/miniblog/wordpress-hide-update/


Add function file

// hide update notifications
function remove_core_updates(){
global $wp_version;return(object) array('last_checked'=> time(),'version_checked'=> $wp_version,);
}
add_filter('pre_site_transient_update_core','remove_core_updates'); //hide updates for WordPress itself
add_filter('pre_site_transient_update_plugins','remove_core_updates'); //hide updates for all plugins
add_filter('pre_site_transient_update_themes','remove_core_updates'); //hide updates for all themes



Config file's
---------------------------------------

define( 'WP_AUTO_UPDATE_CORE', false );

Auto update plugin disbale - function file
------------------------

add_filter( 'auto_update_plugin', '__return_false' );

add_filter( 'auto_update_theme', '__return_false' );

******************************************************************************************************************

contact form submit redirect event's

Add Script JS file

<script>
document.addEventListener('wpcf7mailsent', function (event) {   

 if ('160' == event.detail.contactFormId) {
       window.location.href = "http://13.251.140.13/wordpress/pav/ty-realestate-360/";
   }
if ('160' == event.detail.contactFormId) {
       window.location.href = "http://13.251.140.13/wordpress/pav/ty-realestate-360/";
   }
}, false);
  </script>

ORR
Add in heder Or footer filed
<script>
                                        document.addEventListener('wpcf7mailsent', function (event) {

                                            if ('6071' == event.detail.contactFormId) {
                                                window.location.href = "http://13.251.140.13/wordpress/pav/ty-realestate-360/";
                                            }
                                        }, false);
                                    </script>


One contact form redirect multi page


-------------------------------------------
<script>
    var pageid = "<?php echo get_the_id() ?>";
    document.addEventListener('wpcf7mailsent', function (event) {
        if ('6286' == event.detail.contactFormId && pageid == 7266) {
            window.location.href = "https://photosandvideos.com.au/ty-real-estate-drone-photography-melbourne/";
        }
        if ('6286' == event.detail.contactFormId && pageid == 7269) {
            window.location.href = "https://photosandvideos.com.au/ty-drone-real-estate-photography/";
        }
        if ('6286' == event.detail.contactFormId && pageid == 7271) {
            window.location.href = "https://photosandvideos.com.au/ty-drone-photography-services-melbourne/";
        }
        if ('6286' == event.detail.contactFormId && pageid == 7273) {
            window.location.href = "https://photosandvideos.com.au/ty-aerial-drone-photography-melbourne/";
        }
        if ('6286' == event.detail.contactFormId && pageid == 7275) {
            window.location.href = "https://photosandvideos.com.au/ty-real-estate-aerial-photography/";
        }
    }, false);
</script>
*********************************************************************************************************************************************

change Wordpress Defult css


Add function file's

add_action('admin_head', function() {
    ?>  
    <style>  #woocommerce-product-data ._sale_price_field , #woocommerce-product-data ul.wc-tabs li.marketplace-suggestions_tab , .woocommerce_options_panel p.stock_status_field {display:none;} 
                                        #adminmenu .wp-submenu , #dashboard-widgets-wrap , #welcome-panel , #vc_license-activation-notice {display: none !important;}
    </style> <?php
                                    });



                                    *********************************************************************************************************************************************
                                    Post delete with image (jyare post delet kariye tyare post ni featured image delete thai jay media mathi pan )

                                    https://wordpress.stackexchange.com/questions/333990/remove-featured-image-all-media-uploaded-to-the-post


                                    add_action( 'before_delete_post', 'wps_remove_attachment_with_post', 10 );
                                    function wps_remove_attachment_with_post( $post_id ) {

                                    /** @var WP_Post[] $images */
                                    $images = get_attached_media( 'image', $post_id );

                                    foreach ( $images as $image ) {
                                    wp_delete_attachment( $image->ID, true );
                                    }
                                    }




*********************************************************************************************************************************************
Display Post Author for Custom Post Type in Edit-Post Screen
    
    
                                    
function add_author_support_to_posts() {
   add_post_type_support( 'home-designs', 'author' ); 
}
add_action( 'init', 'add_author_support_to_posts' );




Post backend show author filter
--------------------------------------------------

https://rudrastyh.com/wordpress/filter-posts-by-author.html

function rudr_filter_by_the_author() {
	$params = array(
		'name' => 'author', // this is the "name" attribute for filter <select>
		'show_option_all' => 'All authors' // label for all authors (display posts without filter)
	);
 
	if ( isset($_GET['user']) )
		$params['selected'] = $_GET['user']; // choose selected user by $_GET variable
 
	wp_dropdown_users( $params ); // print the ready author list
}
 
add_action('restrict_manage_posts', 'rudr_filter_by_the_author');

*********************************************************************************************************************************************

Filter Hide Show All Button (THis is to Js file OR Footer File)

<script>
    jQuery(window).on("load", function () {
        
        jQuery('.videopost .video-filter li:nth-child(2) a').trigger('click');
        jQuery('.portfolio-showall .qodef-m-filter-items a:nth-child(2)').trigger('click');
        
    });
</script>

<style>
    .videopost .video-filter li:nth-child(1) {
        display: none !important;
    }
    .portfolio-showall .qodef-m-filter-items a:nth-child(2){
        display: none !important;
    }
</style>


*********************************************************************************************************************************************
*********************************************************************************************************************************************

Simple Shortcodes 
https://www.hostinger.in/tutorials/create-a-shortcode-in-wordpress

function subscribe_link(){
return 'Follow us on <a rel="nofollow" href="https://twitter.com/Hostinger?s=20">Twitter</a>';
}
add_shortcode('subscribe', 'subscribe_link');

echo - [subscribe]


*********************************************************************************************************************************************