




(1)  wordpress newsletter()
=>   MailChimp for WordPress


(2)  instagram()
=>   instagram feed

(3)  field
=>   custom fields


(3)  all form
=   contect form 7


(4) Set up Live Replace url
==> Better search replace
By - Delicious Brains (Auther Name)



(5)Send mail
=>Post SMTP Mailer/Email Log
By-Jason Hendriks, Yehuda Hassine


(6)IP2Location Redirection
=>Version 1.13.1 | By IP2Location
Hide your site in any country

Step
general page find location in hide country
from => any page
destination=> create page and select your page and save changes

go to a ipquery 
ip address=> ip address for hide country => lookup

*******

*****************************************
*****************************************


contact form hidden add post title

Contact Form 7 Modules: Hidden Fields   https://wordpress.org/plugins/contact-form-7-modules/
*****************************************

(7)
*****************************************

download this plugin
Really Simple CAPTCHA

https://contactform7.com/captcha/

use in contact form 7
how to use : https://www.youtube.com/watch?v=HyLLCxzBdc0



*****************************************
Add Google captcha
*****************************************

--> First Create API
--> Contact form 7 Add Integration API
--> AFTER Click reCaptcha Version and select reCaptcha Version2 and google.com after save

contact form add this code [recaptcha]

Pluginname: ReCaptcha v2 for Contact Form 7    https://wordpress.org/plugins/wpcf7-recaptcha/

&AElig;
Not visible captcha add this script in footers

You need to include the recaptcha library before </head>:

<script src="https://www.google.com/recaptcha/api.js" async defer></script


https://stackoverflow.com/questions/46245302/contact-form-7-recaptcha-not-displaying-on-form





*****************************************

Create New Custom Post Type

example new left side your name field

Toolset Types
BY: OnTheGoSystems 

*****************************************
Create custom post type
CPT UI

*****************************************

*****************************************
Social Login (miniOrange social login)
WordPress Social Login and Register (Discord, Google, Twitter, LinkedIn)
https://wordpress.org/plugins/miniorange-login-openid/

google configer example - https://www.youtube.com/watch?v=q7nK1lp7yqc
facebook configer example - https://youtu.be/ju21twD0uB0

*****************************************

Drag and drop post and custom post and texonomi plugin
Simple Custom Post Order
By Colorlib



*****************************************
iThemes Security
Plugin url
https://wordpress.org/plugins/better-wp-security/

Example: wp-admin convert to my admin  http://localhost:8080/woocommerce_filter/wp-admin to http://localhost:8080/woocommerce_filter/wplogin
iThemes Security 
Select menu :-- Hide Backend Menu 


*****************************************
Facebook Messenger Customer Chat

https://wordpress.org/plugins/facebook-messenger-customer-chat/

HOw to :- https://www.youtube.com/watch?v=zne400tXSiY


*****************************************
Hide wp-admin/wp-login.php


https://wordpress.org/plugins/wps-hide-login/

https://www.google.com/search?q=how+to+WPS+Hide+Login+use&oq=how+to+WPS+Hide+Login+use&aqs=chrome..69i57j0.3647j0j7&sourceid=chrome&ie=UTF-8#kpvalbx=1



*****************************************

WP Fastest Cache

https://wordpress.org/plugins/wp-fastest-cache/



*****************************************

Wordfence

https://wordpress.org/plugins/wordfence/


*****************************************
Duplicate page post 

https://wordpress.org/plugins/duplicate-page/


*****************************************

Instagram feed

https://wordpress.org/plugins/instagram-feed/


used 

https://laurinex.cleaning/
team-bear.com









Instagram feed

https://codecanyon.net/item/instagram-feed-wordpress-gallery-for-instagram/13004086?ref=Elfsight&clickthrough_id=1412629442&redirect_back=true


Demo Avialble free sigh up and after create new instagram & Youtube and after grenrate code paste Your Site

Demo on 

"http://13.251.140.13/wordpress/br_shop/"








*****************************************

Wordpress plugin not install required FTP Information

Go to Config file

define('FS_METHOD', 'direct');

*****************************************


Simple Cookie Control

https://wordpress.org/plugins/simple-cookie-control/

custemization-> options 




*****************************************
Contact form 7 Database 
*****************************************

Contact Form 7 Database Addon � CFDB7

https://wordpress.org/plugins/contact-form-cfdb7/

note:  this plugin used for nhs live site :https://newhomeshop.com.au/


OR 


Advanced Contact form 7 DB

https://wordpress.org/plugins/advanced-cf7-db/


*******************************************************
Wordpress Import Export All data In Admin Site
*******************************************************

https://wordpress.org/plugins/all-in-one-wp-migration/


Example This is Video

https://www.youtube.com/watch?v=DVG-PeZBEv0


*******************************************************

*******************************************************

FEED Plugin  - Twitter feed, Youtube, Pinterest and more

Plugin Name : -  Feed Them Social - for Twitter feed, Youtube, Pinterest and more

https://wordpress.org/plugins/feed-them-social/


Note: use in https://tiger-law.com/ & https://tiger-hr.com/

note: Firest of all create devloper account in any feed
this for twitter example: - https://www.youtube.com/watch?v=3353Mgdme4c

This is for devloper aacount question answer - https://www.goodknowledge.co.in/how-to-generate-twitter-api-key/


*******************************************************
